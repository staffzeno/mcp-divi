<?php
/**
 * Exception thrown by tool handlers for a clean, user-facing error.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tool error.
 */
class TWDB_Tool_Error extends Exception {

	/**
	 * Machine readable code.
	 *
	 * @var string
	 */
	public $error_code;

	/**
	 * Extra data.
	 *
	 * @var array
	 */
	public $data;

	/**
	 * Constructor.
	 *
	 * @param string $error_code Code.
	 * @param string $message    Message.
	 * @param array  $data       Extra data.
	 */
	public function __construct( $error_code, $message, $data = array() ) {
		parent::__construct( $message );
		$this->error_code = $error_code;
		$this->data       = $data;
	}
}
