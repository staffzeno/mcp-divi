<?php
/**
 * Settings storage and the Settings > TW Divi Builder admin page.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings.
 */
class TWDB_Settings {

	const PAGE_SLUG = 'tw-divi-builder';

	/**
	 * Default settings.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'acting_user'         => 0,
			'read_only'           => false,
			'groups'              => array_keys( TWDB_Tools::groups() ),
			'allow_app_passwords' => true,
			'allow_url_key'       => false,
			'allow_path_key'      => false, // Keys in URLs can end up in server and proxy logs; opt-in only (1.4.3).
			'allow_oauth'         => true,
			'helpers'             => true,
		);
	}

	/**
	 * Get all settings merged with defaults.
	 *
	 * @return array
	 */
	public static function get() {
		$saved = get_option( 'twdb_settings', array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	/**
	 * Get a single setting.
	 *
	 * @param string $key Key.
	 * @return mixed
	 */
	public static function value( $key ) {
		$all = self::get();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	/**
	 * Resolve the user the AI acts as.
	 *
	 * @return int
	 */
	public static function acting_user_id() {
		$id = (int) self::value( 'acting_user' );
		if ( $id ) {
			// A chosen user that no longer exists is NOT replaced by an administrator: a key issued to act as an
			// editor must never start acting as an administrator because that editor was deleted.
			return get_userdata( $id ) ? $id : 0;
		}
		// Never configured (e.g. activated from WP-CLI, or a network-activated sub-site): the first
		// administrator of this site. On a network a Super Admin is never picked implicitly: the site's own
		// administrators could otherwise act with network-wide powers through the AI.
		$admins = get_users(
			array(
				'role'    => 'administrator',
				'number'  => 20,
				'orderby' => 'ID',
				'fields'  => 'ID',
			)
		);
		foreach ( (array) $admins as $admin_id ) {
			if ( ! is_multisite() || ! is_super_admin( (int) $admin_id ) ) {
				return (int) $admin_id;
			}
		}
		return 0;
	}

	/**
	 * May $approver let an AI act as $acting? Stops a site administrator on a multisite network from
	 * delegating a network Super Admin's powers they do not have themselves.
	 *
	 * @param int $approver Approving / configuring user.
	 * @param int $acting   Acting user.
	 * @return bool
	 */
	public static function may_delegate( $approver, $acting ) {
		$approver = (int) $approver;
		$acting   = (int) $acting;
		if ( ! $acting || ! $approver ) {
			return false;
		}
		if ( is_multisite() && is_super_admin( $acting ) && ! is_super_admin( $approver ) ) {
			return false;
		}
		return true;
	}

	/* ------------------------------------------------------------------
	 * Key hashing. Only an HMAC of a key is stored. Named keys live in TWDB_Keys.
	 * ---------------------------------------------------------------- */

	/**
	 * Hash a key.
	 *
	 * @param string $key Plain key.
	 * @return string
	 */
	public static function hash_key( $key ) {
		return hash_hmac( 'sha256', (string) $key, wp_salt( 'auth' ) . 'twdb' );
	}

	/**
	 * Revoke the single key of earlier versions.
	 */
	public static function revoke_key() {
		delete_option( 'twdb_api_key_hash' );
		delete_option( 'twdb_api_key_hint' );
	}

	/**
	 * Constant time check of a presented key against the single key of earlier versions.
	 *
	 * @param string $key Presented key.
	 * @return bool
	 */
	public static function verify_key( $key ) {
		$stored = get_option( 'twdb_api_key_hash' );
		if ( ! is_string( $stored ) || '' === $stored || ! is_string( $key ) || '' === $key ) {
			return false;
		}
		return hash_equals( $stored, self::hash_key( $key ) );
	}

	/* ------------------------------------------------------------------
	 * Admin pages: Settings > TW Divi Builder, in four tabs.
	 * ---------------------------------------------------------------- */

	/**
	 * Tabs (slug => label).
	 *
	 * @return array
	 */
	public static function tabs() {
		return array(
			'connection' => __( 'Connection', 'tw-divi-builder' ),
			'people'     => __( 'Connected people', 'tw-divi-builder' ),
			'access'     => __( 'Access settings', 'tw-divi-builder' ),
			'selftest'   => __( 'Self-test', 'tw-divi-builder' ),
			'history'    => __( 'History', 'tw-divi-builder' ),
		);
	}

	/**
	 * Address of one tab.
	 *
	 * @param string $tab  Tab slug.
	 * @param array  $args Extra query args.
	 * @return string
	 */
	public static function page_url( $tab = 'connection', $args = array() ) {
		return add_query_arg(
			array_merge(
				array(
					'page' => self::PAGE_SLUG,
					'tab'  => $tab,
				),
				$args
			),
			admin_url( 'options-general.php' )
		);
	}

	/**
	 * Hook admin.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_twdb_save_settings', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_twdb_create_key', array( __CLASS__, 'handle_create_key' ) );
		add_action( 'admin_post_twdb_revoke_key_id', array( __CLASS__, 'handle_revoke_key_id' ) );
		add_action( 'admin_post_twdb_revoke_key', array( __CLASS__, 'handle_revoke_legacy_key' ) );
		add_action( 'admin_post_twdb_clear_log', array( __CLASS__, 'handle_clear_log' ) );
		add_action( 'admin_post_twdb_selftest', array( __CLASS__, 'handle_selftest' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( TWDB_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Settings link on the plugins screen.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::page_url() ) . '">' . esc_html__( 'Settings', 'tw-divi-builder' ) . '</a>' );
		return $links;
	}

	/**
	 * Settings-screen CSS and JS, loaded on that screen only.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public static function assets( $hook ) {
		if ( 'settings_page_' . self::PAGE_SLUG !== $hook ) {
			return;
		}
		wp_enqueue_style( 'twdb-admin', TWDB_URL . 'assets/twdb-admin.css', array(), TWDB_VERSION );
		wp_enqueue_script( 'twdb-admin', TWDB_URL . 'assets/twdb-admin.js', array(), TWDB_VERSION, true );
	}

	/**
	 * Register menu.
	 */
	public static function menu() {
		add_options_page(
			__( 'TW Divi Builder', 'tw-divi-builder' ),
			__( 'TW Divi Builder', 'tw-divi-builder' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Shared guard for admin-post handlers.
	 *
	 * @param string $action Nonce action.
	 */
	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'tw-divi-builder' ), 403 );
		}
		check_admin_referer( $action );
	}

	/**
	 * Redirect back to a tab.
	 *
	 * @param string $msg Message code.
	 * @param string $tab Tab.
	 */
	private static function back( $msg, $tab = 'connection' ) {
		wp_safe_redirect( self::page_url( $tab, array( 'twdb_msg' => $msg ) ) );
		exit;
	}

	// phpcs:disable WordPress.Security.NonceVerification.Missing -- Every handler below calls self::guard(), which checks manage_options and the nonce (check_admin_referer) before reading $_POST.

	/**
	 * Save settings.
	 */
	public static function handle_save() {
		self::guard( 'twdb_save_settings' );
		$settings = self::get();

		$user_id = isset( $_POST['acting_user'] ) ? absint( wp_unslash( $_POST['acting_user'] ) ) : 0;
		if ( $user_id && user_can( $user_id, 'edit_pages' ) && self::may_delegate( get_current_user_id(), $user_id ) ) {
			$settings['acting_user'] = $user_id;
		}
		$settings['read_only']           = ! empty( $_POST['read_only'] );
		$settings['allow_app_passwords'] = ! empty( $_POST['allow_app_passwords'] );
		$settings['allow_url_key']       = ! empty( $_POST['allow_url_key'] );
		$settings['allow_path_key']      = ! empty( $_POST['allow_path_key'] );
		$settings['helpers']             = ! empty( $_POST['helpers'] );
		$settings['allow_oauth']         = ! empty( $_POST['allow_oauth'] );

		$valid_groups       = array_keys( TWDB_Tools::groups() );
		$groups             = isset( $_POST['groups'] ) && is_array( $_POST['groups'] ) ? array_map( 'sanitize_key', wp_unslash( $_POST['groups'] ) ) : array();
		$settings['groups'] = array_values( array_intersect( $valid_groups, $groups ) );

		TWDB_Plugin::save_settings( $settings );
		TWDB_Audit_Log::$via   = 'admin';
		TWDB_Audit_Log::$actor = '';
		TWDB_Audit_Log::add(
			'settings.save',
			array(
				'read_only'   => $settings['read_only'],
				'acting_user' => $settings['acting_user'],
				'groups'      => $settings['groups'],
				'oauth'       => $settings['allow_oauth'],
				'key_in_url'  => $settings['allow_path_key'],
			),
			true,
			'Settings saved in WP Admin'
		);
		self::back( 'saved', 'access' );
	}

	/**
	 * Create a named connector key.
	 */
	public static function handle_create_key() {
		self::guard( 'twdb_create_key' );
		$name   = isset( $_POST['key_name'] ) ? sanitize_text_field( wp_unslash( $_POST['key_name'] ) ) : '';
		$result = TWDB_Keys::create( $name );
		if ( is_wp_error( $result ) ) {
			self::back( 'too_many_keys' );
		}
		set_transient(
			'twdb_new_key_' . get_current_user_id(),
			array(
				'key'  => $result['key'],
				'name' => '' !== $name ? $name : 'Connector key',
			),
			10 * MINUTE_IN_SECONDS
		);
		TWDB_Audit_Log::$via   = 'admin';
		TWDB_Audit_Log::$actor = '';
		TWDB_Audit_Log::add( 'settings.create_key', array( 'name' => $name ), true, 'Connector key created' );
		self::back( 'key' );
	}

	/**
	 * Revoke one named key.
	 */
	public static function handle_revoke_key_id() {
		self::guard( 'twdb_revoke_key_id' );
		$id = isset( $_POST['key_id'] ) ? sanitize_key( wp_unslash( $_POST['key_id'] ) ) : '';
		if ( TWDB_Keys::revoke( $id ) ) {
			TWDB_Audit_Log::$via   = 'admin';
			TWDB_Audit_Log::$actor = '';
			TWDB_Audit_Log::add( 'settings.revoke_key', array( 'id' => $id ), true, 'Connector key revoked' );
		}
		self::back( 'key_revoked' );
	}

	/**
	 * Revoke the single key of earlier versions.
	 */
	public static function handle_revoke_legacy_key() {
		self::guard( 'twdb_revoke_key' );
		self::revoke_key();
		TWDB_Audit_Log::$via   = 'admin';
		TWDB_Audit_Log::$actor = '';
		TWDB_Audit_Log::add( 'settings.revoke_key', array( 'legacy' => true ), true, 'Legacy API key revoked' );
		self::back( 'key_revoked' );
	}

	/**
	 * Run the self-test and show the results on the Self-test tab.
	 */
	public static function handle_selftest() {
		self::guard( 'twdb_selftest' );
		set_transient( 'twdb_selftest_' . get_current_user_id(), TWDB_Diagnostics::run(), 5 * MINUTE_IN_SECONDS );
		self::back( 'selftest', 'selftest' );
	}

	/**
	 * Clear log.
	 */
	public static function handle_clear_log() {
		self::guard( 'twdb_clear_log' );
		TWDB_Audit_Log::clear();
		self::back( 'log_cleared', 'history' );
	}

	// phpcs:enable WordPress.Security.NonceVerification.Missing

	/**
	 * Tags allowed in the guide steps (they are written in this plugin, but escaped output is the habit).
	 *
	 * @return array
	 */
	public static function allowed_html() {
		return array(
			'b'    => array(),
			'i'    => array(),
			'code' => array(),
			'br'   => array(),
			'pre'  => array( 'class' => true ),
		);
	}

	/**
	 * Step-by-step guides for each AI app, for both ways of signing in.
	 *
	 * Steps are HTML written here (never user input); addresses are escaped before they are put in.
	 *
	 * @param string $oauth_url Address with no key (sign in with WordPress).
	 * @param string $key_url   Address with the key inside.
	 * @param string $raw_key   The key itself (or a placeholder), for header-based setups.
	 * @return array
	 */
	public static function guides( $oauth_url, $key_url, $raw_key ) {
		$o = '<code>' . esc_html( $oauth_url ) . '</code>';
		$k = '<code>' . esc_html( $key_url ) . '</code>';
		$r = esc_html( $raw_key );

		$needs = ' <b>' . __( 'Needs "Keys inside the connector address" turned on under Access settings: read the warning there, and prefer Sign in with WordPress or a header when the app supports it.', 'tw-divi-builder' ) . '</b>';

		$allow = __( 'A window opens on this site: sign in with an administrator account and press <b>Allow</b>.', 'tw-divi-builder' );

		$json_oauth = wp_json_encode(
			array( 'mcpServers' => array( 'tw-divi-builder' => array( 'url' => $oauth_url ) ) ),
			JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
		);
		$json_key   = wp_json_encode(
			array(
				'mcpServers' => array(
					'tw-divi-builder' => array(
						'url'     => $oauth_url,
						'headers' => array( 'Authorization' => 'Bearer ' . $raw_key ),
					),
				),
			),
			JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
		);
		$gemini_o   = wp_json_encode( array( 'mcpServers' => array( 'tw-divi' => array( 'httpUrl' => $oauth_url ) ) ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		$gemini_k   = wp_json_encode( array( 'mcpServers' => array( 'tw-divi' => array( 'httpUrl' => $key_url ) ) ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		$bridge     = wp_json_encode(
			array(
				'mcpServers' => array(
					'tw-divi-builder' => array(
						'command' => 'npx',
						'args'    => array( '-y', 'mcp-remote', $oauth_url, '--header', 'Authorization:${TWDB_AUTH}' ),
						'env'     => array( 'TWDB_AUTH' => 'Bearer ' . $raw_key ),
					),
				),
			),
			JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
		);

		$hname         = substr( trim( preg_replace( '/[^A-Za-z0-9_-]+/', '-', 'divi5-' . strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) . (string) wp_parse_url( home_url(), PHP_URL_PATH ) ) ), '-' ), 0, 32 ); // Harness: [A-Za-z0-9_-], max 32.
		$yaml          = "- insert:\n    - id: mcp-{$hname}\n      name: '@deepseek-ai/dsh-mcp-client'\n      config:\n        serverName: {$hname}\n        transport: streamable-http\n        url: {$oauth_url}\n        headers:\n          Authorization: !!js process.env.TWDB_AUTH";
		$envs          = "# Windows PowerShell\n\$env:TWDB_AUTH = \"Bearer {$raw_key}\"\ndsh web\n\n# Windows, keep it permanently (reopen the terminal afterwards)\nsetx TWDB_AUTH \"Bearer {$raw_key}\"\n\n# macOS / Linux\nexport TWDB_AUTH=\"Bearer {$raw_key}\"\ndsh web";
		$harness_steps = array(
			__( 'Open <code>~/.dsh/profiles/web/cordis.patch.yml</code> (Windows: <code>C:\\Users\\YOU\\.dsh\\profiles\\web\\cordis.patch.yml</code>) and add this. The key is not stored in the file: it is read from the <code>TWDB_AUTH</code> environment variable.', 'tw-divi-builder' ) . '<pre class="twdb-pre">' . esc_html( $yaml ) . '</pre>',
			__( 'Set the key in the same terminal you start Harness from, then start it:', 'tw-divi-builder' ) . '<pre class="twdb-pre">' . esc_html( $envs ) . '</pre>',
			__( 'Check with <code>dsh web --dump-config</code>. The tools appear as <code>mcp__NAME__tool_name</code>. If it fails to load, check that <code>transport</code> is exactly <code>streamable-http</code> and the address has no trailing slash.', 'tw-divi-builder' ),
		);

		return array(
			'claude'     => array(
				'label' => 'Claude',
				'sub'   => 'claude.ai & Desktop',
				'oauth' => array(
					__( 'In Claude open <b>Customize &rarr; Connectors</b> (older versions: <b>Settings &rarr; Connectors</b>) and choose <b>Add custom connector</b>. On a Team or Enterprise plan an Owner adds it first under Organization settings &rarr; Connectors.', 'tw-divi-builder' ),
					sprintf( /* translators: %s: address */ __( 'Give it a name (for example <i>Tech Webers Divi</i>) and paste %s as the address. <b>Leave the OAuth client ID and secret fields empty</b>: Claude registers itself with this site.', 'tw-divi-builder' ), $o ),
					__( 'Press <b>Add</b>, then <b>Connect</b>.', 'tw-divi-builder' ) . ' ' . $allow,
					__( 'In a chat, use the <b>+</b> button &rarr; <b>Connectors</b>, switch it on, and ask Claude to build something.', 'tw-divi-builder' ),
				),
				'key'   => array(
					__( 'In Claude open <b>Customize &rarr; Connectors</b> and choose <b>Add custom connector</b>.', 'tw-divi-builder' ),
					sprintf( /* translators: %s: address */ __( 'Paste %s as the address and leave the OAuth fields empty. The key is part of the address, so there is no sign-in.', 'tw-divi-builder' ), $k ) . $needs,
					__( 'Press <b>Add</b>, switch the connector on in a chat, and ask Claude to build something.', 'tw-divi-builder' ),
				),
			),
			'claudecode' => array(
				'label' => 'Claude Code',
				'sub'   => 'terminal',
				'oauth' => array(
					'<code>claude mcp add --scope user --transport http tw-divi ' . esc_html( $oauth_url ) . '</code>',
					__( 'Start Claude Code, type <code>/mcp</code>, choose <b>tw-divi</b> and pick <b>Authenticate</b>.', 'tw-divi-builder' ) . ' ' . $allow,
				),
				'key'   => array(
					'<code>claude mcp add --scope user --transport http tw-divi ' . esc_html( $oauth_url ) . ' --header "Authorization: Bearer ' . $r . '"</code>',
					__( 'Restart Claude Code and run <code>/mcp</code> to check that it shows as connected. The key stays in your local config file, not in the address.', 'tw-divi-builder' ),
				),
			),
			'chatgpt'    => array(
				'label' => 'ChatGPT',
				'sub'   => 'developer mode',
				'oauth' => array(
					__( 'In ChatGPT turn on developer mode and add a custom MCP connector. Menu names change often, so look for the option to add an MCP server by address.', 'tw-divi-builder' ),
					sprintf( /* translators: %s: address */ __( 'Paste %s as the address and choose <b>OAuth</b> as the sign-in.', 'tw-divi-builder' ), $o ),
					$allow,
				),
				'key'   => array(
					__( 'In ChatGPT turn on developer mode and add a custom MCP connector.', 'tw-divi-builder' ),
					sprintf( /* translators: %s: address */ __( 'Paste %s as the address and choose <b>No authentication</b>. The key in the address is the sign-in.', 'tw-divi-builder' ), $k ) . $needs,
				),
			),
			'codex'      => array(
				'label' => 'Codex',
				'sub'   => 'OpenAI',
				'oauth' => array(
					'<code>codex mcp add tw-divi --url ' . esc_html( $oauth_url ) . '</code>',
					__( 'Then run <code>codex mcp login tw-divi</code>.', 'tw-divi-builder' ) . ' ' . $allow . ' ' . __( 'If your Codex version has no <code>login</code> command, use the connector key route instead.', 'tw-divi-builder' ),
				),
				'key'   => array(
					'<code>codex mcp add tw-divi --url ' . esc_html( $key_url ) . '</code>' . $needs,
					__( 'Restart Codex. Needs a Codex version that supports remote (HTTP) MCP servers.', 'tw-divi-builder' ),
				),
			),
			'gemini'     => array(
				'label' => 'Gemini CLI',
				'sub'   => 'and Antigravity',
				'oauth' => array(
					__( 'Add this to <code>~/.gemini/settings.json</code>:', 'tw-divi-builder' ) . '<pre class="twdb-pre">' . esc_html( $gemini_o ) . '</pre>',
					__( 'Start Gemini CLI and run <code>/mcp auth tw-divi</code>.', 'tw-divi-builder' ) . ' ' . $allow . ' ' . __( 'Antigravity cannot sign in yet: use the connector key for it.', 'tw-divi-builder' ),
				),
				'key'   => array(
					__( 'Add this to <code>~/.gemini/settings.json</code>:', 'tw-divi-builder' ) . '<pre class="twdb-pre">' . esc_html( $gemini_k ) . '</pre>' . $needs,
					__( 'Restart Gemini CLI.', 'tw-divi-builder' ),
				),
			),
			'harness'    => array(
				'label' => 'DeepSeek Harness',
				'sub'   => 'dsh',
				'oauth' => array_merge(
					array( __( '<b>Harness cannot sign in with WordPress.</b> Its built-in MCP client sends a fixed header, so use a connector key: press <b>Use a connector key</b> above and create one.', 'tw-divi-builder' ) ),
					$harness_steps
				),
				'key'   => $harness_steps,
			),
			'other'      => array(
				'label' => 'Any MCP app',
				'sub'   => 'Cursor, Cline, Zed',
				'oauth' => array(
					__( 'Add a remote (HTTP) MCP server and use this address. Apps that support MCP sign-in will offer it when they connect:', 'tw-divi-builder' ) . '<pre class="twdb-pre">' . esc_html( $json_oauth ) . '</pre>',
					$allow . ' ' . __( 'If the app has no sign-in flow, use the connector key route.', 'tw-divi-builder' ),
				),
				'key'   => array(
					__( 'Apps that can send headers:', 'tw-divi-builder' ) . '<pre class="twdb-pre">' . esc_html( $json_key ) . '</pre>',
					__( 'Apps that only take an address: use', 'tw-divi-builder' ) . ' ' . $k . '.' . $needs,
					__( 'Claude Desktop through the local <code>mcp-remote</code> bridge (needs Node.js), in <code>claude_desktop_config.json</code>:', 'tw-divi-builder' ) . '<pre class="twdb-pre">' . esc_html( $bridge ) . '</pre>',
				),
			),
		);
	}

	/**
	 * Render the settings screen.
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$tabs = self::tabs();
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'connection'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'connection';
		}
		$msg      = isset( $_GET['twdb_msg'] ) ? sanitize_key( wp_unslash( $_GET['twdb_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$settings = self::get();
		$divi     = TWDB_Divi::status();
		$endpoint = rest_url( TWDB_REST_NS . '/mcp' );

		// The key just made: shown once.
		$new = get_transient( 'twdb_new_key_' . get_current_user_id() );
		if ( $new ) {
			delete_transient( 'twdb_new_key_' . get_current_user_id() );
		}
		$raw_key = is_array( $new ) ? $new['key'] : 'YOUR_KEY';
		$key_url = $endpoint . '/' . $raw_key;

		$selftest = get_transient( 'twdb_selftest_' . get_current_user_id() );
		if ( $selftest ) {
			delete_transient( 'twdb_selftest_' . get_current_user_id() );
		}

		$keys        = TWDB_Keys::all();
		$legacy_hint = get_option( 'twdb_api_key_hint' );
		$legacy_on   = is_string( get_option( 'twdb_api_key_hash' ) ) && '' !== get_option( 'twdb_api_key_hash' );
		$guides      = self::guides( $endpoint, $key_url, $raw_key );
		$oauth_on    = TWDB_OAuth::enabled();
		$people      = TWDB_OAuth::connections();
		$log         = TWDB_Audit_Log::all();
		$users       = get_users(
			array(
				'capability' => 'edit_pages',
				'orderby'    => 'display_name',
				'number'     => 200,
			)
		);
		$subfolder   = TWDB_OAuth::in_subfolder();
		// The sign-in documents this install can answer (the ones that live under its own address).
		$home      = wp_parse_url( home_url( '/' ) );
		$origin    = $home['scheme'] . '://' . $home['host'] . ( isset( $home['port'] ) ? ':' . $home['port'] : '' );
		$home_path = rtrim( isset( $home['path'] ) ? $home['path'] : '', '/' );
		$checks    = array();
		foreach ( array_keys( TWDB_OAuth::well_known_paths() ) as $path ) {
			if ( '' === $home_path || 0 === strpos( $path, $home_path . '/' ) ) {
				$checks[] = $origin . $path;
			}
		}
		$checks = array_slice( array_values( array_unique( $checks ) ), 0, 6 );

		require TWDB_DIR . 'admin/settings-page.php';
	}
}
