<?php
/**
 * One-click self-test shown on the settings page. Added in the merged build.
 *
 * Runs real tool calls (as the logged-in administrator) and cleans up after itself.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Diagnostics.
 */
class TWDB_Diagnostics {

	/**
	 * Run the checks.
	 *
	 * @return array[] Rows: { name, status (ok|fail|skip), detail }.
	 */
	public static function run() {
		$rows = array();
		$add  = static function ( $name, $status, $detail ) use ( &$rows ) {
			$rows[] = array(
				'name'   => $name,
				'status' => $status,
				'detail' => TWDB_Text::substr( is_string( $detail ) ? $detail : (string) wp_json_encode( $detail ), 0, 500 ),
			);
		};
		$call = static function ( $tool, $args = array() ) {
			return TWDB_Tools::call( $tool, $args );
		};
		$fail = static function ( $res ) {
			return $res['error']['code'] . ': ' . $res['error']['message'];
		};

		TWDB_Audit_Log::$via = 'self_test';
		$divi                = TWDB_Divi::status();
		$add( 'Divi detected', $divi['is_divi5'] ? 'ok' : ( $divi['active'] ? 'fail' : 'skip' ), $divi['active'] ? $divi['product'] . ' ' . $divi['version'] : 'Divi is not active; Divi-only checks are skipped.' );

		$gd = '\ET\Builder\Packages\GlobalData\GlobalData';
		if ( $divi['active'] ) {
			$add( 'Divi GlobalData API', class_exists( $gd ) && method_exists( $gd, 'set_global_colors' ) && method_exists( $gd, 'set_global_variables' ) ? 'ok' : 'fail', class_exists( $gd ) ? 'get/set_global_colors and get/set_global_variables found' : 'GlobalData class not found; the fallback option storage will be used (unverified).' );
		}

		$r = $call( 'site_info' );
		$add( 'site_info', $r['ok'] ? 'ok' : 'fail', $r['ok'] ? 'Acting user and versions read.' : $fail( $r ) );

		// Page round trip.
		$v      = TWDB_Divi::builder_version();
		$markup = '<!-- wp:divi/placeholder --><!-- wp:divi/section {"builderVersion":"' . $v . '"} --><!-- wp:divi/row {"builderVersion":"' . $v . '"} --><!-- wp:divi/column {"builderVersion":"' . $v . '"} -->'
			. '<!-- wp:divi/heading {"title":{"innerContent":{"desktop":{"value":"Self-test heading"}}},"builderVersion":"' . $v . '"} /-->'
			. '<!-- /wp:divi/column --><!-- /wp:divi/row --><!-- /wp:divi/section --><!-- /wp:divi/placeholder -->';
		$r      = $call(
			'create_page',
			array(
				'title'   => 'TWDB self-test (safe to delete)',
				'content' => $markup,
			)
		);
		$id     = 0;
		if ( ! $r['ok'] ) {
			$add( 'create_page', 'fail', $fail( $r ) );
		} else {
			$id = (int) $r['data']['id'];
			$add( 'create_page', 'ok', 'Draft #' . $id . ' created.' );

			$t = $call( 'get_page_tree', array( 'id' => $id ) );
			$add( 'get_page_tree', $t['ok'] ? 'ok' : 'fail', $t['ok'] ? 'Tree read (section > row > column > heading).' : $fail( $t ) );

			$e = $call(
				'edit_page_modules',
				array(
					'id'  => $id,
					'ops' => array(
						array(
							'op'    => 'edit',
							'path'  => array( 0, 0, 0, 0 ),
							'attrs' => array( 'title' => array( 'innerContent' => array( 'desktop' => array( 'value' => 'Edited by self-test' ) ) ) ),
						),
					),
				)
			);
			$add( 'edit_page_modules', $e['ok'] ? 'ok' : 'fail', $e['ok'] ? $e['data']['message'] : $fail( $e ) );

			$g   = $call( 'get_page', array( 'id' => $id ) );
			$has = $g['ok'] && false !== strpos( wp_json_encode( $g['data'] ), 'Edited by self-test' );
			$add( 'Edit saved', $has ? 'ok' : 'fail', $has ? 'New heading text is stored.' : 'The edited text was not found in the stored page.' );

			if ( $divi['active'] ) {
				$rd   = $call(
					'render_page',
					array(
						'id'   => $id,
						'mode' => 'full',
					)
				);
				$seen = $rd['ok'] && false !== strpos( (string) $rd['data']['html'], 'Edited by self-test' );
				$add( 'render_page (front-end)', $seen ? 'ok' : 'fail', $rd['ok'] ? ( $seen ? 'HTTP ' . $rd['data']['http_status'] . ', heading rendered.' : 'Page loaded (HTTP ' . $rd['data']['http_status'] . ') but the heading was not in the HTML. ' . implode( ' ', (array) $rd['data']['notes'] ) ) : $fail( $rd ) );
			}
			$b = $call( 'list_backups', array( 'id' => $id ) );
			$add( 'Restore points', $b['ok'] && ! empty( $b['data']['backups'] ) ? 'ok' : 'fail', $b['ok'] ? count( $b['data']['backups'] ) . ' restore point(s) saved.' : $fail( $b ) );
		}

		// Design system round trip.
		if ( $divi['is_divi5'] ) {
			$cid = 'gcid-twdb-selftest';
			$r   = $call(
				'set_global_colors',
				array(
					'colors' => array(
						array(
							'id'    => $cid,
							'label' => 'TWDB Self-test',
							'color' => '#ff3366',
						),
					),
				)
			);
			if ( ! $r['ok'] ) {
				$add( 'set_global_colors', 'fail', $fail( $r ) );
			} else {
				$ds    = $call( 'get_design_system' );
				$found = false;
				if ( $ds['ok'] ) {
					foreach ( $ds['data']['colors'] as $c ) {
						if ( $c['id'] === $cid ) {
							$found = true;
						}
					}
				}
				$add( 'Global color saved + read back', $found ? 'ok' : 'fail', $found ? 'Check Divi: Global Colors should list "TWDB Self-test" until removed below.' : 'Saved but not found when reading back.' );
				$d = $call(
					'delete_global_color',
					array(
						'id'        => $cid,
						'permanent' => true,
					)
				);
				$add( 'Global color cleanup', $d['ok'] ? 'ok' : 'fail', $d['ok'] ? 'Test color removed.' : $fail( $d ) );
			}
			$vid = 'gvid-twdb-selftest';
			$r   = $call(
				'set_global_variables',
				array(
					'variables' => array(
						array(
							'id'    => $vid,
							'type'  => 'numbers',
							'label' => 'TWDB Self-test size',
							'value' => 'clamp(1rem, 2vw, 2rem)',
						),
					),
				)
			);
			if ( ! $r['ok'] ) {
				$add( 'set_global_variables', 'fail', $fail( $r ) );
			} else {
				$vars  = TWDB_Divi::get_global_variables();
				$found = isset( $vars['numbers'][ $vid ] );
				$add( 'Global variable saved + read back', $found ? 'ok' : 'fail', $found ? 'Stored in Divi.' : 'Saved but not found when reading back.' );
				$d = $call( 'set_global_variables', array( 'delete_ids' => array( $vid ) ) );
				$add( 'Global variable cleanup', $d['ok'] ? 'ok' : 'fail', $d['ok'] ? 'Test variable removed.' : $fail( $d ) );
			}
			$p = $call( 'list_presets' );
			$add( 'Presets readable', $p['ok'] ? 'ok' : 'fail', $p['ok'] ? 'Presets read.' : $fail( $p ) );
			$t = $call( 'list_templates' );
			$add( 'Theme Builder readable', $t['ok'] ? 'ok' : 'fail', $t['ok'] ? 'Templates listed.' : $fail( $t ) );
		}

		// Cleanup the test page (and its restore points).
		if ( $id ) {
			foreach ( get_posts(
				array(
					'post_type'      => TWDB_Backups::POST_TYPE,
					'post_status'    => 'private',
					'post_parent'    => $id,
					'posts_per_page' => -1,
					'fields'         => 'ids',
				)
			) as $bid ) {
				wp_delete_post( $bid, true );
			}
			wp_delete_post( $id, true );
			$add( 'Cleanup', 'ok', 'Test page and its restore points deleted.' );
		}
		TWDB_Audit_Log::$via = 'admin';
		return $rows;
	}
}
