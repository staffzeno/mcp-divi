<?php
/**
 * get_divi_reference tool: serves the bundled Divi 5 reference docs (see THIRD-PARTY-NOTICES.txt).
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reference tools.
 */
class TWDB_Tools_Reference {

	/**
	 * Topic => [file, summary].
	 *
	 * @return array
	 */
	public static function topics() {
		return array(
			'plugin-guide'        => array( 'TW-TOOLS-GUIDE.md', 'How this plugin\'s tools map to the Divi 5 workflow (read with "rules").' ),
			'skill'               => array( 'SKILL.md', 'Overview, mandatory build workflow, critical markup rules, which file to read when.' ),
			'rules'               => array( 'DIVI5-BASE.md', 'Core block-markup rules, nesting, validation, common mistakes. Read first.' ),
			'house-rules'         => array( 'DIVI5-HOUSE-RULES.md', 'THE OWNER\'S DEFAULTS - read before writing markup: section/row padding and width, 16px gaps, equal cards, tabs, no look-alike sections, mobile menu, uploaded designs copied exactly.' ),
			'mockup'              => array( 'DIVI5-MOCKUP-FIDELITY.md', 'USER SUPPLIED A MOCKUP / FIGMA / PDF / HTML: build it exactly (99% target) with native modules, then measure and fix. Read this instead of design-process.' ),
			'design-process'      => array( 'DIVI5-DESIGN-PROCESS.md', 'Discovery questions, page planning and approval before markup.' ),
			'page-from-html'      => array( 'DIVI5-PAGE-FROM-HTML.md', 'Design a new page as HTML first, then compose it in Divi.' ),
			'connect'             => array( 'DIVI5-CONNECT.md', 'Live-site workflow and design-token discipline (written for Divi Connect; endpoints map to this plugin\'s tools).' ),
			'wordpress'           => array( 'DIVI5-WORDPRESS.md', 'Required page meta, templates, Theme Builder wiring, Canvas.' ),
			'layout'              => array( 'DIVI5-LAYOUT.md', 'Sections, rows, columns, groups, grid, Components (global-layout / global-slot).' ),
			'styling'             => array( 'DIVI5-STYLING.md', 'Backgrounds, gradients, spacing, borders, typography, variables and tokens.' ),
			'animation'           => array( 'DIVI5-ANIMATION.md', 'Entrance animations, scroll effects, sticky, transforms.' ),
			'modules-content'     => array( 'DIVI5-MODULES-CONTENT.md', 'Heading, text, button, image, blurb, CTA, testimonial, icon, divider, code, etc.' ),
			'modules-interactive' => array( 'DIVI5-MODULES-INTERACTIVE.md', 'Accordion, toggle, tabs, contact form, signup, dropdown.' ),
			'modules-media'       => array( 'DIVI5-MODULES-MEDIA.md', 'Video, gallery, slider, audio, lottie, before/after.' ),
			'modules-data'        => array( 'DIVI5-MODULES-DATA.md', 'Counters, pricing tables, social follow, TOC, charts.' ),
			'modules-dynamic'     => array( 'DIVI5-MODULES-DYNAMIC.md', 'Blog, portfolio, post modules, menu, search, Loop Builder, Theme Builder via PHP.' ),
			'modules-woocommerce' => array( 'DIVI5-MODULES-WOOCOMMERCE.md', 'Shop, product, cart and checkout modules.' ),
			'presets'             => array( 'DIVI5-PRESETS.md', 'Global presets: storage, module vs group presets, attrs paths.' ),
			'patterns'            => array( 'DIVI5-PATTERNS.md', 'Real-world section patterns and generation helpers.' ),
			'coverage'            => array( 'DIVI5-COVERAGE.md', 'What is render-confirmed, source-verified or untested.' ),
			'caveats'             => array( 'KNOWN-CAVEATS.md', 'Known limits and silent failures.' ),
			'custom-modules'      => array( 'DIVI5-CUSTOM-MODULES.md', 'Building custom Divi 5 modules (developer topic).' ),
			'module-template'     => array( 'MODULE-TEMPLATE.md', 'Template used to document a module.' ),
			'workflow'            => array( 'WORKFLOW.md', 'Short workflow summary.' ),
		);
	}

	/**
	 * Definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return array(
			array(
				'name'         => 'get_divi_reference',
				'group'        => 'site',
				'title'        => 'Divi 5 reference docs',
				'description'  => 'Returns the bundled Divi 5 authoring reference (for Divi 5.16) so you can write valid Divi 5 block markup. Call with topic "index" to list topics, then "rules" (DIVI5-BASE) before writing any markup. Use "search" to return only the sections of a topic that mention a term, and offset/max_chars to page through long topics.',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'topic'     => TWDB_Tools::prop(
							'string',
							'Topic key, or "index" to list all topics.',
							array(
								'enum'    => array_merge( array( 'index' ), array_keys( self::topics() ) ),
								'default' => 'index',
							)
						),
						'search'    => TWDB_Tools::prop( 'string', 'Optional term: return only "##" sections containing it (case-insensitive). With topic "index", searches all topics.' ),
						'offset'    => TWDB_Tools::prop(
							'integer',
							'Character offset to start from (for paging).',
							array(
								'minimum' => 0,
								'default' => 0,
							)
						),
						'max_chars' => TWDB_Tools::prop(
							'integer',
							'Maximum characters to return (default 40000, max 120000).',
							array(
								'minimum' => 1000,
								'maximum' => 120000,
								'default' => 40000,
							)
						),
					),
				),
				'callback'     => array( __CLASS__, 'get_reference' ),
			),
		);
	}

	/**
	 * Read a doc file.
	 *
	 * @param string $file File.
	 * @return string
	 */
	private static function read( $file ) {
		$path = TWDB_DIR . 'reference/' . basename( $file );
		if ( ! is_readable( $path ) ) {
			return '';
		}
		return (string) file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local bundled file.
	}

	/**
	 * Sections of a markdown doc that contain a term.
	 *
	 * @param string $doc  Doc.
	 * @param string $term Term.
	 * @return string[]
	 */
	private static function sections_matching( $doc, $term ) {
		$parts = preg_split( '/(?=^##\s)/m', $doc );
		$out   = array();
		foreach ( (array) $parts as $part ) {
			if ( false !== stripos( $part, $term ) ) {
				$out[] = trim( $part );
			}
		}
		return $out;
	}

	/**
	 * Tool: get_divi_reference.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On bad topic.
	 */
	public static function get_reference( $args ) {
		$topic  = isset( $args['topic'] ) ? $args['topic'] : 'index';
		$search = isset( $args['search'] ) ? trim( (string) $args['search'] ) : '';
		$offset = isset( $args['offset'] ) ? max( 0, (int) $args['offset'] ) : 0;
		$max    = isset( $args['max_chars'] ) ? max( 1000, min( 120000, (int) $args['max_chars'] ) ) : 40000;
		$topics = self::topics();

		if ( 'index' === $topic && '' === $search ) {
			$list = array();
			foreach ( $topics as $key => $info ) {
				$list[] = array(
					'topic'   => $key,
					'file'    => $info[0],
					'summary' => $info[1],
					'chars'   => strlen( self::read( $info[0] ) ),
				);
			}
			return array(
				'source' => 'Bundled Divi 5 reference (Divi 5.16), Tech Webers MCP Builder for Divi 5 by Deepak Juneja - https://www.techwebers.com/',
				'topics' => $list,
				'advice' => 'Read "rules" first, then "layout", "styling" and the module topics you need. Use "connect" for token discipline.',
			);
		}

		if ( 'index' === $topic ) {
			$text = '';
			foreach ( $topics as $key => $info ) {
				$hits = self::sections_matching( self::read( $info[0] ), $search );
				if ( $hits ) {
					$text .= "\n\n=== topic: {$key} ===\n\n" . implode( "\n\n", $hits );
				}
			}
		} else {
			if ( ! isset( $topics[ $topic ] ) ) {
				throw new TWDB_Tool_Error( 'invalid_topic', 'Unknown topic. Call with topic "index".' );
			}
			$doc  = self::read( $topics[ $topic ][0] );
			$text = '' === $search ? $doc : implode( "\n\n", self::sections_matching( $doc, $search ) );
		}

		$total = strlen( $text );
		// UTF-8 safe even without mbstring. The next page starts exactly where this one ended, so pages never
		// overlap or skip text; an offset inside a character starts at the next whole character. max_chars is
		// at least 1000 bytes (far above TWDB_Text::MIN_PAGE_BYTES), and next_offset() returns null rather than
		// an offset that would not advance, so a client paging on next_offset always finishes.
		$next  = TWDB_Text::next_offset( $text, $offset, $max );
		$chunk = TWDB_Text::cut( $text, $offset, $max );
		return array(
			'topic'       => $topic,
			'search'      => $search,
			'total_chars' => $total,
			'offset'      => $offset,
			'next_offset' => $next,
			'content'     => '' === $chunk ? '(no matching content)' : $chunk,
			'license'     => 'MIT License (see reference/LICENSE-reference-docs.txt)',
		);
	}
}
