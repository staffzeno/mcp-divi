<?php
/**
 * site_info tool.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Site tools.
 */
class TWDB_Tools_Site {

	/**
	 * Definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return array(
			array(
				'name'         => 'site_info',
				'group'        => 'site',
				'title'        => 'Site info',
				'description'  => 'Returns WordPress, PHP and Divi versions, active theme, active plugins, front page / posts page settings, menu locations, the builderVersion to stamp on markup, which SEO plugin is active and the capabilities of the user the AI acts as. Call this first.',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(),
				),
				'callback'     => array( __CLASS__, 'site_info' ),
			),
			array(
				'name'         => 'set_front_page',
				'group'        => 'settings',
				'title'        => 'Set front page',
				'description'  => 'Sets Settings > Reading so the homepage shows a static page (page_id), or the latest posts (page_id 0). Confirm with the user first - this changes the live homepage.',
				'write'        => true,
				'capability'   => 'manage_options',
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'page_id' ),
					'properties' => array(
						'page_id' => TWDB_Tools::prop( 'integer', 'Published page ID, or 0 for latest posts.', array( 'minimum' => 0 ) ),
					),
				),
				'callback'     => array( __CLASS__, 'set_front_page' ),
			),
			array(
				'name'         => 'set_posts_page',
				'group'        => 'settings',
				'title'        => 'Set posts page',
				'description'  => 'Sets the page that lists blog posts (Settings > Reading > Posts page), or unsets it with page_id 0. Only applies when the homepage is a static page.',
				'write'        => true,
				'capability'   => 'manage_options',
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'page_id' ),
					'properties' => array(
						'page_id' => TWDB_Tools::prop( 'integer', 'Page ID, or 0 to unset.', array( 'minimum' => 0 ) ),
					),
				),
				'callback'     => array( __CLASS__, 'set_posts_page' ),
			),
		);
	}

	/**
	 * Detect SEO plugin.
	 *
	 * @return string yoast|rankmath|''
	 */
	public static function seo_plugin() {
		if ( defined( 'WPSEO_VERSION' ) ) {
			return 'yoast';
		}
		if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
			return 'rankmath';
		}
		return '';
	}

	/**
	 * Tool: site_info.
	 *
	 * @return array
	 */
	public static function site_info() {
		global $wp_version;
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$active  = (array) get_option( 'active_plugins', array() );
		$plugins = array();
		$all     = get_plugins();
		if ( ! current_user_can( 'activate_plugins' ) ) {
			$active = array(); // The plugin inventory is for users who manage plugins.
		}
		foreach ( $active as $file ) {
			if ( isset( $all[ $file ] ) ) {
				$plugins[] = array(
					'name'    => $all[ $file ]['Name'],
					'version' => $all[ $file ]['Version'],
					'file'    => $file,
				);
			}
		}
		$theme = wp_get_theme();
		$user  = wp_get_current_user();
		$front = (int) get_option( 'page_on_front' );
		$posts = (int) get_option( 'page_for_posts' );
		$locs  = array();
		foreach ( get_registered_nav_menus() as $loc => $label ) {
			$assigned = get_nav_menu_locations();
			$locs[]   = array(
				'location' => $loc,
				'label'    => $label,
				'menu_id'  => isset( $assigned[ $loc ] ) ? (int) $assigned[ $loc ] : 0,
			);
		}
		$settings = TWDB_Settings::get();
		$divi     = TWDB_Divi::status();
		return array(
			'site'               => array(
				'name'       => get_bloginfo( 'name' ),
				'tagline'    => get_bloginfo( 'description' ),
				'home_url'   => home_url( '/' ),
				'site_url'   => site_url( '/' ),
				'language'   => get_locale(),
				'timezone'   => wp_timezone_string(),
				'permalinks' => (string) get_option( 'permalink_structure' ),
			),
			'versions'           => array(
				'wordpress' => $wp_version,
				'php'       => current_user_can( 'manage_options' ) ? PHP_VERSION : '',
				'plugin'    => TWDB_VERSION,
			),
			'divi'               => array_merge( $divi, array( 'builder_version_to_use' => TWDB_Divi::builder_version() ) ),
			'theme'              => array(
				'name'     => $theme->get( 'Name' ),
				'version'  => $theme->get( 'Version' ),
				'template' => $theme->get_template(),
				'is_child' => (bool) $theme->parent(),
			),
			'active_plugins'     => $plugins,
			'reading'            => array(
				'show_on_front' => get_option( 'show_on_front' ),
				'front_page'    => $front ? array(
					'id'    => $front,
					'title' => html_entity_decode( get_the_title( $front ), ENT_QUOTES, 'UTF-8' ),
				) : null,
				'posts_page'    => $posts ? array(
					'id'    => $posts,
					'title' => html_entity_decode( get_the_title( $posts ), ENT_QUOTES, 'UTF-8' ),
				) : null,
			),
			'menu_locations'     => $locs,
			'seo_plugin'         => self::seo_plugin(),
			'acting_user'        => array(
				'id'                 => $user->ID,
				'login'              => $user->user_login,
				'roles'              => array_values( $user->roles ),
				'unfiltered_html'    => current_user_can( 'unfiltered_html' ),
				'manage_options'     => current_user_can( 'manage_options' ),
				'edit_theme_options' => current_user_can( 'edit_theme_options' ),
				'upload_files'       => current_user_can( 'upload_files' ),
				'publish_pages'      => current_user_can( 'publish_pages' ),
			),
			'plugin_settings'    => array(
				'read_only'      => (bool) $settings['read_only'],
				'enabled_groups' => array_values( (array) $settings['groups'] ),
			),
			'plugin_code_policy' => 'AI clients cannot add executable code: scripts, iframes, objects/embeds, event handlers, javascript:/data: URLs and script-like CSS are removed from everything you save. Existing content you do not change is kept. Build with native Divi modules (divi/video, divi/map, divi/svg ...).',
			'notes'              => current_user_can( 'unfiltered_html' ) ? array() : array( 'The acting user lacks unfiltered_html: WordPress also filters saved markup with its standard rules.' ),
		);
	}

	/**
	 * Check a page for reading settings.
	 *
	 * @param int $id Page.
	 * @throws TWDB_Tool_Error When unusable.
	 */
	private static function reading_page( $id ) {
		$p = get_post( $id );
		if ( ! $p || 'page' !== $p->post_type ) {
			throw new TWDB_Tool_Error( 'not_found', 'Page ' . $id . ' not found.' );
		}
		if ( 'publish' !== $p->post_status ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Page ' . $id . ' is not published (status ' . $p->post_status . '). Publish it first.' );
		}
	}

	/**
	 * Tool: set_front_page.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On bad input.
	 */
	public static function set_front_page( $args ) {
		$id     = (int) $args['page_id'];
		$before = array(
			'show_on_front' => get_option( 'show_on_front' ),
			'page_on_front' => (int) get_option( 'page_on_front' ),
		);
		if ( 0 === $id ) {
			update_option( 'show_on_front', 'posts' );
			$msg = 'Homepage now shows the latest posts.';
		} else {
			self::reading_page( $id );
			if ( (int) get_option( 'page_for_posts' ) === $id ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', 'That page is the posts page; the front page and posts page must differ.' );
			}
			update_option( 'page_on_front', $id );
			update_option( 'show_on_front', 'page' );
			$msg = sprintf( 'Homepage is now page #%d "%s".', $id, html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' ) );
		}
		TWDB_Tools_Cache::purge_page_caches();
		return array(
			'message' => $msg,
			'before'  => $before,
			'url'     => home_url( '/' ),
		);
	}

	/**
	 * Tool: set_posts_page.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On bad input.
	 */
	public static function set_posts_page( $args ) {
		$id     = (int) $args['page_id'];
		$before = (int) get_option( 'page_for_posts' );
		if ( $id ) {
			self::reading_page( $id );
			if ( (int) get_option( 'page_on_front' ) === $id && 'page' === get_option( 'show_on_front' ) ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', 'That page is the front page; the front page and posts page must differ.' );
			}
		}
		update_option( 'page_for_posts', $id );
		$notes = array();
		if ( $id && 'page' !== get_option( 'show_on_front' ) ) {
			$notes[] = 'The homepage currently shows latest posts, so the posts page only takes effect once a static front page is set.';
		}
		return array(
			'message'        => $id ? sprintf( 'Posts page is now #%d "%s".', $id, html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' ) ) : 'Posts page unset.',
			'before'         => $before,
			'posts_page_url' => $id ? get_permalink( $id ) : null,
			'notes'          => $notes,
		);
	}
}
