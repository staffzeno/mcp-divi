<?php
/**
 * SEO tools (Yoast SEO / Rank Math).
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SEO tools.
 */
class TWDB_Tools_SEO {

	/**
	 * Meta keys per provider.
	 *
	 * @return array
	 */
	private static function keys() {
		return array(
			'yoast'    => array(
				'title'         => '_yoast_wpseo_title',
				'description'   => '_yoast_wpseo_metadesc',
				'focus_keyword' => '_yoast_wpseo_focuskw',
				'canonical'     => '_yoast_wpseo_canonical',
				'noindex'       => '_yoast_wpseo_meta-robots-noindex',
			),
			'rankmath' => array(
				'title'         => 'rank_math_title',
				'description'   => 'rank_math_description',
				'focus_keyword' => 'rank_math_focus_keyword',
				'canonical'     => 'rank_math_canonical_url',
				'noindex'       => 'rank_math_robots',
			),
		);
	}

	/**
	 * Definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		$id = TWDB_Tools::prop( 'integer', 'Page/post ID.', array( 'minimum' => 1 ) );
		return array(
			array(
				'name'         => 'get_seo',
				'group'        => 'seo',
				'title'        => 'Get SEO meta',
				'description'  => 'Reads the SEO title, meta description, focus keyword, canonical URL and noindex flag of a page from Yoast SEO or Rank Math (whichever is active).',
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'id' ),
					'properties' => array( 'id' => $id ),
				),
				'callback'     => array( __CLASS__, 'get_seo' ),
			),
			array(
				'name'         => 'set_seo',
				'group'        => 'seo',
				'title'        => 'Set SEO meta',
				'description'  => 'Sets the SEO title, meta description, focus keyword, canonical URL and/or noindex for a page via Yoast SEO or Rank Math (whichever is active). Only the fields you pass change; an empty string clears a field. Titles may use the plugin\'s variables (e.g. %%sitename%% for Yoast, %sitename% for Rank Math).',
				'write'        => true,
				'beta'         => true,
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'id' ),
					'properties' => array(
						'id'            => $id,
						'title'         => TWDB_Tools::prop( 'string', 'SEO title (about 50-60 characters).' ),
						'description'   => TWDB_Tools::prop( 'string', 'Meta description (about 150-160 characters).' ),
						'focus_keyword' => TWDB_Tools::prop( 'string', 'Focus keyword.' ),
						'canonical'     => TWDB_Tools::prop( 'string', 'Canonical URL.' ),
						'noindex'       => TWDB_Tools::prop( 'boolean', 'Hide this page from search engines.' ),
					),
				),
				'callback'     => array( __CLASS__, 'set_seo' ),
			),
		);
	}

	/**
	 * Active provider or error.
	 *
	 * @return string
	 * @throws TWDB_Tool_Error When none.
	 */
	private static function provider() {
		$p = TWDB_Tools_Site::seo_plugin();
		if ( '' === $p ) {
			throw new TWDB_Tool_Error( 'no_seo_plugin', 'Neither Yoast SEO nor Rank Math is active on this site.' );
		}
		return $p;
	}

	/**
	 * Read values.
	 *
	 * @param string $provider Provider.
	 * @param int    $id       Post.
	 * @return array
	 */
	private static function read( $provider, $id ) {
		$k   = self::keys()[ $provider ];
		$out = array(
			'provider'      => $provider,
			'id'            => $id,
			'title'         => (string) get_post_meta( $id, $k['title'], true ),
			'description'   => (string) get_post_meta( $id, $k['description'], true ),
			'focus_keyword' => (string) get_post_meta( $id, $k['focus_keyword'], true ),
			'canonical'     => (string) get_post_meta( $id, $k['canonical'], true ),
		);
		if ( 'yoast' === $provider ) {
			$out['noindex'] = '1' === (string) get_post_meta( $id, $k['noindex'], true );
		} else {
			$robots         = (array) get_post_meta( $id, $k['noindex'], true );
			$out['noindex'] = in_array( 'noindex', $robots, true );
		}
		return $out;
	}

	/**
	 * Tool: get_seo.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function get_seo( $args ) {
		$provider = self::provider();
		$post     = TWDB_Tools_Pages::load( $args['id'] );
		return self::read( $provider, $post->ID );
	}

	/**
	 * Tool: set_seo.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On failure.
	 */
	public static function set_seo( $args ) {
		$provider = self::provider();
		$post     = TWDB_Tools_Pages::load( $args['id'], true );
		$k        = self::keys()[ $provider ];
		$before   = self::read( $provider, $post->ID );
		$changed  = array();
		foreach ( array( 'title', 'description', 'focus_keyword', 'canonical' ) as $f ) {
			if ( ! isset( $args[ $f ] ) ) {
				continue;
			}
			$val = 'canonical' === $f ? esc_url_raw( $args[ $f ] ) : sanitize_text_field( $args[ $f ] );
			if ( '' === $val ) {
				delete_post_meta( $post->ID, $k[ $f ] );
			} else {
				update_post_meta( $post->ID, $k[ $f ], wp_slash( $val ) );
			}
			$changed[] = $f;
		}
		if ( isset( $args['noindex'] ) ) {
			if ( 'yoast' === $provider ) {
				if ( $args['noindex'] ) {
					update_post_meta( $post->ID, $k['noindex'], '1' );
				} else {
					delete_post_meta( $post->ID, $k['noindex'] );
				}
			} else {
				$robots   = array_values( array_diff( (array) get_post_meta( $post->ID, $k['noindex'], true ), array( 'noindex', 'index', '' ) ) );
				$robots[] = $args['noindex'] ? 'noindex' : 'index';
				update_post_meta( $post->ID, $k['noindex'], $robots );
			}
			$changed[] = 'noindex';
		}
		if ( ! $changed ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Pass at least one of title, description, focus_keyword, canonical, noindex.' );
		}
		clean_post_cache( $post->ID );
		return array(
			'message' => sprintf( 'Updated %s SEO for #%d (%s).', 'yoast' === $provider ? 'Yoast' : 'Rank Math', $post->ID, implode( ', ', $changed ) ),
			'before'  => $before,
			'after'   => self::read( $provider, $post->ID ),
			'note'    => 'yoast' === $provider ? 'Yoast may show the new values in its admin/indexables only after the page is next saved in WordPress; the front-end meta reads the stored values.' : '',
		);
	}
}
