<?php
/**
 * Module-level tools: read the module tree of a page and apply surgical edits
 * (edit attributes, replace, add, delete, move) by index path.
 *
 * Added in the merged build. Every write saves a restore point and the resulting
 * markup is validated before anything is stored.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Module tools.
 */
class TWDB_Tools_Modules {

	const MAX_OPS = 100;

	/**
	 * Definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		$id   = TWDB_Tools::prop( 'integer', 'Page/post ID.', array( 'minimum' => 1 ) );
		$path = array(
			'type'  => 'array',
			'items' => array(
				'type'    => 'integer',
				'minimum' => 0,
			),
		);

		return array(
			array(
				'name'         => 'get_page_tree',
				'group'        => 'pages',
				'title'        => 'Get page module tree',
				'description'  => 'Returns the module tree of a Divi page (section > row > column > modules) with an index path for every module and a short text preview. Use the paths with edit_page_modules. include_attrs=true returns every module\'s full attributes (can be large).',
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'id' ),
					'properties' => array(
						'id'            => $id,
						'include_attrs' => TWDB_Tools::prop( 'boolean', 'Include full attributes of each module (default false).' ),
					),
				),
				'callback'     => array( __CLASS__, 'get_page_tree' ),
			),
			array(
				'name'         => 'edit_page_modules',
				'group'        => 'pages',
				'title'        => 'Edit page modules',
				'description'  => 'Applies surgical edits to a page by module path, in order, atomically (all or nothing). ops: {op:"edit",path,attrs} deep-merges attrs into the module (null deletes a key); {op:"replace",path,markup} swaps a module for new markup; {op:"delete",path}; {op:"move",path,to_parent,index?}; {op:"add",parent,index?,markup} (parent [] = top level, i.e. a new section). Paths come from get_page_tree. Ops run in order, so a path refers to the tree as changed by the ops before it: put attribute edits first and structural ops (delete/move/add/replace) last, or call again with fresh paths. A restore point is saved first and the result is validated.',
				'write'        => true,
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'id', 'ops' ),
					'properties' => array(
						'id'  => $id,
						'ops' => array(
							'type'     => 'array',
							'minItems' => 1,
							'maxItems' => self::MAX_OPS,
							'items'    => array(
								'type'       => 'object',
								'required'   => array( 'op' ),
								'properties' => array(
									'op'        => TWDB_Tools::prop( 'string', 'Operation.', array( 'enum' => array( 'edit', 'replace', 'delete', 'move', 'add' ) ) ),
									'path'      => array_merge( $path, array( 'description' => 'Index path of the target module (edit/replace/delete/move).' ) ),
									'attrs'     => TWDB_Tools::prop( 'object', 'Attributes to deep-merge (edit). null deletes a key.' ),
									'markup'    => TWDB_Tools::prop( 'string', 'Divi block markup without the placeholder wrapper (replace/add).' ),
									'parent'    => array_merge( $path, array( 'description' => 'Parent path to insert into (add). [] = top level.' ) ),
									'to_parent' => array_merge( $path, array( 'description' => 'Destination parent path (move). [] = top level.' ) ),
									'index'     => TWDB_Tools::prop( 'integer', 'Position among the siblings (add/move; default end).', array( 'minimum' => 0 ) ),
								),
							),
						),
					),
				),
				'callback'     => array( __CLASS__, 'edit_page_modules' ),
			),
		);
	}

	/* ---------------- Helpers ---------------- */

	/**
	 * Editable block list, unwrapped from divi/placeholder.
	 *
	 * @param WP_Post $post Post.
	 * @return array
	 * @throws TWDB_Tool_Error If the page has no Divi markup.
	 */
	private static function load_blocks( $post ) {
		$blocks = array_values(
			array_filter(
				parse_blocks( (string) $post->post_content ),
				static function ( $b ) {
					return null !== $b['blockName'] || '' !== trim( (string) $b['innerHTML'] );
				}
			)
		);
		if ( 1 === count( $blocks ) && 'divi/placeholder' === $blocks[0]['blockName'] ) {
			return $blocks[0]['innerBlocks'];
		}
		if ( ! $blocks ) {
			return array();
		}
		throw new TWDB_Tool_Error( 'invalid_arguments', 'This page is not a Divi 5 page wrapped in divi/placeholder, so module paths are not available. Use update_page instead.' );
	}

	/**
	 * Make innerContent consistent with innerBlocks so serialize_blocks() is correct after edits.
	 *
	 * @param array $blocks Blocks.
	 * @return array
	 */
	private static function normalize( array $blocks ) {
		foreach ( $blocks as &$b ) {
			$b['innerBlocks'] = self::normalize( $b['innerBlocks'] );
			if ( empty( $b['innerBlocks'] ) && in_array( null, (array) $b['innerContent'], true ) ) {
				// A container whose last child was deleted or moved out: keep it as an open/close pair, but
				// drop the slots that pointed at children (serialize_blocks() would read missing blocks).
				$b['innerContent'] = array( "\n" );
				$b['innerHTML']    = "\n";
			} elseif ( ! empty( $b['innerBlocks'] ) ) {
				$ic = array( "\n" );
				foreach ( $b['innerBlocks'] as $unused ) {
					$ic[] = null;
					$ic[] = "\n";
				}
				$b['innerContent'] = $ic;
				$b['innerHTML']    = str_repeat( "\n", count( $b['innerBlocks'] ) + 1 );
			}
		}
		unset( $b );
		return $blocks;
	}

	/**
	 * Serialise an editable block list back to placeholder-wrapped markup.
	 *
	 * @param array $blocks Blocks.
	 * @return string
	 */
	private static function to_markup( array $blocks ) {
		return TWDB_Markup::PLACEHOLDER_OPEN . "\n" . serialize_blocks( self::normalize( $blocks ) ) . "\n" . TWDB_Markup::PLACEHOLDER_CLOSE;
	}

	/**
	 * First human-readable text inside a module's attributes.
	 *
	 * @param mixed $node Attribute subtree.
	 * @return string
	 */
	private static function find_text( $node ) {
		if ( ! is_array( $node ) ) {
			return '';
		}
		foreach ( $node as $k => $v ) {
			if ( 'innerContent' === $k ) {
				$flat = self::first_string( $v );
				if ( '' !== $flat ) {
					return $flat;
				}
			} elseif ( is_array( $v ) ) {
				$t = self::find_text( $v );
				if ( '' !== $t ) {
					return $t;
				}
			}
		}
		return '';
	}

	/**
	 * First non-empty string leaf.
	 *
	 * @param mixed $v Value.
	 * @return string
	 */
	private static function first_string( $v ) {
		if ( is_string( $v ) ) {
			$t = trim( wp_strip_all_tags( $v ) );
			return '' !== $t ? TWDB_Text::substr( $t, 0, 80 ) : '';
		}
		if ( is_array( $v ) ) {
			foreach ( $v as $x ) {
				$t = self::first_string( $x );
				if ( '' !== $t ) {
					return $t;
				}
			}
		}
		return '';
	}

	/**
	 * Tree nodes with paths.
	 *
	 * @param array $blocks Blocks.
	 * @param array $path   Parent path.
	 * @param bool  $full   Include attrs.
	 * @return array
	 */
	private static function nodes( array $blocks, array $path, $full ) {
		$out = array();
		foreach ( $blocks as $i => $b ) {
			if ( null === $b['blockName'] ) {
				continue;
			}
			$p     = array_merge( $path, array( $i ) );
			$attrs = is_array( $b['attrs'] ) ? $b['attrs'] : array();
			$node  = array(
				'path'     => $p,
				'name'     => $b['blockName'],
				'preview'  => self::find_text( $attrs ),
				'attrKeys' => array_keys( $attrs ),
			);
			if ( $full ) {
				$node['attrs'] = $attrs;
			}
			$node['children'] = self::nodes( $b['innerBlocks'], $p, $full );
			$out[]            = $node;
		}
		return $out;
	}

	/**
	 * Reference to the sibling list at a parent path.
	 *
	 * @param array $blocks Root list.
	 * @param array $parent Parent path.
	 * @return array|null Reference.
	 */
	private static function &siblings( array &$blocks, array $parent ) {
		$null = null;
		$cur  = &$blocks;
		foreach ( $parent as $i ) {
			if ( ! isset( $cur[ $i ] ) ) {
				return $null;
			}
			$cur = &$cur[ $i ]['innerBlocks'];
		}
		return $cur;
	}

	/**
	 * Deep merge where null deletes a key and lists are replaced.
	 *
	 * @param array $base  Base.
	 * @param array $patch Patch.
	 * @return array
	 */
	private static function merge_attrs( array $base, array $patch ) {
		foreach ( $patch as $k => $v ) {
			if ( null === $v ) {
				unset( $base[ $k ] );
			} elseif ( is_array( $v ) && ! empty( $v ) && array_keys( $v ) !== range( 0, count( $v ) - 1 ) && isset( $base[ $k ] ) && is_array( $base[ $k ] ) ) {
				$base[ $k ] = self::merge_attrs( $base[ $k ], $v );
			} else {
				$base[ $k ] = $v;
			}
		}
		return $base;
	}

	/**
	 * Parse snippet markup into blocks.
	 *
	 * @param string $markup Markup.
	 * @param int    $n      Op number.
	 * @return array
	 * @throws TWDB_Tool_Error If empty or invalid.
	 */
	private static function parse_snippet( $markup, $n ) {
		$markup = trim( (string) $markup );
		if ( 0 === strpos( $markup, TWDB_Markup::PLACEHOLDER_OPEN ) ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', sprintf( 'Op #%d: send module markup without the divi/placeholder wrapper.', $n ) );
		}
		$v = TWDB_Markup::validate( $markup, false );
		if ( ! $v['valid'] ) {
			throw new TWDB_Tool_Error( 'invalid_markup', sprintf( 'Op #%d: the markup failed validation; nothing was saved.', $n ), $v );
		}
		$blocks = array_values(
			array_filter(
				parse_blocks( $markup ),
				static function ( $b ) {
					return null !== $b['blockName'];
				}
			)
		);
		if ( ! $blocks ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', sprintf( 'Op #%d: the markup contained no blocks.', $n ) );
		}
		return $blocks;
	}

	/* ---------------- Tools ---------------- */

	/**
	 * Tool: get_page_tree.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function get_page_tree( $args ) {
		$post   = TWDB_Tools_Pages::load( $args['id'] );
		$blocks = self::load_blocks( $post );
		return array(
			'id'    => $post->ID,
			'title' => $post->post_title,
			'tree'  => self::nodes( $blocks, array(), ! empty( $args['include_attrs'] ) ),
		);
	}

	/**
	 * Tool: edit_page_modules.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On bad ops or invalid result.
	 */
	public static function edit_page_modules( $args ) {
		$post   = TWDB_Tools_Pages::load( $args['id'], true );
		$blocks = self::load_blocks( $post );
		$ops    = $args['ops'];

		foreach ( $ops as $n => $op ) {
			$kind = isset( $op['op'] ) ? $op['op'] : '';
			$path = isset( $op['path'] ) ? array_map( 'intval', (array) $op['path'] ) : array();
			$num  = $n + 1;

			if ( in_array( $kind, array( 'edit', 'replace', 'delete', 'move' ), true ) ) {
				if ( ! $path ) {
					throw new TWDB_Tool_Error( 'invalid_arguments', sprintf( 'Op #%d (%s): "path" is required.', $num, $kind ) );
				}
				$idx  = array_pop( $path );
				$sibs = &self::siblings( $blocks, $path );
				if ( null === $sibs || ! isset( $sibs[ $idx ] ) ) {
					throw new TWDB_Tool_Error( 'not_found', sprintf( 'Op #%d (%s): no module at path [%s]. Call get_page_tree again.', $num, $kind, implode( ',', array_merge( $path, array( $idx ) ) ) ) );
				}
				if ( 'edit' === $kind ) {
					$sibs[ $idx ]['attrs'] = self::merge_attrs( (array) $sibs[ $idx ]['attrs'], isset( $op['attrs'] ) ? (array) $op['attrs'] : array() );
				} elseif ( 'replace' === $kind ) {
					array_splice( $sibs, $idx, 1, self::parse_snippet( isset( $op['markup'] ) ? $op['markup'] : '', $num ) );
				} else {
					$node = $sibs[ $idx ];
					array_splice( $sibs, $idx, 1 );
					if ( 'move' === $kind ) {
						unset( $sibs );
						$to   = array_map( 'intval', (array) ( isset( $op['to_parent'] ) ? $op['to_parent'] : array() ) );
						$dest = &self::siblings( $blocks, $to );
						if ( null === $dest ) {
							throw new TWDB_Tool_Error( 'not_found', sprintf( 'Op #%d (move): destination parent does not exist.', $num ) );
						}
						$at = isset( $op['index'] ) ? max( 0, min( (int) $op['index'], count( $dest ) ) ) : count( $dest );
						array_splice( $dest, $at, 0, array( $node ) );
						unset( $dest );
					}
				}
				unset( $sibs );
			} elseif ( 'add' === $kind ) {
				$parsed = self::parse_snippet( isset( $op['markup'] ) ? $op['markup'] : '', $num );
				$to     = array_map( 'intval', (array) ( isset( $op['parent'] ) ? $op['parent'] : array() ) );
				$sibs   = &self::siblings( $blocks, $to );
				if ( null === $sibs ) {
					throw new TWDB_Tool_Error( 'not_found', sprintf( 'Op #%d (add): parent path does not exist.', $num ) );
				}
				$at = isset( $op['index'] ) ? max( 0, min( (int) $op['index'], count( $sibs ) ) ) : count( $sibs );
				array_splice( $sibs, $at, 0, $parsed );
				unset( $sibs );
			} else {
				throw new TWDB_Tool_Error( 'invalid_arguments', sprintf( 'Op #%d: unknown op "%s".', $num, $kind ) );
			}
		}

		$markup = TWDB_Code_Policy::clean_markup( self::to_markup( $blocks ), (string) $post->post_content );
		$v      = TWDB_Markup::validate( $markup, true );
		if ( ! $v['valid'] ) {
			throw new TWDB_Tool_Error( 'invalid_markup', 'The edited page failed validation; nothing was saved.', $v );
		}

		$backup_id = TWDB_Backups::backup_post( $post->ID, 'before edit_page_modules (' . count( $ops ) . ' op(s))' );
		$r         = TWDB_Tools_Pages::safe_update_post(
			array(
				'ID'           => $post->ID,
				'post_content' => $markup,
			)
		);
		if ( is_wp_error( $r ) ) {
			throw new TWDB_Tool_Error( 'save_failed', $r->get_error_message() );
		}
		TWDB_Tools_Pages::apply_divi_meta( $post->ID, $post->post_type );
		TWDB_Divi::clear_cache( $post->ID );

		$fresh = get_post( $post->ID );
		return array_merge(
			TWDB_Tools_Pages::summary( $fresh ),
			array(
				'message'     => sprintf( 'Applied %d edit(s) to %s #%d. Restore point #%d.', count( $ops ), $fresh->post_type, $fresh->ID, $backup_id ),
				'backup_id'   => $backup_id,
				'builder_url' => TWDB_Tools_Pages::builder_url( $fresh->ID ),
				'preview_url' => TWDB_Frontend::preview_url( $fresh->ID ),
				'tree'        => self::nodes( self::load_blocks( $fresh ), array(), false ),
				'warnings'    => $v['warnings'],
			)
		);
	}
}
