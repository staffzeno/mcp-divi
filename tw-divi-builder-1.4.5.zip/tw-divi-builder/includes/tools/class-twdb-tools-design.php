<?php
/**
 * Design-system tools: global colors, global variables, presets.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Design tools.
 */
class TWDB_Tools_Design {

	const VAR_TYPES = array( 'numbers', 'strings', 'images', 'links', 'fonts', 'gradients' );

	/**
	 * Definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return array(
			array(
				'name'         => 'get_design_system',
				'group'        => 'design',
				'title'        => 'Get design system',
				'description'  => 'Returns the site\'s Divi 5 design system: global colors (customizer + user, with ready-to-paste $variable(...)$ tokens), global variables (numbers, strings, images, links, fonts, gradients) with tokens, theme fonts, and a summary of presets per module. Build pages with these exact tokens; never invent gcid-/gvid- ids.',
				'divi'         => true,
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'include_archived' => TWDB_Tools::prop( 'boolean', 'Include archived colors/variables (default false).' ),
					),
				),
				'callback'     => array( __CLASS__, 'get_design_system' ),
			),
			array(
				'name'         => 'set_global_colors',
				'group'        => 'design',
				'title'        => 'Set global colors',
				'description'  => 'Creates or updates Divi 5 global colors (merge - other colors are untouched). Match by id (gcid-...) or, if no id is given, by label; otherwise a new id is created from the label. Saves a restore point first. Returns each color\'s token. Customizer colors (gcid-primary-color etc.) are changed in Theme Options, not here.',
				'beta'         => true,
				'divi'         => true,
				'write'        => true,
				'capability'   => 'edit_theme_options',
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'colors' ),
					'properties' => array(
						'colors' => array(
							'type'     => 'array',
							'minItems' => 1,
							'maxItems' => 100,
							'items'    => array(
								'type'       => 'object',
								'required'   => array( 'color' ),
								'properties' => array(
									'id'     => TWDB_Tools::prop( 'string', 'Existing or desired id, e.g. "gcid-brand-primary" ([a-z0-9-]).' ),
									'label'  => TWDB_Tools::prop( 'string', 'Label shown in the Divi color manager.' ),
									'color'  => TWDB_Tools::prop( 'string', 'Hex (#1a2b3c / #1a2b3c80), rgb()/rgba(), hsl()/hsla(), or "transparent".' ),
									'folder' => TWDB_Tools::prop( 'string', 'Optional folder name.' ),
									'status' => TWDB_Tools::prop( 'string', 'active (default) or archived.', array( 'enum' => array( 'active', 'archived' ) ) ),
								),
							),
						),
					),
				),
				'callback'     => array( __CLASS__, 'set_global_colors' ),
			),
			array(
				'name'         => 'delete_global_color',
				'group'        => 'design',
				'title'        => 'Delete global color',
				'description'  => 'Archives a user global color (default; it stops showing in the picker but pages using it keep rendering) or removes it permanently with permanent=true (pages still referencing it lose the color). Saves a restore point first.',
				'beta'         => true,
				'divi'         => true,
				'write'        => true,
				'destructive'  => true,
				'capability'   => 'edit_theme_options',
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'id' ),
					'properties' => array(
						'id'        => TWDB_Tools::prop( 'string', 'Color id (gcid-...).' ),
						'permanent' => TWDB_Tools::prop( 'boolean', 'Remove instead of archive (default false).' ),
					),
				),
				'callback'     => array( __CLASS__, 'delete_global_color' ),
			),
			array(
				'name'         => 'set_global_variables',
				'group'        => 'design',
				'title'        => 'Set global variables',
				'description'  => 'Creates or updates Divi 5 global variables (numbers e.g. "clamp(1rem, 2vw, 1.5rem)" or "24px", strings, images (URL), links (URL), fonts (font family), gradients). Gradients accept either a full $variable({"type":"gradient",...})$ string or {stops:[{position,color}], type, direction}. Match by id, else by type+label. Optional delete_ids removes variables. Saves a restore point first. Returns tokens.',
				'divi'         => true,
				'write'        => true,
				'beta'         => true,
				'capability'   => 'edit_theme_options',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'variables'  => array(
							'type'     => 'array',
							'maxItems' => 200,
							'items'    => array(
								'type'       => 'object',
								'required'   => array( 'type', 'value' ),
								'properties' => array(
									'id'    => TWDB_Tools::prop( 'string', 'Existing or desired id, e.g. "gvid-space-lg" ([a-z0-9-]).' ),
									'type'  => TWDB_Tools::prop( 'string', 'Variable type.', array( 'enum' => self::VAR_TYPES ) ),
									'label' => TWDB_Tools::prop( 'string', 'Label.' ),
									'value' => array(
										'description' => 'Value: string for most types; string or {stops,type,direction} object for gradients.',
										'type'        => array( 'string', 'number', 'object' ),
									),
								),
							),
						),
						'delete_ids' => array(
							'type'        => 'array',
							'description' => 'Variable ids (gvid-...) to remove.',
							'items'       => array( 'type' => 'string' ),
						),
					),
				),
				'callback'     => array( __CLASS__, 'set_global_variables' ),
			),
			array(
				'name'         => 'list_presets',
				'group'        => 'design',
				'title'        => 'List presets',
				'description'  => 'Lists Divi 5 global presets (module presets per module, e.g. divi/button, and option-group presets), with ids, names and which is the default. Set include_attrs to see attribute values. Apply a module preset on a block with "modulePreset":["<id>"].',
				'divi'         => true,
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'module'        => TWDB_Tools::prop( 'string', 'Only this module (e.g. divi/button) or group name.' ),
						'include_attrs' => TWDB_Tools::prop( 'boolean', 'Include attrs (default false).' ),
					),
				),
				'callback'     => array( __CLASS__, 'list_presets' ),
			),
			array(
				'name'         => 'upsert_preset',
				'group'        => 'design',
				'title'        => 'Create or update preset',
				'description'  => 'Creates or updates a Divi 5 global preset. kind "module": module_name e.g. "divi/button", attrs uses the same attribute tree as the block JSON (e.g. {"button":{"decoration":{...}}}). kind "group": group_name and group_id required, attrs rooted at the group key. Give id to update an existing preset (attrs are replaced). make_default makes it the module default. Saves a restore point first. See get_divi_reference topic "presets".',
				'divi'         => true,
				'write'        => true,
				'beta'         => true,
				'capability'   => 'edit_theme_options',
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'name', 'attrs' ),
					'properties' => array(
						'kind'         => TWDB_Tools::prop( 'string', 'module (default) or group.', array( 'enum' => array( 'module', 'group' ) ) ),
						'id'           => TWDB_Tools::prop( 'string', 'Existing preset id to update.' ),
						'name'         => TWDB_Tools::prop( 'string', 'Preset name.' ),
						'module_name'  => TWDB_Tools::prop( 'string', 'Module block name, e.g. divi/button (required for kind module; for group presets the module the group belongs to).' ),
						'group_name'   => TWDB_Tools::prop( 'string', 'Option group name for group presets, e.g. divi/font.' ),
						'group_id'     => TWDB_Tools::prop( 'string', 'Option group id for group presets, e.g. designTitleText.' ),
						'attrs'        => TWDB_Tools::prop( 'object', 'Preset attributes (non-empty).' ),
						'style_attrs'  => TWDB_Tools::prop( 'object', 'Optional styleAttrs (defaults to attrs).' ),
						'make_default' => TWDB_Tools::prop( 'boolean', 'Make this the default preset.' ),
					),
				),
				'callback'     => array( __CLASS__, 'upsert_preset' ),
			),
			array(
				'name'         => 'delete_preset',
				'group'        => 'design',
				'title'        => 'Delete preset',
				'description'  => 'Removes a preset by id (module or group). Modules referencing it fall back to their own styles. Saves a restore point first.',
				'divi'         => true,
				'write'        => true,
				'destructive'  => true,
				'beta'         => true,
				'capability'   => 'edit_theme_options',
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'id' ),
					'properties' => array(
						'id' => TWDB_Tools::prop( 'string', 'Preset id.' ),
					),
				),
				'callback'     => array( __CLASS__, 'delete_preset' ),
			),
		);
	}

	/* -------------------- Helpers -------------------- */

	/**
	 * Divi-style timestamp.
	 *
	 * @return string
	 */
	private static function now() {
		return gmdate( 'Y-m-d\TH:i:s.000\Z' );
	}

	/**
	 * Normalise an id.
	 *
	 * @param string $raw    Raw id or label.
	 * @param string $prefix gcid-/gvid-.
	 * @return string
	 */
	private static function make_id( $raw, $prefix ) {
		$raw = strtolower( (string) $raw );
		if ( 0 === strpos( $raw, $prefix ) ) {
			$raw = substr( $raw, strlen( $prefix ) );
		}
		$raw = trim( preg_replace( '/[^a-z0-9-]+/', '-', $raw ), '-' );
		$raw = substr( $raw, 0, 60 );
		if ( '' === $raw ) {
			$raw = strtolower( wp_generate_password( 8, false ) );
		}
		return $prefix . $raw;
	}

	/**
	 * Validate a CSS color.
	 *
	 * @param string $c Color.
	 * @return string|false
	 */
	public static function clean_color( $c ) {
		$c = trim( (string) $c );
		if ( preg_match( '/^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $c ) ) {
			return strtolower( $c );
		}
		if ( preg_match( '/^(?:rgba?|hsla?)\(\s*[0-9.%\s,\/+-]+\)$/i', $c ) ) {
			return $c;
		}
		if ( 'transparent' === strtolower( $c ) ) {
			return 'transparent';
		}
		return false;
	}

	/**
	 * Gradient object -> Divi gradient variable value string.
	 *
	 * @param array $g Gradient.
	 * @return string
	 * @throws TWDB_Tool_Error On bad input.
	 */
	private static function gradient_value( $g ) {
		if ( empty( $g['stops'] ) || ! is_array( $g['stops'] ) ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Gradient needs "stops": [{"position":"0%","color":"#000"}, ...].' );
		}
		$stops = array();
		foreach ( $g['stops'] as $s ) {
			$color = isset( $s['color'] ) ? self::clean_color( $s['color'] ) : false;
			if ( false === $color && isset( $s['color'] ) && 0 === strpos( (string) $s['color'], '$variable(' ) ) {
				$color = (string) $s['color'];
			}
			if ( false === $color ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', 'Each gradient stop needs a valid color.' );
			}
			$pos     = isset( $s['position'] ) ? (string) $s['position'] : '0';
			$stops[] = array(
				'position' => rtrim( $pos, '%' ),
				'color'    => $color,
			);
		}
		$settings = array(
			'enabled'         => 'on',
			'stops'           => $stops,
			'type'            => isset( $g['type'] ) ? sanitize_key( $g['type'] ) : 'linear',
			'direction'       => isset( $g['direction'] ) ? (string) $g['direction'] : '180deg',
			'directionRadial' => isset( $g['directionRadial'] ) ? (string) $g['directionRadial'] : 'center',
			'length'          => isset( $g['length'] ) ? (string) $g['length'] : '100%',
			'overlaysImage'   => isset( $g['overlaysImage'] ) ? (string) $g['overlaysImage'] : 'off',
			'repeat'          => isset( $g['repeat'] ) ? (string) $g['repeat'] : 'off',
		);
		return '$variable(' . wp_json_encode(
			array(
				'type'  => 'gradient',
				'value' => array(
					'name'     => 'gradient',
					'settings' => $settings,
				),
			),
			JSON_UNESCAPED_SLASHES
		) . ')$';
	}

	/**
	 * Find a preset by id anywhere.
	 *
	 * @param array  $presets Presets.
	 * @param string $id      Id.
	 * @return array|null [bucket, key]
	 */
	private static function locate_preset( $presets, $id ) {
		foreach ( array( 'module', 'group' ) as $bucket ) {
			foreach ( (array) $presets[ $bucket ] as $key => $info ) {
				if ( isset( $info['items'][ $id ] ) ) {
					return array( $bucket, $key );
				}
			}
		}
		return null;
	}

	/* -------------------- Tools -------------------- */

	/**
	 * Tool: get_design_system.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function get_design_system( $args ) {
		$archived = ! empty( $args['include_archived'] );
		$colors   = array();
		foreach ( TWDB_Divi::get_customizer_colors() as $id => $c ) {
			$colors[] = array(
				'id'     => $id,
				'label'  => $c['label'],
				'value'  => $c['color'],
				'source' => 'customizer',
				'token'  => TWDB_Divi::color_token( $id ),
			);
		}
		foreach ( TWDB_Divi::get_global_colors() as $id => $c ) {
			$status = isset( $c['status'] ) ? $c['status'] : 'active';
			if ( 'active' !== $status && ! $archived ) {
				continue;
			}
			$colors[] = array(
				'id'     => $id,
				'label'  => isset( $c['label'] ) ? $c['label'] : $id,
				'value'  => isset( $c['color'] ) ? $c['color'] : '',
				'status' => $status,
				'folder' => isset( $c['folder'] ) ? $c['folder'] : '',
				'source' => 'user',
				'token'  => TWDB_Divi::color_token( $id ),
			);
		}
		$vars = array();
		foreach ( TWDB_Divi::get_global_variables() as $type => $items ) {
			if ( ! is_array( $items ) ) {
				continue;
			}
			foreach ( $items as $id => $v ) {
				if ( ! is_array( $v ) ) {
					continue;
				}
				$status = isset( $v['status'] ) ? $v['status'] : 'active';
				if ( 'active' !== $status && ! $archived ) {
					continue;
				}
				$vars[ $type ][] = array(
					'id'    => $id,
					'label' => isset( $v['label'] ) ? $v['label'] : $id,
					'value' => isset( $v['value'] ) ? $v['value'] : '',
					'token' => TWDB_Divi::variable_token( $id, $type ),
				);
			}
		}
		$presets = TWDB_Divi::get_presets();
		$summary = array();
		foreach ( array( 'module', 'group' ) as $bucket ) {
			foreach ( (array) $presets[ $bucket ] as $key => $info ) {
				$items = isset( $info['items'] ) && is_array( $info['items'] ) ? $info['items'] : array();
				if ( ! $items ) {
					continue;
				}
				$list = array();
				foreach ( $items as $pid => $p ) {
					$list[] = array(
						'id'   => $pid,
						'name' => isset( $p['name'] ) ? $p['name'] : '',
					);
				}
				$summary[] = array(
					'kind'    => $bucket,
					'key'     => $key,
					'default' => isset( $info['default'] ) ? $info['default'] : '',
					'presets' => $list,
				);
			}
		}
		return array(
			'colors'    => $colors,
			'variables' => $vars ? $vars : new stdClass(),
			'fonts'     => array(
				'heading' => function_exists( 'et_get_option' ) ? et_get_option( 'heading_font', '' ) : '',
				'body'    => function_exists( 'et_get_option' ) ? et_get_option( 'body_font', '' ) : '',
			),
			'presets'   => $summary,
			'usage'     => 'Paste tokens verbatim as attribute values, e.g. "background":{"desktop":{"value":{"color":"<color token>"}}}. Size/font variables use type "content" tokens. Apply presets with "modulePreset":["<id>"].',
		);
	}

	/**
	 * Tool: set_global_colors.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On bad input.
	 */
	public static function set_global_colors( $args ) {
		$colors  = TWDB_Divi::get_global_colors();
		$custom  = TWDB_Divi::get_customizer_colors();
		$backup  = TWDB_Backups::create( 'global_colors', 'et_global_data', $colors, 'Global colors', 'before set_global_colors' );
		$results = array();
		$max     = count( $custom );
		foreach ( $colors as $c ) {
			if ( isset( $c['order'] ) && is_numeric( $c['order'] ) ) {
				$max = max( $max, (int) $c['order'] );
			}
		}

		foreach ( $args['colors'] as $in ) {
			$value = self::clean_color( $in['color'] );
			if ( false === $value ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', sprintf( 'Invalid color "%s". Nothing was saved.', $in['color'] ) );
			}
			$label = isset( $in['label'] ) ? sanitize_text_field( $in['label'] ) : '';
			$id    = '';
			if ( ! empty( $in['id'] ) ) {
				$id = self::make_id( $in['id'], 'gcid-' );
				if ( isset( $custom[ $id ] ) ) {
					throw new TWDB_Tool_Error( 'invalid_arguments', sprintf( '%s is a customizer color; change it in Divi > Theme Options / Customizer. Nothing was saved.', $id ) );
				}
			} elseif ( '' !== $label ) {
				foreach ( $colors as $cid => $c ) {
					if ( isset( $c['label'] ) && 0 === strcasecmp( $c['label'], $label ) ) {
						$id = $cid;
						break;
					}
				}
				if ( '' === $id ) {
					$id = self::make_id( $label, 'gcid-' );
					while ( isset( $colors[ $id ] ) || isset( $custom[ $id ] ) ) {
						$id .= '-' . strtolower( wp_generate_password( 3, false ) );
					}
				}
			} else {
				$id = self::make_id( '', 'gcid-' );
			}
			$exists               = isset( $colors[ $id ] );
			$entry                = $exists ? $colors[ $id ] : array(
				'folder'      => '',
				'usedInPosts' => array(),
				'order'       => (string) ( ++$max ),
			);
			$entry['color']       = $value;
			$entry['label']       = '' !== $label ? $label : ( isset( $entry['label'] ) ? $entry['label'] : $id );
			$entry['status']      = isset( $in['status'] ) ? $in['status'] : ( isset( $entry['status'] ) ? $entry['status'] : 'active' );
			$entry['lastUpdated'] = self::now();
			if ( isset( $in['folder'] ) ) {
				$entry['folder'] = sanitize_text_field( $in['folder'] );
			}
			$colors[ $id ] = $entry;
			$results[]     = array(
				'id'     => $id,
				'label'  => $entry['label'],
				'color'  => $value,
				'action' => $exists ? 'updated' : 'created',
				'token'  => TWDB_Divi::color_token( $id ),
			);
		}
		TWDB_Divi::save_global_colors( $colors );
		TWDB_Divi::clear_cache();
		return array(
			'message'   => sprintf( 'Saved %d global color(s). Restore point #%d.', count( $results ), $backup ),
			'colors'    => $results,
			'backup_id' => $backup,
		);
	}

	/**
	 * Tool: delete_global_color.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error When missing.
	 */
	public static function delete_global_color( $args ) {
		$colors = TWDB_Divi::get_global_colors();
		$id     = (string) $args['id'];
		if ( ! isset( $colors[ $id ] ) ) {
			if ( isset( TWDB_Divi::get_customizer_colors()[ $id ] ) ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', 'Customizer colors cannot be deleted.' );
			}
			throw new TWDB_Tool_Error( 'not_found', 'No user global color with id ' . $id . '.' );
		}
		$backup = TWDB_Backups::create( 'global_colors', 'et_global_data', $colors, 'Global colors', 'before delete_global_color ' . $id );
		if ( ! empty( $args['permanent'] ) ) {
			unset( $colors[ $id ] );
			$action = 'deleted';
		} else {
			$colors[ $id ]['status']      = 'archived';
			$colors[ $id ]['lastUpdated'] = self::now();
			$action                       = 'archived';
		}
		TWDB_Divi::save_global_colors( $colors );
		TWDB_Divi::clear_cache();
		return array(
			'message'   => sprintf( 'Global color %s %s. Restore point #%d.', $id, $action, $backup ),
			'backup_id' => $backup,
		);
	}

	/**
	 * Tool: set_global_variables.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On bad input.
	 */
	public static function set_global_variables( $args ) {
		$in_vars = isset( $args['variables'] ) ? (array) $args['variables'] : array();
		$deletes = isset( $args['delete_ids'] ) ? (array) $args['delete_ids'] : array();
		if ( ! $in_vars && ! $deletes ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Pass variables and/or delete_ids.' );
		}
		$vars    = TWDB_Divi::get_global_variables();
		$backup  = TWDB_Backups::create( 'global_variables', TWDB_Divi::variables_option(), $vars, 'Global variables', 'before set_global_variables' );
		$out     = array();
		$all_ids = array();
		foreach ( $vars as $type => $items ) {
			foreach ( (array) $items as $vid => $v ) {
				$all_ids[ $vid ] = $type;
			}
		}

		foreach ( $in_vars as $in ) {
			$type = $in['type'];
			if ( ! isset( $vars[ $type ] ) || ! is_array( $vars[ $type ] ) ) {
				$vars[ $type ] = array();
			}
			$label = isset( $in['label'] ) ? sanitize_text_field( $in['label'] ) : '';
			if ( 'gradients' === $type ) {
				if ( is_array( $in['value'] ) ) {
					$value = self::gradient_value( $in['value'] );
				} else {
					$value = TWDB_Code_Policy::clean_string( (string) $in['value'] );
					if ( 0 !== strpos( $value, '$variable(' ) ) {
						throw new TWDB_Tool_Error( 'invalid_arguments', 'Gradient value must be a $variable({"type":"gradient",...})$ string or a {stops,type,direction} object. Nothing was saved.' );
					}
				}
			} elseif ( is_array( $in['value'] ) ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', 'Only gradient variables accept an object value. Nothing was saved.' );
			} elseif ( in_array( $type, array( 'images', 'links' ), true ) ) {
				$value = esc_url_raw( (string) $in['value'] );
			} else {
				$value = sanitize_text_field( (string) $in['value'] );
			}

			$id = '';
			if ( ! empty( $in['id'] ) ) {
				$id = self::make_id( $in['id'], 'gvid-' );
				if ( isset( $all_ids[ $id ] ) && $all_ids[ $id ] !== $type ) {
					throw new TWDB_Tool_Error( 'invalid_arguments', sprintf( '%s already exists as a %s variable. Nothing was saved.', $id, $all_ids[ $id ] ) );
				}
			} elseif ( '' !== $label ) {
				foreach ( $vars[ $type ] as $vid => $v ) {
					if ( isset( $v['label'] ) && 0 === strcasecmp( $v['label'], $label ) ) {
						$id = $vid;
						break;
					}
				}
			}
			if ( '' === $id ) {
				$id = self::make_id( '' !== $label ? $label : '', 'gvid-' );
				while ( isset( $all_ids[ $id ] ) ) {
					$id .= '-' . strtolower( wp_generate_password( 3, false ) );
				}
			}
			$exists = isset( $vars[ $type ][ $id ] );
			$max    = 0;
			foreach ( $vars[ $type ] as $v ) {
				if ( isset( $v['order'] ) && is_numeric( $v['order'] ) ) {
					$max = max( $max, (int) $v['order'] );
				}
			}
			$entry                = $exists ? $vars[ $type ][ $id ] : array( 'order' => $max + 1 );
			$entry['id']          = $id;
			$entry['label']       = '' !== $label ? $label : ( isset( $entry['label'] ) ? $entry['label'] : $id );
			$entry['value']       = $value;
			$entry['status']      = 'active';
			$entry['lastUpdated'] = self::now();
			$entry['type']        = $type;
			$vars[ $type ][ $id ] = $entry;
			$all_ids[ $id ]       = $type;
			$out[]                = array(
				'id'     => $id,
				'type'   => $type,
				'label'  => $entry['label'],
				'value'  => $value,
				'action' => $exists ? 'updated' : 'created',
				'token'  => TWDB_Divi::variable_token( $id, $type ),
			);
		}

		$deleted = array();
		foreach ( $deletes as $did ) {
			foreach ( $vars as $type => $items ) {
				if ( is_array( $items ) && isset( $items[ $did ] ) ) {
					unset( $vars[ $type ][ $did ] );
					$deleted[] = $did;
				}
			}
		}

		TWDB_Divi::save_global_variables( $vars );
		TWDB_Divi::clear_cache();
		return array(
			'message'   => sprintf( 'Saved %d variable(s), deleted %d. Restore point #%d.', count( $out ), count( $deleted ), $backup ),
			'variables' => $out,
			'deleted'   => $deleted,
			'backup_id' => $backup,
		);
	}

	/**
	 * Tool: list_presets.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function list_presets( $args ) {
		$presets = TWDB_Divi::get_presets();
		$filter  = isset( $args['module'] ) ? (string) $args['module'] : '';
		$attrs   = ! empty( $args['include_attrs'] );
		$out     = array();
		foreach ( array( 'module', 'group' ) as $bucket ) {
			foreach ( (array) $presets[ $bucket ] as $key => $info ) {
				if ( '' !== $filter && $filter !== $key ) {
					continue;
				}
				$items = array();
				foreach ( (array) ( isset( $info['items'] ) ? $info['items'] : array() ) as $pid => $p ) {
					$row = array(
						'id'          => $pid,
						'name'        => isset( $p['name'] ) ? $p['name'] : '',
						'module_name' => isset( $p['moduleName'] ) ? $p['moduleName'] : '',
						'is_default'  => isset( $info['default'] ) && $info['default'] === $pid,
						'version'     => isset( $p['version'] ) ? $p['version'] : '',
					);
					if ( 'group' === $bucket ) {
						$row['group_id'] = isset( $p['groupId'] ) ? $p['groupId'] : '';
					}
					if ( $attrs ) {
						$row['attrs'] = isset( $p['attrs'] ) ? $p['attrs'] : new stdClass();
					}
					$items[] = $row;
				}
				$out[] = array(
					'kind'    => $bucket,
					'key'     => $key,
					'default' => isset( $info['default'] ) ? $info['default'] : '',
					'items'   => $items,
				);
			}
		}
		return array( 'presets' => $out );
	}

	/**
	 * Every string inside a nested value, as a set.
	 *
	 * @param mixed $v Value.
	 * @return array
	 */
	private static function strings_of( $v ) {
		$out = array();
		array_walk_recursive(
			$v,
			static function ( $x ) use ( &$out ) {
				if ( is_string( $x ) ) {
					$out[ $x ] = true;
				}
			}
		);
		return $out;
	}

	/**
	 * Tool: upsert_preset.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On failure.
	 */
	public static function upsert_preset( $args ) {
		if ( empty( $args['attrs'] ) || ! is_array( $args['attrs'] ) ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'attrs must be a non-empty object.' );
		}
		$presets = TWDB_Divi::get_presets();
		$kind    = isset( $args['kind'] ) ? $args['kind'] : 'module';
		$now     = (int) round( microtime( true ) * 1000 );
		$version = TWDB_Divi::builder_version();

		if ( ! empty( $args['id'] ) ) {
			$loc = self::locate_preset( $presets, $args['id'] );
			if ( ! $loc ) {
				throw new TWDB_Tool_Error( 'not_found', 'No preset with id ' . $args['id'] . '.' );
			}
			list( $bucket, $key ) = $loc;
			$id                   = $args['id'];
			$preset               = $presets[ $bucket ][ $key ]['items'][ $id ];
			$action               = 'updated';
		} else {
			if ( 'group' === $kind ) {
				if ( empty( $args['group_name'] ) || empty( $args['group_id'] ) ) {
					throw new TWDB_Tool_Error( 'invalid_arguments', 'Group presets need group_name and group_id.' );
				}
				$bucket = 'group';
				$key    = sanitize_text_field( $args['group_name'] );
			} else {
				if ( empty( $args['module_name'] ) || ! preg_match( '#^[a-z0-9-]+/[a-z0-9-]+$#', $args['module_name'] ) ) {
					throw new TWDB_Tool_Error( 'invalid_arguments', 'module_name must look like "divi/button".' );
				}
				$bucket = 'module';
				$key    = $args['module_name'];
			}
			$id     = wp_generate_uuid4();
			$preset = array(
				'id'      => $id,
				'type'    => $bucket,
				'created' => $now,
			);
			if ( 'group' === $bucket ) {
				$preset['groupName']  = $key;
				$preset['groupId']    = sanitize_text_field( $args['group_id'] );
				$preset['moduleName'] = ! empty( $args['module_name'] ) ? sanitize_text_field( $args['module_name'] ) : $key;
			} else {
				$preset['moduleName'] = $key;
			}
			$action = 'created';
		}

		$backup = TWDB_Backups::create( 'presets', TWDB_Divi::presets_option(), TWDB_Divi::get_presets(), 'Presets', 'before upsert_preset' );

		// Presets are design data: no executable code. Values already stored in this preset are kept.
		$known = array();
		foreach ( array( 'attrs', 'styleAttrs', 'renderAttrs' ) as $part ) {
			if ( isset( $preset[ $part ] ) ) {
				$known += self::strings_of( $preset[ $part ] );
			}
		}
		$attrs                 = TWDB_Code_Policy::clean_value( $args['attrs'], $known );
		$preset['name']        = sanitize_text_field( $args['name'] );
		$preset['attrs']       = $attrs;
		$preset['styleAttrs']  = ! empty( $args['style_attrs'] ) && is_array( $args['style_attrs'] ) ? TWDB_Code_Policy::clean_value( $args['style_attrs'], $known ) : $attrs;
		$preset['renderAttrs'] = $attrs;
		$preset['updated']     = $now;
		$preset['version']     = $version;

		if ( ! isset( $presets[ $bucket ][ $key ] ) || ! is_array( $presets[ $bucket ][ $key ] ) ) {
			$presets[ $bucket ][ $key ] = array(
				'default' => '',
				'items'   => array(),
			);
		}
		if ( ! isset( $presets[ $bucket ][ $key ]['items'] ) || ! is_array( $presets[ $bucket ][ $key ]['items'] ) ) {
			$presets[ $bucket ][ $key ]['items'] = array();
		}
		if ( ! isset( $presets[ $bucket ][ $key ]['default'] ) ) {
			$presets[ $bucket ][ $key ]['default'] = '';
		}
		$presets[ $bucket ][ $key ]['items'][ $id ] = $preset;
		if ( ! empty( $args['make_default'] ) ) {
			$presets[ $bucket ][ $key ]['default'] = $id;
		}
		TWDB_Divi::save_presets( $presets );
		TWDB_Divi::clear_cache();
		return array(
			'message'    => sprintf( 'Preset "%s" %s (%s %s). Restore point #%d.', $preset['name'], $action, $bucket, $key, $backup ),
			'id'         => $id,
			'kind'       => $bucket,
			'key'        => $key,
			'is_default' => $presets[ $bucket ][ $key ]['default'] === $id,
			'usage'      => 'module' === $bucket ? 'Add "modulePreset":["' . $id . '"] to the block JSON.' : 'Reference via the module\'s groupPreset settings.',
			'backup_id'  => $backup,
		);
	}

	/**
	 * Tool: delete_preset.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error When missing.
	 */
	public static function delete_preset( $args ) {
		$presets = TWDB_Divi::get_presets();
		$loc     = self::locate_preset( $presets, $args['id'] );
		if ( ! $loc ) {
			throw new TWDB_Tool_Error( 'not_found', 'No preset with id ' . $args['id'] . '.' );
		}
		list( $bucket, $key ) = $loc;
		$backup               = TWDB_Backups::create( 'presets', TWDB_Divi::presets_option(), $presets, 'Presets', 'before delete_preset ' . $args['id'] );
		unset( $presets[ $bucket ][ $key ]['items'][ $args['id'] ] );
		if ( isset( $presets[ $bucket ][ $key ]['default'] ) && $presets[ $bucket ][ $key ]['default'] === $args['id'] ) {
			$presets[ $bucket ][ $key ]['default'] = '';
		}
		if ( empty( $presets[ $bucket ][ $key ]['items'] ) ) {
			unset( $presets[ $bucket ][ $key ] );
		}
		TWDB_Divi::save_presets( $presets );
		TWDB_Divi::clear_cache();
		return array(
			'message'   => sprintf( 'Preset %s deleted from %s %s. Restore point #%d.', $args['id'], $bucket, $key, $backup ),
			'backup_id' => $backup,
		);
	}
}
