<?php
/**
 * Page / post tools: list, get, create, update, trash, backups, render, validate.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pages tools.
 */
class TWDB_Tools_Pages {

	const BLANK_TEMPLATE = 'page-template-blank.php';

	/**
	 * Post types the tools may touch (filtered to those registered).
	 *
	 * @return string[]
	 */
	public static function allowed_types() {
		$types = array( 'page', 'post', 'project', 'et_header_layout', 'et_body_layout', 'et_footer_layout', 'et_pb_layout' );
		$types = apply_filters( 'twdb_allowed_post_types', $types );
		return array_values( array_filter( $types, 'post_type_exists' ) );
	}

	/**
	 * Definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		$id         = TWDB_Tools::prop( 'integer', 'Post/page ID.', array( 'minimum' => 1 ) );
		$content    = TWDB_Tools::prop( 'string', 'Full Divi 5 block markup. Must start with <!-- wp:divi/placeholder --> and end with <!-- /wp:divi/placeholder -->. Every block needs "builderVersion"; module attributes go at the top level of the block JSON (never inside "attrs"); HTML inside values is raw.' );
		$template   = TWDB_Tools::prop( 'string', '"default" keeps the theme header/footer (Theme Builder templates apply). "blank" uses Divi\'s Blank Page template (no header/footer; Theme Builder chrome suppressed).', array( 'enum' => array( 'default', 'blank' ) ) );
		$status     = TWDB_Tools::prop( 'string', 'Post status.', array( 'enum' => array( 'draft', 'publish', 'pending', 'private' ) ) );
		$list_props = array(
			'status'   => TWDB_Tools::prop( 'string', 'Filter by status (default: any non-trashed).', array( 'enum' => array( 'any', 'publish', 'draft', 'pending', 'private', 'future', 'trash' ) ) ),
			'search'   => TWDB_Tools::prop( 'string', 'Search term (title/content).' ),
			'parent'   => TWDB_Tools::prop( 'integer', 'Only children of this page ID (0 = top level).', array( 'minimum' => 0 ) ),
			'per_page' => TWDB_Tools::prop(
				'integer',
				'Results per page (1-100, default 50).',
				array(
					'minimum' => 1,
					'maximum' => 100,
				)
			),
			'page'     => TWDB_Tools::prop( 'integer', 'Page number (default 1).', array( 'minimum' => 1 ) ),
		);

		return array(
			array(
				'name'         => 'list_pages',
				'group'        => 'pages',
				'title'        => 'List pages',
				'description'  => 'Lists pages (or another allowed post type such as project, et_pb_layout, et_header_layout) with ID, title, status, slug, URL, template, parent, whether Divi is used and whether it is the front/posts page.',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array_merge(
						array( 'post_type' => TWDB_Tools::prop( 'string', 'Post type (default "page").', array( 'enum' => self::allowed_types() ) ) ),
						$list_props
					),
				),
				'callback'     => array( __CLASS__, 'list_pages' ),
			),
			array(
				'name'         => 'list_posts',
				'group'        => 'pages',
				'title'        => 'List blog posts',
				'description'  => 'Lists blog posts with ID, title, status, slug, URL and date.',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => $list_props,
				),
				'callback'     => array( __CLASS__, 'list_posts' ),
			),
			array(
				'name'         => 'get_page',
				'group'        => 'pages',
				'title'        => 'Get page',
				'description'  => 'Returns a page/post by ID (or slug): title, status, URL, template, Divi meta, per-page custom CSS and the raw Divi 5 block markup. Use before update_page so you edit the current content.',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'id'              => $id,
						'slug'            => TWDB_Tools::prop( 'string', 'Slug (used when id is not given).' ),
						'post_type'       => TWDB_Tools::prop( 'string', 'Post type for slug lookup (default page).', array( 'enum' => self::allowed_types() ) ),
						'include_content' => TWDB_Tools::prop( 'boolean', 'Include raw markup (default true).' ),
						'max_chars'       => TWDB_Tools::prop( 'integer', 'Truncate content to this many characters (default 300000).', array( 'minimum' => 1000 ) ),
					),
				),
				'callback'     => array( __CLASS__, 'get_page' ),
			),
			array(
				'name'         => 'validate_markup',
				'group'        => 'pages',
				'title'        => 'Validate Divi markup',
				'description'  => 'Checks Divi 5 block markup without saving: placeholder wrapper, balanced block comments, valid JSON attributes, no "attrs" wrapper, divi/text uses "content", builderVersion present, nesting. Returns errors (would block saving) and warnings.',
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'content' ),
					'properties' => array(
						'content'             => $content,
						'require_placeholder' => TWDB_Tools::prop( 'boolean', 'Require the divi/placeholder wrapper (default true; set false for a single section/module snippet).' ),
					),
				),
				'callback'     => array( __CLASS__, 'validate_markup' ),
			),
			array(
				'name'         => 'create_page',
				'group'        => 'pages',
				'title'        => 'Create page',
				'description'  => 'Creates a page (or post/project) from Divi 5 block markup and sets the Divi builder meta (_et_pb_use_builder=on, _et_pb_use_divi_5=on, full-width layout). Markup is validated first; errors block saving. Defaults to draft - publish only when the user asked. Returns the ID, URL, Visual Builder URL and a 1-hour preview link that works without login.',
				'write'        => true,
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'title' ),
					'properties' => array(
						'title'          => TWDB_Tools::prop( 'string', 'Title.', array( 'minLength' => 1 ) ),
						'content'        => $content,
						'status'         => $status,
						'slug'           => TWDB_Tools::prop( 'string', 'URL slug.' ),
						'parent'         => TWDB_Tools::prop( 'integer', 'Parent page ID.', array( 'minimum' => 0 ) ),
						'template'       => $template,
						'post_type'      => TWDB_Tools::prop( 'string', 'page (default), post or project.', array( 'enum' => array_values( array_intersect( array( 'page', 'post', 'project' ), self::allowed_types() ) ) ) ),
						'excerpt'        => TWDB_Tools::prop( 'string', 'Excerpt.' ),
						'menu_order'     => TWDB_Tools::prop( 'integer', 'Menu order.' ),
						'auto_wrap'      => TWDB_Tools::prop( 'boolean', 'Wrap the markup in divi/placeholder if missing (default false).' ),
						'allow_non_divi' => TWDB_Tools::prop( 'boolean', 'Save non-Divi content (plain HTML / Gutenberg blocks) without the placeholder requirement and without Divi builder meta (default false).' ),
					),
				),
				'callback'     => array( __CLASS__, 'create_page' ),
			),
			array(
				'name'         => 'update_page',
				'group'        => 'pages',
				'title'        => 'Update page',
				'description'  => 'Updates a page/post. Saves a restore point first (see list_backups / restore_backup). Content can be replaced entirely, sections appended/prepended inside the placeholder, or an exact text snippet replaced (find + replace_with). Also updates title, status, slug, parent, template, excerpt. The resulting markup is validated; errors block saving.',
				'write'        => true,
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'id' ),
					'properties' => array(
						'id'             => $id,
						'content'        => TWDB_Tools::prop( 'string', 'New markup. With content_mode "replace" this is the full page (placeholder-wrapped); with "append"/"prepend" it is one or more sections (no placeholder).' ),
						'content_mode'   => TWDB_Tools::prop( 'string', 'How to apply content (default replace).', array( 'enum' => array( 'replace', 'append', 'prepend' ) ) ),
						'find'           => TWDB_Tools::prop( 'string', 'Exact text to find in the current markup (surgical edit). Must exist.' ),
						'replace_with'   => TWDB_Tools::prop( 'string', 'Replacement for "find".' ),
						'replace_all'    => TWDB_Tools::prop( 'boolean', 'Replace every occurrence of "find" (default: only when it occurs once; error if ambiguous).' ),
						'title'          => TWDB_Tools::prop( 'string', 'Title.' ),
						'status'         => $status,
						'slug'           => TWDB_Tools::prop( 'string', 'Slug.' ),
						'parent'         => TWDB_Tools::prop( 'integer', 'Parent ID.', array( 'minimum' => 0 ) ),
						'template'       => $template,
						'excerpt'        => TWDB_Tools::prop( 'string', 'Excerpt.' ),
						'menu_order'     => TWDB_Tools::prop( 'integer', 'Menu order.' ),
						'auto_wrap'      => TWDB_Tools::prop( 'boolean', 'Wrap replacement markup in divi/placeholder if missing (default false).' ),
						'allow_non_divi' => TWDB_Tools::prop( 'boolean', 'Skip the placeholder requirement for non-Divi content (default false).' ),
					),
				),
				'callback'     => array( __CLASS__, 'update_page' ),
			),
			array(
				'name'         => 'trash_page',
				'group'        => 'pages',
				'title'        => 'Trash page',
				'description'  => 'Moves a page/post to the Trash (recoverable from WP Admin or with restore_backup). Saves a restore point first. Refuses the front page / posts page unless force is true. Confirm with the user before calling.',
				'write'        => true,
				'destructive'  => true,
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'id' ),
					'properties' => array(
						'id'    => $id,
						'force' => TWDB_Tools::prop( 'boolean', 'Allow trashing the front page or posts page.' ),
					),
				),
				'callback'     => array( __CLASS__, 'trash_page' ),
			),
			array(
				'name'         => 'list_backups',
				'group'        => 'pages',
				'title'        => 'List restore points',
				'description'  => 'Lists restore points saved automatically before every overwrite (pages, global colors, variables, presets, custom CSS, Theme Builder layouts). The last 25 per object are kept.',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'kind'    => TWDB_Tools::prop( 'string', 'Filter by kind.', array( 'enum' => array( 'post', 'global_colors', 'global_variables', 'presets', 'plugin_css', 'wp_custom_css' ) ) ),
						'post_id' => TWDB_Tools::prop( 'integer', 'Only backups of this post.', array( 'minimum' => 1 ) ),
						'limit'   => TWDB_Tools::prop(
							'integer',
							'Max results (default 30).',
							array(
								'minimum' => 1,
								'maximum' => 200,
							)
						),
					),
				),
				'callback'     => array( __CLASS__, 'list_backups' ),
			),
			array(
				'name'         => 'restore_backup',
				'group'        => 'pages',
				'title'        => 'Restore a backup',
				'description'  => 'Restores a restore point from list_backups (page content + title/status/slug/template/Divi meta, or the global colors / variables / presets / custom CSS). The current state is backed up first, so a restore can itself be undone. Untrashes a trashed page.',
				'write'        => true,
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'backup_id' ),
					'properties' => array(
						'backup_id' => TWDB_Tools::prop( 'integer', 'Backup ID from list_backups.', array( 'minimum' => 1 ) ),
					),
				),
				'callback'     => array( __CLASS__, 'restore_backup' ),
			),
			array(
				'name'         => 'render_page',
				'group'        => 'pages',
				'title'        => 'Render page',
				'description'  => 'Renders a page so you can verify the output. mode "content" (default) runs the_content server-side and returns the module HTML; mode "full" fetches the real front-end page over HTTP (theme header/footer, Divi CSS) - drafts use a signed preview link. Also returns the URL and a 1-hour preview link the user can open without logging in.',
				'beta'         => true,
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'id' ),
					'properties' => array(
						'id'            => $id,
						'mode'          => TWDB_Tools::prop( 'string', 'content or full.', array( 'enum' => array( 'content', 'full' ) ) ),
						'strip_scripts' => TWDB_Tools::prop( 'boolean', 'Remove <script> blocks (default true).' ),
						'strip_styles'  => TWDB_Tools::prop( 'boolean', 'Remove <style> blocks (default false; mode "full" strips them unless include_head is true).' ),
						'include_head'  => TWDB_Tools::prop( 'boolean', 'Mode "full" only: return the whole document including <head> (default false = only the <body>).' ),
						'max_chars'     => TWDB_Tools::prop(
							'integer',
							'Truncate HTML (default 60000).',
							array(
								'minimum' => 1000,
								'maximum' => 500000,
							)
						),
					),
				),
				'callback'     => array( __CLASS__, 'render_page' ),
			),
		);
	}

	/* -------------------- Helpers -------------------- */

	/**
	 * Load a post the tools may touch.
	 *
	 * @param int  $id        ID.
	 * @param bool $for_write Check edit permission.
	 * @return WP_Post
	 * @throws TWDB_Tool_Error When missing / not allowed.
	 */
	public static function load( $id, $for_write = false ) {
		$post = get_post( (int) $id );
		if ( ! $post || ! in_array( $post->post_type, self::allowed_types(), true ) ) {
			throw new TWDB_Tool_Error( 'not_found', sprintf( 'No page/post with ID %d.', (int) $id ) );
		}
		if ( ! current_user_can( $for_write ? 'edit_post' : 'read_post', $post->ID ) ) {
			throw new TWDB_Tool_Error( 'forbidden', 'The acting user cannot ' . ( $for_write ? 'edit' : 'read' ) . ' this item.' );
		}
		if ( $for_write ) {
			self::check_type_cap( $post->post_type );
		}
		return $post;
	}

	/**
	 * Theme Builder layouts are site-wide (every page's header, body or footer): changing them needs the same
	 * capability as the Theme Builder tools, not just the right to edit a post.
	 *
	 * @param string $post_type Post type.
	 * @throws TWDB_Tool_Error When not allowed.
	 */
	public static function check_type_cap( $post_type ) {
		if ( in_array( $post_type, array( 'et_header_layout', 'et_body_layout', 'et_footer_layout', 'et_template', 'et_theme_builder' ), true ) && ! current_user_can( 'edit_theme_options' ) ) {
			throw new TWDB_Tool_Error( 'forbidden', 'Theme Builder layouts apply to the whole site; the acting user needs the edit_theme_options capability to change them.' );
		}
	}

	/**
	 * Validate a parent id: an existing item of the same type that the acting user can read.
	 *
	 * @param int    $parent_id Parent id (0 = none).
	 * @param string $type      Post type.
	 * @param int    $self_id   The post being changed (0 when creating).
	 * @throws TWDB_Tool_Error When invalid.
	 */
	private static function check_parent( $parent_id, $type, $self_id = 0 ) {
		$parent_id = (int) $parent_id;
		if ( ! $parent_id ) {
			return;
		}
		if ( $self_id && $parent_id === (int) $self_id ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'A page cannot be its own parent.' );
		}
		$parent = get_post( $parent_id );
		if ( ! $parent || $parent->post_type !== $type || ! current_user_can( 'read_post', $parent_id ) ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Parent must be an existing ' . $type . '.' );
		}
		if ( $self_id && in_array( (int) $self_id, array_map( 'intval', get_post_ancestors( $parent ) ), true ) ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'That parent is a descendant of this page.' );
		}
	}

	/**
	 * Summary of a post.
	 *
	 * @param WP_Post $p Post.
	 * @return array
	 */
	public static function summary( $p ) {
		$tpl = (string) get_post_meta( $p->ID, '_wp_page_template', true );
		return array(
			'id'        => $p->ID,
			'title'     => html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ),
			'status'    => $p->post_status,
			'post_type' => $p->post_type,
			'slug'      => $p->post_name,
			'url'       => get_permalink( $p ),
			'parent'    => (int) $p->post_parent,
			'template'  => self::BLANK_TEMPLATE === $tpl ? 'blank' : ( '' === $tpl || 'default' === $tpl ? 'default' : $tpl ),
			'uses_divi' => 'on' === get_post_meta( $p->ID, '_et_pb_use_builder', true ),
			'is_front'  => (int) get_option( 'page_on_front' ) === $p->ID,
			'is_posts'  => (int) get_option( 'page_for_posts' ) === $p->ID,
			'modified'  => get_post_modified_time( 'c', false, $p ),
			'date'      => get_post_time( 'c', false, $p ),
		);
	}

	/**
	 * Visual Builder URL.
	 *
	 * @param int $id ID.
	 * @return string
	 */
	public static function builder_url( $id ) {
		return add_query_arg( 'et_fb', '1', get_permalink( $id ) );
	}

	/**
	 * Apply Divi builder meta.
	 *
	 * @param int    $id        ID.
	 * @param string $post_type Post type.
	 */
	public static function apply_divi_meta( $id, $post_type ) {
		update_post_meta( $id, '_et_pb_use_builder', 'on' );
		update_post_meta( $id, '_et_pb_use_divi_5', 'on' );
		update_post_meta( $id, '_et_pb_show_page_creation', 'off' );
		if ( in_array( $post_type, array( 'page', 'post', 'project' ), true ) ) {
			update_post_meta( $id, '_et_pb_page_layout', 'et_full_width_page' );
			update_post_meta( $id, '_et_pb_built_for_post_type', $post_type );
		} else {
			update_post_meta( $id, '_et_pb_built_for_post_type', 'page' );
		}
	}

	/**
	 * wp_update_post() wrapper that tolerates a page template the active theme lacks.
	 *
	 * @param array $postarr Post array (unslashed).
	 * @return int|WP_Error
	 */
	public static function safe_update_post( $postarr ) {
		// wp_update_post() re-submits the stored page template and fails AFTER saving
		// when the active theme does not provide it (e.g. Divi's blank template while
		// another theme is active). Park the meta on "default" during the update.
		$id      = (int) $postarr['ID'];
		$current = (string) get_post_meta( $id, '_wp_page_template', true );
		$parked  = false;
		if ( '' !== $current && 'default' !== $current ) {
			$post      = get_post( $id );
			$templates = $post ? wp_get_theme()->get_page_templates( $post ) : array();
			if ( ! isset( $templates[ $current ] ) ) {
				update_post_meta( $id, '_wp_page_template', 'default' );
				$parked = true;
			}
		}
		$r = wp_update_post( wp_slash( $postarr ), true );
		if ( $parked ) {
			update_post_meta( $id, '_wp_page_template', $current );
		}
		return $r;
	}

	/**
	 * Set the page template meta.
	 *
	 * @param int    $id       ID.
	 * @param string $template default|blank.
	 */
	public static function apply_template( $id, $template ) {
		if ( 'blank' === $template ) {
			update_post_meta( $id, '_wp_page_template', self::BLANK_TEMPLATE );
		} elseif ( 'default' === $template ) {
			update_post_meta( $id, '_wp_page_template', 'default' );
		}
	}

	/**
	 * Validate (and maybe wrap) content.
	 *
	 * @param string $content Content.
	 * @param array  $args    Args (auto_wrap, allow_non_divi).
	 * @param string $old     Content currently stored for this post ('' when creating).
	 * @return array [content, validation]
	 * @throws TWDB_Tool_Error On invalid markup.
	 */
	public static function prepare_content( $content, $args, $old = '' ) {
		$non_divi = ! empty( $args['allow_non_divi'] );
		if ( ! $non_divi && ! empty( $args['auto_wrap'] ) ) {
			$content = TWDB_Markup::ensure_wrapper( $content );
		}
		$v = TWDB_Markup::validate( $content, ! $non_divi );
		if ( ! $v['valid'] ) {
			throw new TWDB_Tool_Error( 'invalid_markup', 'Markup failed validation; nothing was saved. Fix the errors and retry (get_divi_reference topic "rules").', $v );
		}
		// No executable code from the AI; unchanged existing values are kept as they are.
		$content = TWDB_Code_Policy::clean_markup( $content, $old );
		return array( $content, $v );
	}

	/**
	 * Warn if WordPress filtered the saved content.
	 *
	 * @param int    $id       ID.
	 * @param string $intended Intended content.
	 * @return string|null
	 */
	private static function kses_warning( $id, $intended ) {
		$saved = (string) get_post_field( 'post_content', $id, 'raw' );
		if ( ! current_user_can( 'unfiltered_html' ) ) {
			$intended = TWDB_Markup::canonical( $intended ); // Saved in canonical form before filtering.
		}
		if ( trim( $saved ) !== trim( $intended ) ) {
			return current_user_can( 'unfiltered_html' )
				? 'Saved content differs from what was sent (a plugin filtered it). Check get_page.'
				: 'WordPress filtered the saved content because the acting user lacks unfiltered_html (some tags and attributes removed). Divi structure was kept.';
		}
		return null;
	}

	/**
	 * Check status permission.
	 *
	 * @param string $post_type Post type.
	 * @param string $status    Status.
	 * @throws TWDB_Tool_Error When not allowed.
	 */
	private static function check_status_cap( $post_type, $status ) {
		$pto = get_post_type_object( $post_type );
		if ( in_array( $status, array( 'publish', 'private', 'future' ), true ) && $pto && ! current_user_can( $pto->cap->publish_posts ) ) {
			throw new TWDB_Tool_Error( 'forbidden', 'The acting user cannot publish ' . $post_type . 's. Use status "draft" or "pending".' );
		}
	}

	/* -------------------- Tools -------------------- */

	/**
	 * Tool: list_pages.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function list_pages( $args ) {
		$type = isset( $args['post_type'] ) ? $args['post_type'] : 'page';
		return self::query( $type, $args );
	}

	/**
	 * Tool: list_posts.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function list_posts( $args ) {
		return self::query( 'post', $args );
	}

	/**
	 * Shared listing.
	 *
	 * @param string $type Post type.
	 * @param array  $args Args.
	 * @return array
	 */
	private static function query( $type, $args ) {
		$status = isset( $args['status'] ) ? $args['status'] : 'any';
		$per    = isset( $args['per_page'] ) ? (int) $args['per_page'] : 50;
		$page   = isset( $args['page'] ) ? (int) $args['page'] : 1;
		$q      = array(
			'post_type'      => $type,
			'post_status'    => 'any' === $status ? array( 'publish', 'draft', 'pending', 'private', 'future' ) : $status,
			'posts_per_page' => $per,
			'paged'          => $page,
			'orderby'        => 'page' === $type ? 'menu_order title' : 'date',
			'order'          => 'page' === $type ? 'ASC' : 'DESC',
		);
		if ( ! empty( $args['search'] ) ) {
			$q['s'] = $args['search'];
		}
		if ( isset( $args['parent'] ) ) {
			$q['post_parent'] = (int) $args['parent'];
		}
		$wpq   = new WP_Query( $q );
		$items = array();
		foreach ( $wpq->posts as $p ) {
			if ( current_user_can( 'read_post', $p->ID ) ) {
				$items[] = self::summary( $p );
			}
		}
		return array(
			'post_type'   => $type,
			'total'       => (int) $wpq->found_posts,
			'total_pages' => (int) $wpq->max_num_pages,
			'page'        => $page,
			'items'       => $items,
		);
	}

	/**
	 * Tool: get_page.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error When missing.
	 */
	public static function get_page( $args ) {
		if ( ! empty( $args['id'] ) ) {
			$post = self::load( $args['id'] );
		} elseif ( ! empty( $args['slug'] ) ) {
			$type  = isset( $args['post_type'] ) ? $args['post_type'] : 'page';
			$found = get_posts(
				array(
					'name'           => sanitize_title( $args['slug'] ),
					'post_type'      => $type,
					'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
					'posts_per_page' => 1,
				)
			);
			if ( ! $found ) {
				$by_path = get_page_by_path( $args['slug'], OBJECT, $type );
				$found   = $by_path ? array( $by_path ) : array();
			}
			if ( ! $found ) {
				throw new TWDB_Tool_Error( 'not_found', 'No ' . $type . ' with that slug.' );
			}
			$post = self::load( $found[0]->ID );
		} else {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Provide id or slug.' );
		}

		$out         = self::summary( $post );
		$out['meta'] = array();
		foreach ( TWDB_Backups::DIVI_METAS as $key ) {
			$out['meta'][ $key ] = get_post_meta( $post->ID, $key, true );
		}
		$out['custom_css']  = (string) get_post_meta( $post->ID, '_et_pb_custom_css', true );
		$out['excerpt']     = $post->post_excerpt;
		$out['menu_order']  = (int) $post->menu_order;
		$out['builder_url'] = self::builder_url( $post->ID );
		if ( ! isset( $args['include_content'] ) || $args['include_content'] ) {
			$max                      = isset( $args['max_chars'] ) ? (int) $args['max_chars'] : 300000;
			$content                  = (string) $post->post_content;
			$out['content_length']    = strlen( $content );
			$out['content_truncated'] = strlen( $content ) > $max;
			$out['content']           = $out['content_truncated'] ? TWDB_Text::cut( $content, 0, $max ) : $content;
		}
		return $out;
	}

	/**
	 * Tool: validate_markup.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function validate_markup( $args ) {
		$req = ! isset( $args['require_placeholder'] ) || $args['require_placeholder'];
		return TWDB_Markup::validate( $args['content'], $req );
	}

	/**
	 * Tool: create_page.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On failure.
	 */
	public static function create_page( $args ) {
		$type = isset( $args['post_type'] ) ? $args['post_type'] : 'page';
		self::check_type_cap( $type );
		$pto = get_post_type_object( $type );
		if ( ! $pto || ! current_user_can( $pto->cap->create_posts ) ) {
			throw new TWDB_Tool_Error( 'forbidden', 'The acting user cannot create ' . $type . 's.' );
		}
		$status = isset( $args['status'] ) ? $args['status'] : 'draft';
		self::check_status_cap( $type, $status );

		$non_divi = ! empty( $args['allow_non_divi'] );
		$content  = isset( $args['content'] ) ? (string) $args['content'] : '';
		$v        = null;
		if ( '' === trim( $content ) ) {
			$content = $non_divi ? '' : TWDB_Markup::PLACEHOLDER_OPEN . "\n" . TWDB_Markup::PLACEHOLDER_CLOSE;
		} else {
			list( $content, $v ) = self::prepare_content( $content, $args );
		}

		if ( ! empty( $args['parent'] ) ) {
			self::check_parent( $args['parent'], $type );
		}

		$postarr = array(
			'post_type'    => $type,
			'post_title'   => TWDB_Code_Policy::clean_text( $args['title'] ),
			'post_content' => $content,
			'post_status'  => $status,
			'post_author'  => get_current_user_id(),
		);
		if ( ! empty( $args['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( $args['slug'] );
		}
		if ( ! empty( $args['parent'] ) ) {
			$postarr['post_parent'] = (int) $args['parent'];
		}
		if ( isset( $args['excerpt'] ) ) {
			$postarr['post_excerpt'] = TWDB_Code_Policy::clean_text( $args['excerpt'] );
		}
		if ( isset( $args['menu_order'] ) ) {
			$postarr['menu_order'] = (int) $args['menu_order'];
		}

		$id = wp_insert_post( wp_slash( $postarr ), true );
		if ( is_wp_error( $id ) ) {
			throw new TWDB_Tool_Error( 'save_failed', $id->get_error_message() );
		}
		if ( ! $non_divi ) {
			self::apply_divi_meta( $id, $type );
		}
		self::apply_template( $id, isset( $args['template'] ) ? $args['template'] : 'default' );
		TWDB_Divi::clear_cache( $id );

		$warnings = $v ? $v['warnings'] : array();
		$kw       = self::kses_warning( $id, $content );
		if ( $kw ) {
			$warnings[] = $kw;
		}
		$ds = TWDB_Divi::status();
		if ( ! $ds['active'] && ! $non_divi ) {
			$warnings[] = 'Divi is not active on this site, so the page will not render as a Divi layout until Divi 5 is activated.';
		} elseif ( ! $ds['is_divi5'] && ! $non_divi ) {
			$warnings[] = sprintf( 'This site runs %s %s, not Divi 5, so Divi 5 block markup will not render correctly.', $ds['product'], $ds['version'] );
		}
		$post = get_post( $id );
		return array_merge(
			self::summary( $post ),
			array(
				'message'     => sprintf( 'Created %s #%d "%s" (%s).', $type, $id, $post->post_title, $post->post_status ),
				'builder_url' => self::builder_url( $id ),
				'preview_url' => TWDB_Frontend::preview_url( $id ),
				'warnings'    => $warnings,
			)
		);
	}

	/**
	 * Tool: update_page.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On failure.
	 */
	public static function update_page( $args ) {
		$post    = self::load( $args['id'], true );
		$postarr = array( 'ID' => $post->ID );
		$changed = array();
		$v       = null;
		$content = null;

		$has_content = isset( $args['content'] ) && '' !== $args['content'];
		$has_find    = isset( $args['find'] ) && '' !== $args['find'];
		if ( $has_content && $has_find ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Use either content or find/replace_with, not both.' );
		}

		if ( $has_content ) {
			$mode = isset( $args['content_mode'] ) ? $args['content_mode'] : 'replace';
			if ( 'replace' === $mode ) {
				$content = (string) $args['content'];
			} else {
				$snippet = trim( (string) $args['content'] );
				$v_snip  = TWDB_Markup::validate( $snippet, false );
				if ( ! $v_snip['valid'] ) {
					throw new TWDB_Tool_Error( 'invalid_markup', 'The snippet failed validation; nothing was saved.', $v_snip );
				}
				if ( 0 === strpos( $snippet, TWDB_Markup::PLACEHOLDER_OPEN ) ) {
					throw new TWDB_Tool_Error( 'invalid_arguments', 'With content_mode append/prepend, send sections only (no divi/placeholder wrapper).' );
				}
				$current = trim( (string) $post->post_content );
				if ( '' === $current ) {
					$current = TWDB_Markup::PLACEHOLDER_OPEN . "\n" . TWDB_Markup::PLACEHOLDER_CLOSE;
				}
				$open  = TWDB_Markup::PLACEHOLDER_OPEN;
				$close = TWDB_Markup::PLACEHOLDER_CLOSE;
				if ( 0 !== strpos( $current, $open ) || substr( $current, -strlen( $close ) ) !== $close ) {
					throw new TWDB_Tool_Error( 'invalid_arguments', 'The current content is not wrapped in divi/placeholder, so append/prepend is not possible. Use content_mode "replace".' );
				}
				$inner   = trim( substr( $current, strlen( $open ), -strlen( $close ) ) );
				$inner   = 'append' === $mode ? trim( $inner . "\n" . $snippet ) : trim( $snippet . "\n" . $inner );
				$content = $open . "\n" . $inner . "\n" . $close;
			}
			$changed[] = 'content(' . $mode . ')';
		} elseif ( $has_find ) {
			$current = (string) $post->post_content;
			$count   = substr_count( $current, $args['find'] );
			if ( 0 === $count ) {
				throw new TWDB_Tool_Error( 'not_found', 'The "find" text does not occur in the current content. Call get_page and copy the exact text.' );
			}
			if ( $count > 1 && empty( $args['replace_all'] ) ) {
				throw new TWDB_Tool_Error( 'ambiguous', sprintf( '"find" occurs %d times. Make it more specific or set replace_all true.', $count ) );
			}
			$with      = isset( $args['replace_with'] ) ? (string) $args['replace_with'] : '';
			$content   = str_replace( $args['find'], $with, $current );
			$changed[] = sprintf( 'content(find/replace x%d)', $count );
		}

		if ( null !== $content ) {
			list( $content, $v )     = self::prepare_content( $content, $args, (string) $post->post_content );
			$postarr['post_content'] = $content;
		}
		if ( isset( $args['title'] ) && '' !== $args['title'] ) {
			$postarr['post_title'] = TWDB_Code_Policy::clean_text( $args['title'], $post->post_title );
			$changed[]             = 'title';
		}
		if ( isset( $args['status'] ) ) {
			self::check_status_cap( $post->post_type, $args['status'] );
			$postarr['post_status'] = $args['status'];
			$changed[]              = 'status';
		}
		if ( isset( $args['slug'] ) && '' !== $args['slug'] ) {
			$postarr['post_name'] = sanitize_title( $args['slug'] );
			$changed[]            = 'slug';
		}
		if ( isset( $args['parent'] ) ) {
			self::check_parent( $args['parent'], $post->post_type, $post->ID );
			$postarr['post_parent'] = (int) $args['parent'];
			$changed[]              = 'parent';
		}
		if ( isset( $args['excerpt'] ) ) {
			$postarr['post_excerpt'] = TWDB_Code_Policy::clean_text( $args['excerpt'], $post->post_excerpt );
			$changed[]               = 'excerpt';
		}
		if ( isset( $args['menu_order'] ) ) {
			$postarr['menu_order'] = (int) $args['menu_order'];
			$changed[]             = 'menu_order';
		}
		if ( isset( $args['template'] ) ) {
			$changed[] = 'template';
		}
		if ( ! $changed ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Nothing to update. Pass content, find/replace_with, title, status, slug, parent, template, excerpt or menu_order.' );
		}

		$backup_id = TWDB_Backups::backup_post( $post->ID, 'before update_page: ' . implode( ', ', $changed ) );

		if ( count( $postarr ) > 1 ) {
			$r = self::safe_update_post( $postarr );
			if ( is_wp_error( $r ) ) {
				throw new TWDB_Tool_Error( 'save_failed', $r->get_error_message() );
			}
		}
		if ( null !== $content && empty( $args['allow_non_divi'] ) ) {
			self::apply_divi_meta( $post->ID, $post->post_type );
		}
		if ( isset( $args['template'] ) ) {
			self::apply_template( $post->ID, $args['template'] );
		}
		TWDB_Divi::clear_cache( $post->ID );

		$warnings = $v ? $v['warnings'] : array();
		if ( null !== $content ) {
			$kw = self::kses_warning( $post->ID, $content );
			if ( $kw ) {
				$warnings[] = $kw;
			}
		}
		$fresh = get_post( $post->ID );
		return array_merge(
			self::summary( $fresh ),
			array(
				'message'     => sprintf( 'Updated %s #%d (%s). Restore point #%d.', $fresh->post_type, $fresh->ID, implode( ', ', $changed ), $backup_id ),
				'backup_id'   => $backup_id,
				'builder_url' => self::builder_url( $fresh->ID ),
				'preview_url' => TWDB_Frontend::preview_url( $fresh->ID ),
				'warnings'    => $warnings,
			)
		);
	}

	/**
	 * Tool: trash_page.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On failure.
	 */
	public static function trash_page( $args ) {
		$post = self::load( $args['id'], true );
		if ( ! current_user_can( 'delete_post', $post->ID ) ) {
			throw new TWDB_Tool_Error( 'forbidden', 'The acting user cannot delete this item.' );
		}
		if ( 'trash' === $post->post_status ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Already in the Trash.' );
		}
		$special = in_array( $post->ID, array( (int) get_option( 'page_on_front' ), (int) get_option( 'page_for_posts' ) ), true );
		if ( $special && empty( $args['force'] ) ) {
			throw new TWDB_Tool_Error( 'refused', 'This is the front page or posts page. Pass force true (after confirming with the user) to trash it.' );
		}
		$backup_id = TWDB_Backups::backup_post( $post->ID, 'before trash_page' );
		$r         = wp_trash_post( $post->ID );
		if ( ! $r ) {
			throw new TWDB_Tool_Error( 'save_failed', 'WordPress could not trash the item.' );
		}
		return array(
			'id'        => $post->ID,
			'status'    => 'trash',
			'backup_id' => $backup_id,
			'message'   => sprintf( 'Trashed %s #%d "%s". Restore with restore_backup %d or from WP Admin > Trash.', $post->post_type, $post->ID, $post->post_title, $backup_id ),
		);
	}

	/**
	 * Tool: list_backups.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function list_backups( $args ) {
		$kind   = isset( $args['kind'] ) ? $args['kind'] : '';
		$object = '';
		if ( ! empty( $args['post_id'] ) ) {
			$kind   = 'post';
			$object = (string) (int) $args['post_id'];
		}
		$limit = isset( $args['limit'] ) ? (int) $args['limit'] : 30;
		$out   = array();
		foreach ( TWDB_Backups::list_backups( $kind, $object, $limit ) as $b ) {
			// Only restore points of things the acting user may see (labels carry post titles).
			if ( 'post' === $b['kind'] ? current_user_can( 'read_post', (int) $b['object'] ) : current_user_can( 'edit_theme_options' ) ) {
				$out[] = $b;
			}
		}
		return array( 'backups' => $out );
	}

	/**
	 * Tool: restore_backup.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On failure.
	 */
	public static function restore_backup( $args ) {
		$b = TWDB_Backups::get( (int) $args['backup_id'] );
		if ( ! $b || ( ! is_array( $b['payload'] ) && 'plugin_css' !== $b['kind'] ) ) {
			throw new TWDB_Tool_Error( 'not_found', 'Backup not found or unreadable.' );
		}
		$payload = $b['payload'];
		switch ( $b['kind'] ) {
			case 'post':
				$post_id = (int) $b['object'];
				$post    = get_post( $post_id );
				if ( ! $post ) {
					throw new TWDB_Tool_Error( 'not_found', 'The original post no longer exists (permanently deleted).' );
				}
				if ( ! current_user_can( 'edit_post', $post_id ) ) {
					throw new TWDB_Tool_Error( 'forbidden', 'The acting user cannot edit this item.' );
				}
				self::check_type_cap( $post->post_type );
				$status = 'trash' === $payload['post_status'] ? 'draft' : (string) $payload['post_status'];
				// A restore must not publish what the acting user could not publish directly.
				self::check_status_cap( $post->post_type, $status );
				$pre = TWDB_Backups::backup_post( $post_id, 'before restore_backup #' . $b['backup_id'] );
				if ( 'trash' === $post->post_status ) {
					wp_untrash_post( $post_id );
				}
				$r = self::safe_update_post(
					array(
						'ID'           => $post_id,
						'post_title'   => $payload['post_title'],
						'post_content' => $payload['post_content'],
						'post_status'  => $status,
						'post_name'    => $payload['post_name'],
						'post_parent'  => (int) $payload['post_parent'],
					)
				);
				if ( is_wp_error( $r ) ) {
					throw new TWDB_Tool_Error( 'save_failed', $r->get_error_message() );
				}
				foreach ( (array) $payload['meta'] as $key => $val ) {
					if ( ! in_array( $key, TWDB_Backups::DIVI_METAS, true ) ) {
						continue;
					}
					if ( '' === $val || null === $val ) {
						delete_post_meta( $post_id, $key );
					} else {
						update_post_meta( $post_id, $key, wp_slash( $val ) );
					}
				}
				TWDB_Divi::clear_cache( $post_id );
				return array(
					'message'            => sprintf( 'Restored %s #%d from backup #%d. Previous state saved as #%d.', $post->post_type, $post_id, $b['backup_id'], $pre ),
					'post'               => self::summary( get_post( $post_id ) ),
					'pre_restore_backup' => $pre,
				);

			case 'global_colors':
			case 'global_variables':
			case 'presets':
				TWDB_Divi::require_divi();
				TWDB_Tools::need( 'edit_theme_options' );
				if ( 'global_colors' === $b['kind'] ) {
					$pre = TWDB_Backups::create( 'global_colors', 'et_global_data', TWDB_Divi::get_global_colors(), 'Global colors', 'before restore_backup #' . $b['backup_id'] );
					TWDB_Divi::save_global_colors( $payload );
				} elseif ( 'global_variables' === $b['kind'] ) {
					$pre = TWDB_Backups::create( 'global_variables', TWDB_Divi::variables_option(), TWDB_Divi::get_global_variables(), 'Global variables', 'before restore_backup #' . $b['backup_id'] );
					TWDB_Divi::save_global_variables( $payload );
				} else {
					$pre = TWDB_Backups::create( 'presets', TWDB_Divi::presets_option(), TWDB_Divi::get_presets(), 'Presets', 'before restore_backup #' . $b['backup_id'] );
					TWDB_Divi::save_presets( $payload );
				}
				TWDB_Divi::clear_cache();
				return array(
					'message'            => sprintf( 'Restored %s from backup #%d. Previous state saved as #%d.', $b['kind'], $b['backup_id'], $pre ),
					'pre_restore_backup' => $pre,
				);

			case 'plugin_css':
				TWDB_Tools::need( 'edit_theme_options' );
				$pre = TWDB_Backups::create( 'plugin_css', 'twdb_custom_css', (string) get_option( 'twdb_custom_css', '' ), 'Plugin custom CSS', 'before restore_backup #' . $b['backup_id'] );
				update_option( 'twdb_custom_css', is_string( $payload ) ? $payload : '', false );
				return array(
					'message'            => sprintf( 'Restored plugin custom CSS from backup #%d. Previous state saved as #%d.', $b['backup_id'], $pre ),
					'pre_restore_backup' => $pre,
				);

			case 'wp_custom_css':
				TWDB_Tools::need( 'edit_css' );
				$stylesheet = isset( $payload['stylesheet'] ) ? $payload['stylesheet'] : get_stylesheet();
				$pre        = TWDB_Backups::create(
					'wp_custom_css',
					$stylesheet,
					array(
						'stylesheet' => $stylesheet,
						'css'        => wp_get_custom_css( $stylesheet ),
					),
					'Customizer Additional CSS',
					'before restore_backup #' . $b['backup_id']
				);
				$r          = wp_update_custom_css_post( isset( $payload['css'] ) ? $payload['css'] : '', array( 'stylesheet' => $stylesheet ) );
				if ( is_wp_error( $r ) ) {
					throw new TWDB_Tool_Error( 'save_failed', $r->get_error_message() );
				}
				return array(
					'message'            => sprintf( 'Restored Additional CSS from backup #%d. Previous state saved as #%d.', $b['backup_id'], $pre ),
					'pre_restore_backup' => $pre,
				);
		}
		throw new TWDB_Tool_Error( 'invalid_arguments', 'Unsupported backup kind.' );
	}

	/**
	 * Tool: render_page.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On failure.
	 */
	public static function render_page( $args ) {
		$post    = self::load( $args['id'] );
		$mode    = isset( $args['mode'] ) ? $args['mode'] : 'content';
		$max     = isset( $args['max_chars'] ) ? (int) $args['max_chars'] : 60000;
		$preview = TWDB_Frontend::preview_url( $post->ID );
		$notes   = array();
		$status  = null;

		if ( 'full' === $mode ) {
			$url = 'publish' === $post->post_status ? get_permalink( $post ) : $preview;
			TWDB_Security::extend_time_limit( 60 );
			$res = wp_remote_get(
				$url,
				array(
					'timeout'     => 25,
					'redirection' => 3,
					'sslverify'   => apply_filters( 'https_local_ssl_verify', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook used for loopback requests.
					'headers'     => array( 'Cache-Control' => 'no-cache' ),
				)
			);
			if ( is_wp_error( $res ) ) {
				throw new TWDB_Tool_Error( 'render_failed', 'Loopback request to the page failed: ' . $res->get_error_message() . '. Try mode "content".' );
			}
			$status = (int) wp_remote_retrieve_response_code( $res );
			$html   = (string) wp_remote_retrieve_body( $res );
			if ( $status >= 400 ) {
				$notes[] = 'The page returned HTTP ' . $status . '.';
			}
			if ( '' !== $html && ! preg_match( '/\b(page-id|postid)-' . $post->ID . '\b/', $html ) ) {
				$notes[] = sprintf( 'Warning: the HTML returned does not look like #%d (no page-id-%d / postid-%d body class). The request may have been redirected or served from a page cache.', $post->ID, $post->ID, $post->ID );
			}
			if ( empty( $args['include_head'] ) ) {
				// Divi prints large inline CSS in <head>; keep only the body so truncation cannot hide the content.
				if ( preg_match( '#<body\b[^>]*>(.*)</body>#is', $html, $bm ) ) {
					$html = $bm[1];
				}
				$html = preg_replace( '#<style\b[^>]*>.*?</style>#is', '', $html );
			}
		} else {
			$saved_post      = isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null;
			$GLOBALS['post'] = $post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Temporarily set for the_content.
			setup_postdata( $post );
			$html            = (string) apply_filters( 'the_content', $post->post_content ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
			$GLOBALS['post'] = $saved_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Restoring.
			if ( $saved_post instanceof WP_Post ) {
				setup_postdata( $saved_post );
			} else {
				wp_reset_postdata();
			}
			if ( ! TWDB_Divi::available() ) {
				$notes[] = 'Divi is not active, so Divi blocks are not rendered as Divi modules.';
			} else {
				$notes[] = 'Content mode renders module HTML without the theme or Divi stylesheets; use mode "full" to check the real page.';
			}
		}

		if ( ! isset( $args['strip_scripts'] ) || $args['strip_scripts'] ) {
			$html = preg_replace( '#<script\b[^>]*>.*?</script>#is', '', $html );
		}
		if ( ! empty( $args['strip_styles'] ) ) {
			$html = preg_replace( '#<style\b[^>]*>.*?</style>#is', '', $html );
		}
		$len = strlen( $html );
		return array(
			'id'          => (int) $args['id'],
			'mode'        => $mode,
			'url'         => get_permalink( (int) $args['id'] ),
			'preview_url' => $preview,
			'http_status' => $status,
			'html_length' => $len,
			'truncated'   => $len > $max,
			'html'        => $len > $max ? TWDB_Text::cut( $html, 0, $max ) : $html,
			'notes'       => $notes,
		);
	}
}
