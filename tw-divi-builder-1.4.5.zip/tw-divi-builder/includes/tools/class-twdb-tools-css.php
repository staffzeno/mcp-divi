<?php
/**
 * Custom CSS tools.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CSS tools.
 */
class TWDB_Tools_CSS {

	const MAX_CSS = 300000;

	/**
	 * Definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		$mode = TWDB_Tools::prop( 'string', 'replace (default) or append.', array( 'enum' => array( 'replace', 'append' ) ) );
		return array(
			array(
				'name'         => 'get_custom_css',
				'group'        => 'css',
				'title'        => 'Get custom CSS',
				'description'  => 'Returns site-wide custom CSS: this plugin\'s CSS (printed in <head> on every page), the Customizer "Additional CSS" of the active theme, Divi Theme Options custom CSS (read-only here), and optionally one page\'s Divi page CSS.',
				'capability'   => 'edit_theme_options',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'page_id' => TWDB_Tools::prop( 'integer', 'Also return this page\'s CSS.', array( 'minimum' => 1 ) ),
					),
				),
				'callback'     => array( __CLASS__, 'get_custom_css' ),
			),
			array(
				'name'         => 'set_custom_css',
				'group'        => 'css',
				'title'        => 'Set site-wide custom CSS',
				'description'  => 'Sets site-wide CSS. target "plugin" (default) stores it in this plugin and prints it in <head> after theme styles; target "theme" writes the Customizer Additional CSS. mode replace or append. Saves a restore point first. Prefer Divi design settings and presets; use CSS for what they cannot do.',
				'write'        => true,
				'capability'   => 'edit_theme_options',
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'css' ),
					'properties' => array(
						'css'    => TWDB_Tools::prop( 'string', 'CSS (no <style> tags).' ),
						'target' => TWDB_Tools::prop( 'string', 'plugin or theme.', array( 'enum' => array( 'plugin', 'theme' ) ) ),
						'mode'   => $mode,
					),
				),
				'callback'     => array( __CLASS__, 'set_custom_css' ),
			),
			array(
				'name'         => 'set_page_custom_css',
				'group'        => 'css',
				'title'        => 'Set page custom CSS',
				'description'  => 'Sets the per-page custom CSS (Divi Page Settings > Advanced > Custom CSS, meta _et_pb_custom_css). Divi prints it on that page; this plugin prints it when Divi is not active. Saves a page restore point first.',
				'write'        => true,
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'page_id', 'css' ),
					'properties' => array(
						'page_id' => TWDB_Tools::prop( 'integer', 'Page/post ID.', array( 'minimum' => 1 ) ),
						'css'     => TWDB_Tools::prop( 'string', 'CSS (empty string clears it).' ),
						'mode'    => $mode,
					),
				),
				'callback'     => array( __CLASS__, 'set_page_custom_css' ),
			),
		);
	}

	/**
	 * Clean CSS.
	 *
	 * @param string $css CSS.
	 * @return string
	 * @throws TWDB_Tool_Error When too large.
	 */
	private static function clean( $css ) {
		$css = (string) $css;
		if ( strlen( $css ) > self::MAX_CSS ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'CSS is too large (max 300 KB).' );
		}
		$css = trim( preg_replace( '#^\s*<style[^>]*>|</style>\s*$#i', '', trim( $css ) ) );
		TWDB_Code_Policy::assert_css( $css );
		$clean = trim( TWDB_Frontend::safe_css( $css ) );
		if ( $clean !== $css ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'CSS must not contain HTML tags (<script>, <style> inside the CSS, etc.). Send plain CSS only. Nothing was saved.' );
		}
		return $clean;
	}

	/**
	 * Tool: get_custom_css.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function get_custom_css( $args ) {
		$out = array(
			'plugin_css'         => (string) get_option( 'twdb_custom_css', '' ),
			'theme_additional'   => wp_get_custom_css(),
			'divi_theme_options' => function_exists( 'et_get_option' ) ? (string) et_get_option( TWDB_Divi::shortname() . '_custom_css', '' ) : '',
		);
		if ( ! empty( $args['page_id'] ) ) {
			$post            = TWDB_Tools_Pages::load( $args['page_id'] );
			$out['page_css'] = array(
				'page_id' => $post->ID,
				'css'     => (string) get_post_meta( $post->ID, '_et_pb_custom_css', true ),
			);
		}
		return $out;
	}

	/**
	 * Tool: set_custom_css.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On failure.
	 */
	public static function set_custom_css( $args ) {
		$css    = self::clean( $args['css'] );
		$target = isset( $args['target'] ) ? $args['target'] : 'plugin';
		$append = isset( $args['mode'] ) && 'append' === $args['mode'];

		if ( 'theme' === $target ) {
			TWDB_Tools::need( 'edit_css' );
			$stylesheet = get_stylesheet();
			$current    = wp_get_custom_css( $stylesheet );
			$backup     = TWDB_Backups::create(
				'wp_custom_css',
				$stylesheet,
				array(
					'stylesheet' => $stylesheet,
					'css'        => $current,
				),
				'Customizer Additional CSS',
				'before set_custom_css'
			);
			$new        = $append ? trim( $current . "\n\n" . $css ) : $css;
			$r          = wp_update_custom_css_post( $new, array( 'stylesheet' => $stylesheet ) );
			if ( is_wp_error( $r ) ) {
				throw new TWDB_Tool_Error( 'save_failed', $r->get_error_message() );
			}
		} else {
			$current = (string) get_option( 'twdb_custom_css', '' );
			$backup  = TWDB_Backups::create( 'plugin_css', 'twdb_custom_css', $current, 'Plugin custom CSS', 'before set_custom_css' );
			$new     = $append ? trim( $current . "\n\n" . $css ) : $css;
			update_option( 'twdb_custom_css', $new, true );
		}
		TWDB_Tools_Cache::purge_page_caches();
		return array(
			'message'   => sprintf( 'Saved %s CSS (%s, %d chars). Restore point #%d.', $target, $append ? 'appended' : 'replaced', strlen( $new ), $backup ),
			'target'    => $target,
			'length'    => strlen( $new ),
			'backup_id' => $backup,
		);
	}

	/**
	 * Tool: set_page_custom_css.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function set_page_custom_css( $args ) {
		$post    = TWDB_Tools_Pages::load( $args['page_id'], true );
		$css     = self::clean( $args['css'] );
		$current = (string) get_post_meta( $post->ID, '_et_pb_custom_css', true );
		$new     = ( isset( $args['mode'] ) && 'append' === $args['mode'] ) ? trim( $current . "\n\n" . $css ) : $css;
		$backup  = TWDB_Backups::backup_post( $post->ID, 'before set_page_custom_css' );
		if ( '' === $new ) {
			delete_post_meta( $post->ID, '_et_pb_custom_css' );
		} else {
			update_post_meta( $post->ID, '_et_pb_custom_css', wp_slash( $new ) );
		}
		TWDB_Divi::clear_cache( $post->ID );
		return array(
			'message'   => sprintf( 'Saved page CSS for #%d (%d chars). Restore point #%d.', $post->ID, strlen( $new ), $backup ),
			'page_id'   => $post->ID,
			'length'    => strlen( $new ),
			'backup_id' => $backup,
		);
	}
}
