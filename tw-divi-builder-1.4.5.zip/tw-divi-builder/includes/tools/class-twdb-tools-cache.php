<?php
/**
 * Cache tools.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cache tools.
 */
class TWDB_Tools_Cache {

	/**
	 * Definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return array(
			array(
				'name'         => 'clear_divi_cache',
				'group'        => 'cache',
				'title'        => 'Clear caches',
				'description'  => 'Clears Divi\'s generated CSS / dynamic-assets / Theme Builder caches (all, or one post) and purges common page caches (LiteSpeed, WP Rocket, W3 Total Cache, WP Super Cache, SiteGround, WP Fastest Cache, Autoptimize, Hostinger). Use when a change does not show on the front end.',
				'write'        => true,
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'          => TWDB_Tools::prop( 'integer', 'Only this post (default: everything).', array( 'minimum' => 1 ) ),
						'purge_page_cache' => TWDB_Tools::prop( 'boolean', 'Also purge page-cache plugins (default true).' ),
					),
				),
				'callback'     => array( __CLASS__, 'clear' ),
			),
		);
	}

	/**
	 * Purge known page caches.
	 *
	 * @param int $post_id Optional post.
	 * @return string[]
	 */
	public static function purge_page_caches( $post_id = 0 ) {
		$done = array();
		if ( has_action( 'litespeed_purge_all' ) || defined( 'LSCWP_V' ) ) {
			if ( $post_id ) {
				do_action( 'litespeed_purge_post', $post_id ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Third-party hook.
			} else {
				do_action( 'litespeed_purge_all' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Third-party hook.
			}
			$done[] = 'litespeed';
		}
		if ( function_exists( 'rocket_clean_domain' ) ) {
			if ( $post_id && function_exists( 'rocket_clean_post' ) ) {
				rocket_clean_post( $post_id );
			} else {
				rocket_clean_domain();
			}
			$done[] = 'wp_rocket';
		}
		if ( function_exists( 'w3tc_flush_all' ) ) {
			w3tc_flush_all();
			$done[] = 'w3_total_cache';
		}
		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
			$done[] = 'wp_super_cache';
		}
		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
			sg_cachepress_purge_cache();
			$done[] = 'siteground';
		}
		if ( isset( $GLOBALS['wp_fastest_cache'] ) && is_object( $GLOBALS['wp_fastest_cache'] ) && method_exists( $GLOBALS['wp_fastest_cache'], 'deleteCache' ) ) {
			$GLOBALS['wp_fastest_cache']->deleteCache( true );
			$done[] = 'wp_fastest_cache';
		}
		if ( class_exists( 'autoptimizeCache' ) && method_exists( 'autoptimizeCache', 'clearall' ) ) {
			autoptimizeCache::clearall();
			$done[] = 'autoptimize';
		}
		if ( has_action( 'hostinger_cache_purge' ) ) {
			do_action( 'hostinger_cache_purge' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Third-party hook.
			$done[] = 'hostinger';
		}
		return $done;
	}

	/**
	 * Tool: clear_divi_cache.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function clear( $args ) {
		$post_id = isset( $args['post_id'] ) ? (int) $args['post_id'] : 0;
		if ( $post_id ) {
			TWDB_Tools_Pages::load( $post_id, true );
		} else {
			TWDB_Tools::need( 'edit_theme_options' );
		}
		$divi = TWDB_Divi::clear_cache( $post_id );
		$page = ( ! isset( $args['purge_page_cache'] ) || $args['purge_page_cache'] ) ? self::purge_page_caches( $post_id ) : array();
		// wp_cache_flush_group() and wp_cache_supports() exist from WordPress 6.1; the plugin supports 6.0.
		if ( function_exists( 'wp_cache_flush_group' ) && function_exists( 'wp_cache_supports' ) && wp_cache_supports( 'flush_group' ) ) {
			wp_cache_flush_group( 'posts' );
		}
		$notes = array();
		if ( ! TWDB_Divi::available() ) {
			$notes[] = 'Divi is not active, so only WordPress / page caches were cleared.';
		}
		$cleared = implode( ', ', array_merge( $divi, $page ) );
		return array(
			'message'     => sprintf( 'Cleared caches%s: %s.', $post_id ? ' for #' . $post_id : '', '' !== $cleared ? $cleared : 'nothing to clear' ),
			'divi'        => $divi,
			'page_caches' => $page,
			'notes'       => $notes,
		);
	}
}
