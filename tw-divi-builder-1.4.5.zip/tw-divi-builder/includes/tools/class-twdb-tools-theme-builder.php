<?php
/**
 * Divi Theme Builder tools.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Theme Builder tools.
 */
class TWDB_Tools_Theme_Builder {

	const SLOTS = array(
		'header' => 'et_header_layout',
		'body'   => 'et_body_layout',
		'footer' => 'et_footer_layout',
	);

	/**
	 * Definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		$slot = array(
			'type'       => 'object',
			'properties' => array(
				'content'   => TWDB_Tools::prop( 'string', 'Divi 5 markup for this area (placeholder-wrapped). Updates the template\'s current layout (restore point saved) or creates a new one.' ),
				'layout_id' => TWDB_Tools::prop( 'integer', 'Use an existing layout post instead (0 = none / theme default).', array( 'minimum' => 0 ) ),
				'enabled'   => TWDB_Tools::prop( 'boolean', 'false hides this area on matching pages (e.g. no header).' ),
			),
		);
		return array(
			array(
				'name'         => 'list_templates',
				'group'        => 'theme_builder',
				'title'        => 'List Theme Builder templates',
				'description'  => 'Lists Divi Theme Builder templates in priority order with their conditions (use_on / exclude_from), whether each is the default website template, and their header/body/footer layout ids. include_content adds layout markup.',
				'divi'         => true,
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'include_content' => TWDB_Tools::prop( 'boolean', 'Include each layout\'s markup (default false).' ),
					),
				),
				'callback'     => array( __CLASS__, 'list_templates' ),
			),
			array(
				'name'         => 'create_or_update_template',
				'group'        => 'theme_builder',
				'title'        => 'Create or update Theme Builder template',
				'description'  => 'Creates or updates a Divi Theme Builder template and its header/body/footer layouts. default=true targets the Default Website Template (reused if it exists). Otherwise give use_on conditions such as "singular:post_type:post:all", "singular:post_type:page:id:42", "archive:taxonomy:category:all", "homepage", "404", "search". Body with enabled true and no layout uses the page\'s own content. Layout markup is validated and backed up before overwrite. Pages using template "blank" ignore Theme Builder headers/footers.',
				'divi'         => true,
				'write'        => true,
				'beta'         => true,
				'capability'   => 'edit_theme_options',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'template_id'  => TWDB_Tools::prop( 'integer', 'Existing template id to update.', array( 'minimum' => 1 ) ),
						'title'        => TWDB_Tools::prop( 'string', 'Template title.' ),
						'default'      => TWDB_Tools::prop( 'boolean', 'Target the Default Website Template (applies everywhere unless a more specific template matches).' ),
						'use_on'       => array(
							'type'        => 'array',
							'description' => 'Conditions where the template applies (replaces existing).',
							'items'       => array( 'type' => 'string' ),
						),
						'exclude_from' => array(
							'type'        => 'array',
							'description' => 'Conditions excluded (replaces existing).',
							'items'       => array( 'type' => 'string' ),
						),
						'enabled'      => TWDB_Tools::prop( 'boolean', 'Template enabled (default true).' ),
						'header'       => $slot,
						'body'         => $slot,
						'footer'       => $slot,
					),
				),
				'callback'     => array( __CLASS__, 'create_or_update_template' ),
			),
		);
	}

	/**
	 * Master Theme Builder post id (0 if none).
	 *
	 * @param bool $create Create if missing.
	 * @return int
	 */
	private static function master_id( $create = false ) {
		if ( function_exists( 'et_theme_builder_get_theme_builder_post_id' ) ) {
			$id = (int) et_theme_builder_get_theme_builder_post_id( true, $create );
			if ( $id ) {
				return $id;
			}
		}
		$found = get_posts(
			array(
				'post_type'      => 'et_theme_builder',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'fields'         => 'ids',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => '_et_library_theme_builder',
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);
		if ( $found ) {
			return (int) $found[0];
		}
		if ( ! $create ) {
			return 0;
		}
		$id = wp_insert_post(
			array(
				'post_type'   => 'et_theme_builder',
				'post_status' => 'publish',
				'post_title'  => 'Theme Builder',
			),
			true
		);
		return is_wp_error( $id ) ? 0 : (int) $id;
	}

	/**
	 * Template ids linked to the master.
	 *
	 * @param int $master Master id.
	 * @return int[]
	 */
	private static function template_ids( $master ) {
		if ( ! $master ) {
			return array();
		}
		return array_values( array_filter( array_map( 'intval', (array) get_post_meta( $master, '_et_template', false ) ) ) );
	}

	/**
	 * Describe a template.
	 *
	 * @param int  $id      Template id.
	 * @param bool $content Include markup.
	 * @return array
	 */
	private static function describe( $id, $content = false ) {
		$out = array(
			'id'           => $id,
			'title'        => html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' ),
			'default'      => '1' === (string) get_post_meta( $id, '_et_default', true ),
			'enabled'      => '1' === (string) get_post_meta( $id, '_et_enabled', true ),
			'use_on'       => array_values( (array) get_post_meta( $id, '_et_use_on', false ) ),
			'exclude_from' => array_values( (array) get_post_meta( $id, '_et_exclude_from', false ) ),
		);
		foreach ( array_keys( self::SLOTS ) as $slot ) {
			$lid = (int) get_post_meta( $id, '_et_' . $slot . '_layout_id', true );
			$row = array(
				'layout_id' => $lid,
				'enabled'   => '1' === (string) get_post_meta( $id, '_et_' . $slot . '_layout_enabled', true ),
				'title'     => $lid ? html_entity_decode( get_the_title( $lid ), ENT_QUOTES, 'UTF-8' ) : '',
			);
			if ( $content && $lid ) {
				$row['content'] = (string) get_post_field( 'post_content', $lid, 'raw' );
			}
			$out[ $slot ] = $row;
		}
		return $out;
	}

	/**
	 * Tool: list_templates.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function list_templates( $args ) {
		$master = self::master_id();
		$out    = array();
		foreach ( self::template_ids( $master ) as $tid ) {
			if ( 'et_template' === get_post_type( $tid ) ) {
				$out[] = self::describe( $tid, ! empty( $args['include_content'] ) );
			}
		}
		return array(
			'theme_builder_id' => $master,
			'templates'        => $out,
			'note'             => $out ? 'Templates are matched most-specific first; the default template applies where nothing else matches.' : 'No Theme Builder templates yet.',
		);
	}

	/**
	 * Validate a condition string.
	 *
	 * @param string $c Condition.
	 * @return string
	 * @throws TWDB_Tool_Error On invalid.
	 */
	public static function clean_condition( $c ) {
		$c = trim( (string) $c );
		if ( 'default' === $c ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Use default=true instead of the condition "default".' );
		}
		if ( ! preg_match( '/^[a-z0-9_:\-]+$/i', $c ) ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Invalid condition "' . $c . '". Examples: homepage, 404, singular:post_type:page:all, singular:post_type:page:id:42.' );
		}
		return $c;
	}

	/**
	 * Tool: create_or_update_template.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On failure.
	 */
	public static function create_or_update_template( $args ) {
		// Validate all layout markup first so nothing is half-saved.
		foreach ( array_keys( self::SLOTS ) as $slot ) {
			if ( isset( $args[ $slot ]['content'] ) && '' !== trim( $args[ $slot ]['content'] ) ) {
				$v = TWDB_Markup::validate( $args[ $slot ]['content'], true );
				if ( ! $v['valid'] ) {
					throw new TWDB_Tool_Error( 'invalid_markup', ucfirst( $slot ) . ' markup failed validation; nothing was saved.', $v );
				}
			}
			if ( isset( $args[ $slot ]['layout_id'] ) && $args[ $slot ]['layout_id'] > 0 && get_post_type( $args[ $slot ]['layout_id'] ) !== self::SLOTS[ $slot ] ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', sprintf( '%s layout_id must be an %s post.', ucfirst( $slot ), self::SLOTS[ $slot ] ) );
			}
		}
		$use_on  = isset( $args['use_on'] ) ? array_map( array( __CLASS__, 'clean_condition' ), (array) $args['use_on'] ) : null;
		$exclude = isset( $args['exclude_from'] ) ? array_map( array( __CLASS__, 'clean_condition' ), (array) $args['exclude_from'] ) : null;

		$master = self::master_id( true );
		if ( ! $master ) {
			throw new TWDB_Tool_Error( 'save_failed', 'Could not find or create the Theme Builder post.' );
		}
		$linked  = self::template_ids( $master );
		$tid     = 0;
		$created = false;
		$notes   = array();

		if ( ! empty( $args['template_id'] ) ) {
			$tid = (int) $args['template_id'];
			if ( 'et_template' !== get_post_type( $tid ) || ! in_array( $tid, $linked, true ) ) {
				throw new TWDB_Tool_Error( 'not_found', 'Template ' . $tid . ' is not part of the active Theme Builder.' );
			}
		} elseif ( ! empty( $args['default'] ) ) {
			foreach ( $linked as $l ) {
				if ( '1' === (string) get_post_meta( $l, '_et_default', true ) ) {
					$tid     = $l;
					$notes[] = 'Updated the existing Default Website Template #' . $l . '.';
					break;
				}
			}
		} elseif ( null === $use_on || ! $use_on ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'A new non-default template needs use_on conditions (or set default true).' );
		}

		if ( ! $tid ) {
			$title = ! empty( $args['title'] ) ? sanitize_text_field( $args['title'] ) : ( ! empty( $args['default'] ) ? 'Default Website Template' : 'Template' );
			$tid   = wp_insert_post(
				array(
					'post_type'   => 'et_template',
					'post_status' => 'publish',
					'post_title'  => $title,
				),
				true
			);
			if ( is_wp_error( $tid ) ) {
				throw new TWDB_Tool_Error( 'save_failed', $tid->get_error_message() );
			}
			update_post_meta( $tid, '_et_default', ! empty( $args['default'] ) ? '1' : '0' );
			update_post_meta( $tid, '_et_enabled', '1' );
			foreach ( array_keys( self::SLOTS ) as $slot ) {
				update_post_meta( $tid, '_et_' . $slot . '_layout_id', '0' );
				update_post_meta( $tid, '_et_' . $slot . '_layout_enabled', '1' );
			}
			add_post_meta( $master, '_et_template', $tid );
			$created = true;
		} elseif ( ! empty( $args['title'] ) ) {
			wp_update_post(
				array(
					'ID'         => $tid,
					'post_title' => sanitize_text_field( $args['title'] ),
				)
			);
		}

		if ( isset( $args['default'] ) && ! $created ) {
			update_post_meta( $tid, '_et_default', $args['default'] ? '1' : '0' );
		}
		if ( isset( $args['enabled'] ) ) {
			update_post_meta( $tid, '_et_enabled', $args['enabled'] ? '1' : '0' );
		}
		if ( null !== $use_on ) {
			delete_post_meta( $tid, '_et_use_on' );
			foreach ( array_unique( $use_on ) as $c ) {
				add_post_meta( $tid, '_et_use_on', $c );
			}
		}
		if ( null !== $exclude ) {
			delete_post_meta( $tid, '_et_exclude_from' );
			foreach ( array_unique( $exclude ) as $c ) {
				add_post_meta( $tid, '_et_exclude_from', $c );
			}
		}

		$backups = array();
		$title   = html_entity_decode( get_the_title( $tid ), ENT_QUOTES, 'UTF-8' );
		foreach ( self::SLOTS as $slot => $ptype ) {
			if ( ! isset( $args[ $slot ] ) || ! is_array( $args[ $slot ] ) ) {
				continue;
			}
			$in = $args[ $slot ];
			if ( isset( $in['layout_id'] ) ) {
				update_post_meta( $tid, '_et_' . $slot . '_layout_id', (string) (int) $in['layout_id'] );
			}
			if ( isset( $in['content'] ) && '' !== trim( $in['content'] ) ) {
				$current       = (int) get_post_meta( $tid, '_et_' . $slot . '_layout_id', true );
				$in['content'] = TWDB_Code_Policy::clean_markup( $in['content'], $current && get_post_type( $current ) === $ptype ? (string) get_post_field( 'post_content', $current, 'raw' ) : '' );
				if ( $current && get_post_type( $current ) === $ptype ) {
					$backups[ $slot ] = TWDB_Backups::backup_post( $current, 'before create_or_update_template (' . $slot . ')' );
					$r                = wp_update_post(
						wp_slash(
							array(
								'ID'           => $current,
								'post_content' => $in['content'],
							)
						),
						true
					);
					if ( is_wp_error( $r ) ) {
						throw new TWDB_Tool_Error( 'save_failed', $r->get_error_message() );
					}
					$lid = $current;
				} else {
					$lid = wp_insert_post(
						wp_slash(
							array(
								'post_type'    => $ptype,
								'post_status'  => 'publish',
								'post_title'   => $title . ' ' . ucfirst( $slot ) . ' Layout',
								'post_content' => $in['content'],
							)
						),
						true
					);
					if ( is_wp_error( $lid ) ) {
						throw new TWDB_Tool_Error( 'save_failed', $lid->get_error_message() );
					}
					update_post_meta( $tid, '_et_' . $slot . '_layout_id', (string) $lid );
				}
				TWDB_Tools_Pages::apply_divi_meta( $lid, $ptype );
				TWDB_Divi::clear_cache( $lid );
			}
			if ( isset( $in['enabled'] ) ) {
				update_post_meta( $tid, '_et_' . $slot . '_layout_enabled', $in['enabled'] ? '1' : '0' );
			}
		}

		TWDB_Divi::clear_cache();
		if ( class_exists( 'ET_Core_PageResource' ) && method_exists( 'ET_Core_PageResource', 'remove_static_resources' ) ) {
			ET_Core_PageResource::remove_static_resources( 'all', 'all' );
		}
		if ( ! empty( $args['default'] ) && 'page' === get_option( 'show_on_front' ) ) {
			$notes[] = 'Your homepage is a static page: if it uses the "blank" template it will not show this header/footer.';
		}
		$desc = self::describe( $tid );
		return array(
			'message'  => sprintf( '%s Theme Builder template #%d "%s".', $created ? 'Created' : 'Updated', $tid, $desc['title'] ),
			'template' => $desc,
			'backups'  => $backups,
			'notes'    => $notes,
		);
	}
}
