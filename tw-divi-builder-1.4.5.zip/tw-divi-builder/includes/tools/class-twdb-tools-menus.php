<?php
/**
 * Navigation menu tools.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Menu tools.
 */
class TWDB_Tools_Menus {

	const MAX_ITEMS = 300;

	/**
	 * Definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return array(
			array(
				'name'         => 'list_menus',
				'group'        => 'menus',
				'title'        => 'List menus',
				'description'  => 'Lists navigation menus with their items (as a tree) and theme menu locations. Divi menu modules reference a menu by id ("menuId").',
				'capability'   => 'edit_theme_options',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'include_items' => TWDB_Tools::prop( 'boolean', 'Include items (default true).' ),
					),
				),
				'callback'     => array( __CLASS__, 'list_menus' ),
			),
			array(
				'name'         => 'create_or_update_menu',
				'group'        => 'menus',
				'title'        => 'Create or update menu',
				'description'  => 'Creates a menu (or updates one by menu_id / name) and sets its items. Each item links a page_id, post_id, category_id or custom url, with optional title, target_blank, classes and nested children (max 3 levels). By default existing items are replaced (the previous items are returned so they can be recreated). locations assigns theme menu locations (e.g. primary-menu, secondary-menu, footer-menu for Divi).',
				'write'        => true,
				'capability'   => 'edit_theme_options',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'menu_id'       => TWDB_Tools::prop( 'integer', 'Existing menu id.', array( 'minimum' => 1 ) ),
						'name'          => TWDB_Tools::prop( 'string', 'Menu name (finds or creates the menu when menu_id is not given; renames when it is).' ),
						'items'         => array(
							'type'        => 'array',
							'description' => 'Items: {title?, page_id? | post_id? | category_id? | url?, target_blank?, classes?, children?: [items]}.',
							'maxItems'    => self::MAX_ITEMS,
							'items'       => array( 'type' => 'object' ),
						),
						'replace_items' => TWDB_Tools::prop( 'boolean', 'Replace existing items (default true). false appends.' ),
						'locations'     => array(
							'type'        => 'array',
							'description' => 'Theme menu locations to assign this menu to (see site_info menu_locations).',
							'items'       => array( 'type' => 'string' ),
						),
					),
				),
				'callback'     => array( __CLASS__, 'create_or_update_menu' ),
			),
		);
	}

	/**
	 * Items as a tree.
	 *
	 * @param int $menu_id Menu.
	 * @return array
	 */
	public static function items_tree( $menu_id ) {
		$items = wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'any' ) );
		if ( ! $items ) {
			return array();
		}
		$by_parent = array();
		foreach ( $items as $i ) {
			$row                                       = array(
				'item_id'      => (int) $i->ID,
				'title'        => $i->title,
				'type'         => $i->type,
				'object'       => $i->object,
				'object_id'    => (int) $i->object_id,
				'url'          => $i->url,
				'target_blank' => '_blank' === $i->target,
				'classes'      => trim( implode( ' ', array_filter( (array) $i->classes ) ) ),
			);
			$by_parent[ (int) $i->menu_item_parent ][] = $row;
		}
		$build = static function ( $parent ) use ( &$build, $by_parent ) {
			$out = array();
			foreach ( isset( $by_parent[ $parent ] ) ? $by_parent[ $parent ] : array() as $row ) {
				$kids = $build( $row['item_id'] );
				if ( $kids ) {
					$row['children'] = $kids;
				}
				$out[] = $row;
			}
			return $out;
		};
		return $build( 0 );
	}

	/**
	 * Tool: list_menus.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function list_menus( $args ) {
		$locations = get_nav_menu_locations();
		$out       = array();
		foreach ( wp_get_nav_menus() as $m ) {
			$row = array(
				'menu_id'   => (int) $m->term_id,
				'name'      => $m->name,
				'slug'      => $m->slug,
				'count'     => (int) $m->count,
				'locations' => array_keys(
					array_filter(
						$locations,
						static function ( $id ) use ( $m ) {
							return (int) $id === (int) $m->term_id;
						}
					)
				),
			);
			if ( ! isset( $args['include_items'] ) || $args['include_items'] ) {
				$row['items'] = self::items_tree( $m->term_id );
			}
			$out[] = $row;
		}
		return array(
			'menus'                => $out,
			'registered_locations' => get_registered_nav_menus(),
		);
	}

	/**
	 * Validate items recursively.
	 *
	 * @param array $items Items.
	 * @param int   $depth Depth.
	 * @param int   $count Running count.
	 * @throws TWDB_Tool_Error On bad item.
	 */
	private static function check_items( $items, $depth, &$count ) {
		if ( $depth > 3 ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Menus may nest at most 3 levels.' );
		}
		foreach ( $items as $n => $it ) {
			++$count;
			if ( $count > self::MAX_ITEMS ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', 'Too many menu items.' );
			}
			if ( ! is_array( $it ) ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', 'Each menu item must be an object.' );
			}
			$targets = array_intersect(
				array_keys(
					array_filter(
						$it,
						static function ( $v ) {
							return '' !== $v && null !== $v && 0 !== $v;
						}
					)
				),
				array( 'page_id', 'post_id', 'category_id', 'url' )
			);
			if ( 1 !== count( $targets ) ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', sprintf( 'Menu item %d needs exactly one of page_id, post_id, category_id or url.', $n + 1 ) );
			}
			$t = reset( $targets );
			if ( in_array( $t, array( 'page_id', 'post_id' ), true ) ) {
				$p = get_post( (int) $it[ $t ] );
				if ( ! $p || 'trash' === $p->post_status ) {
					throw new TWDB_Tool_Error( 'invalid_arguments', sprintf( 'Menu item %d: post %d not found.', $n + 1, (int) $it[ $t ] ) );
				}
			} elseif ( 'category_id' === $t && ! term_exists( (int) $it['category_id'], 'category' ) ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', sprintf( 'Menu item %d: category not found.', $n + 1 ) );
			} elseif ( 'url' === $t && '' === esc_url_raw( (string) $it['url'] ) && '#' !== $it['url'] ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', sprintf( 'Menu item %d: invalid url.', $n + 1 ) );
			}
			if ( ! empty( $it['children'] ) ) {
				if ( ! is_array( $it['children'] ) ) {
					throw new TWDB_Tool_Error( 'invalid_arguments', 'children must be an array.' );
				}
				self::check_items( $it['children'], $depth + 1, $count );
			}
		}
	}

	/**
	 * Add items recursively.
	 *
	 * @param int   $menu_id Menu.
	 * @param array $items   Items.
	 * @param int   $parent  Parent item id.
	 * @param int   $pos     Position counter.
	 * @return int Items added.
	 * @throws TWDB_Tool_Error On failure.
	 */
	private static function add_items( $menu_id, $items, $parent, &$pos ) {
		$added = 0;
		foreach ( $items as $it ) {
			$data = array(
				'menu-item-status'    => 'publish',
				'menu-item-parent-id' => $parent,
				'menu-item-position'  => ++$pos,
				'menu-item-title'     => isset( $it['title'] ) ? sanitize_text_field( $it['title'] ) : '',
				'menu-item-target'    => ! empty( $it['target_blank'] ) ? '_blank' : '',
				'menu-item-classes'   => isset( $it['classes'] ) ? implode( ' ', array_map( 'sanitize_html_class', preg_split( '/\s+/', (string) $it['classes'] ) ) ) : '',
			);
			if ( ! empty( $it['page_id'] ) || ! empty( $it['post_id'] ) ) {
				$pid                         = ! empty( $it['page_id'] ) ? (int) $it['page_id'] : (int) $it['post_id'];
				$data['menu-item-type']      = 'post_type';
				$data['menu-item-object']    = get_post_type( $pid );
				$data['menu-item-object-id'] = $pid;
			} elseif ( ! empty( $it['category_id'] ) ) {
				$data['menu-item-type']      = 'taxonomy';
				$data['menu-item-object']    = 'category';
				$data['menu-item-object-id'] = (int) $it['category_id'];
			} else {
				$data['menu-item-type'] = 'custom';
				$data['menu-item-url']  = '#' === $it['url'] ? '#' : esc_url_raw( $it['url'] );
				if ( '' === $data['menu-item-title'] ) {
					$data['menu-item-title'] = $data['menu-item-url'];
				}
			}
			$item_id = wp_update_nav_menu_item( $menu_id, 0, $data );
			if ( is_wp_error( $item_id ) ) {
				throw new TWDB_Tool_Error( 'save_failed', $item_id->get_error_message() );
			}
			++$added;
			if ( ! empty( $it['children'] ) ) {
				$added += self::add_items( $menu_id, $it['children'], $item_id, $pos );
			}
		}
		return $added;
	}

	/**
	 * Tool: create_or_update_menu.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On failure.
	 */
	public static function create_or_update_menu( $args ) {
		$items = isset( $args['items'] ) ? (array) $args['items'] : null;
		if ( null !== $items ) {
			$count = 0;
			self::check_items( $items, 1, $count );
		}
		if ( ! empty( $args['locations'] ) ) {
			$registered = get_registered_nav_menus();
			foreach ( $args['locations'] as $loc ) {
				if ( ! isset( $registered[ $loc ] ) ) {
					throw new TWDB_Tool_Error( 'invalid_arguments', 'Unknown menu location "' . $loc . '". Registered: ' . ( $registered ? implode( ', ', array_keys( $registered ) ) : '(none - the active theme registers no locations)' ) . '.' );
				}
			}
		}

		$created = false;
		if ( ! empty( $args['menu_id'] ) ) {
			$menu = wp_get_nav_menu_object( (int) $args['menu_id'] );
			if ( ! $menu ) {
				throw new TWDB_Tool_Error( 'not_found', 'No menu with id ' . (int) $args['menu_id'] . '.' );
			}
			if ( ! empty( $args['name'] ) && $args['name'] !== $menu->name ) {
				$r = wp_update_nav_menu_object( $menu->term_id, array( 'menu-name' => sanitize_text_field( $args['name'] ) ) );
				if ( is_wp_error( $r ) ) {
					throw new TWDB_Tool_Error( 'save_failed', $r->get_error_message() );
				}
			}
			$menu_id = (int) $menu->term_id;
		} elseif ( ! empty( $args['name'] ) ) {
			$menu = wp_get_nav_menu_object( $args['name'] );
			if ( $menu ) {
				$menu_id = (int) $menu->term_id;
			} else {
				$menu_id = wp_create_nav_menu( sanitize_text_field( $args['name'] ) );
				if ( is_wp_error( $menu_id ) ) {
					throw new TWDB_Tool_Error( 'save_failed', $menu_id->get_error_message() );
				}
				$created = true;
			}
		} else {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'Provide menu_id or name.' );
		}

		$previous = self::items_tree( $menu_id );
		$added    = 0;
		if ( null !== $items ) {
			$replace = ! isset( $args['replace_items'] ) || $args['replace_items'];
			$pos     = 0;
			if ( $replace ) {
				foreach ( (array) wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'any' ) ) as $old ) {
					wp_delete_post( $old->ID, true );
				}
			} else {
				$pos = count( (array) wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'any' ) ) );
			}
			$added = self::add_items( $menu_id, $items, 0, $pos );
		}

		if ( ! empty( $args['locations'] ) ) {
			$locs = get_nav_menu_locations();
			foreach ( $args['locations'] as $loc ) {
				$locs[ $loc ] = $menu_id;
			}
			set_theme_mod( 'nav_menu_locations', $locs );
		}
		$menu = wp_get_nav_menu_object( $menu_id );
		return array(
			'message'        => sprintf( '%s menu #%d "%s" (%d item(s) added%s).', $created ? 'Created' : 'Updated', $menu_id, $menu->name, $added, ! empty( $args['locations'] ) ? ', assigned to ' . implode( ', ', $args['locations'] ) : '' ),
			'menu_id'        => $menu_id,
			'name'           => $menu->name,
			'items'          => self::items_tree( $menu_id ),
			'previous_items' => $created ? array() : $previous,
		);
	}
}
