<?php
/**
 * Divi Library / Components tools.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Library tools.
 */
class TWDB_Tools_Library {

	/**
	 * Definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return array(
			array(
				'name'         => 'list_library_layouts',
				'group'        => 'library',
				'title'        => 'List Divi Library items',
				'description'  => 'Lists Divi Library items (layouts, sections, rows, modules) with type, scope (global = Divi 5 Component) and categories. Use a global item on a page with <!-- wp:divi/global-layout {"globalModule":"<id>","blockName":"divi/section|row|<module>","builderVersion":"..."} /-->.',
				'divi'         => true,
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'layout_type'     => TWDB_Tools::prop( 'string', 'Filter by type.', array( 'enum' => array( 'layout', 'section', 'row', 'module' ) ) ),
						'scope'           => TWDB_Tools::prop( 'string', 'global (Components) or non_global.', array( 'enum' => array( 'global', 'non_global' ) ) ),
						'search'          => TWDB_Tools::prop( 'string', 'Search title.' ),
						'include_content' => TWDB_Tools::prop( 'boolean', 'Include markup (default false).' ),
						'per_page'        => TWDB_Tools::prop(
							'integer',
							'Max results (default 50).',
							array(
								'minimum' => 1,
								'maximum' => 200,
							)
						),
					),
				),
				'callback'     => array( __CLASS__, 'list_library_layouts' ),
			),
			array(
				'name'         => 'save_library_layout',
				'group'        => 'library',
				'title'        => 'Save Divi Library item',
				'description'  => 'Creates or updates a Divi Library item from placeholder-wrapped markup. layout_type layout|section|row|module; global=true makes it a Divi 5 Component (shared everywhere it is used). For modules give module_type (e.g. divi/blurb). Updating an existing item saves a restore point first.',
				'divi'         => true,
				'write'        => true,
				'beta'         => true,
				'capability'   => 'edit_theme_options',
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'content' ),
					'properties' => array(
						'id'          => TWDB_Tools::prop( 'integer', 'Existing library item to update.', array( 'minimum' => 1 ) ),
						'title'       => TWDB_Tools::prop( 'string', 'Title (required when creating).' ),
						'content'     => TWDB_Tools::prop( 'string', 'Markup wrapped in divi/placeholder.' ),
						'layout_type' => TWDB_Tools::prop( 'string', 'Type (default section).', array( 'enum' => array( 'layout', 'section', 'row', 'module' ) ) ),
						'module_type' => TWDB_Tools::prop( 'string', 'For module items, the block name e.g. divi/blurb.' ),
						'global'      => TWDB_Tools::prop( 'boolean', 'Global item / Component (default false).' ),
						'categories'  => array(
							'type'        => 'array',
							'description' => 'Library category names (created if missing).',
							'items'       => array( 'type' => 'string' ),
						),
					),
				),
				'callback'     => array( __CLASS__, 'save_library_layout' ),
			),
		);
	}

	/**
	 * Term slug.
	 *
	 * @param int    $id  Post.
	 * @param string $tax Taxonomy.
	 * @return string
	 */
	private static function term( $id, $tax ) {
		$t = get_the_terms( $id, $tax );
		return ( $t && ! is_wp_error( $t ) ) ? $t[0]->slug : '';
	}

	/**
	 * Describe an item.
	 *
	 * @param WP_Post $p       Post.
	 * @param bool    $content Include content.
	 * @return array
	 */
	private static function describe( $p, $content ) {
		$cats = get_the_terms( $p->ID, 'layout_category' );
		$row  = array(
			'id'          => $p->ID,
			'title'       => $p->post_title,
			'status'      => $p->post_status,
			'layout_type' => self::term( $p->ID, 'layout_type' ),
			'scope'       => self::term( $p->ID, 'scope' ),
			'module_type' => (string) get_post_meta( $p->ID, '_et_pb_module_type', true ),
			'categories'  => ( $cats && ! is_wp_error( $cats ) ) ? wp_list_pluck( $cats, 'name' ) : array(),
			'modified'    => get_post_modified_time( 'c', false, $p ),
		);
		if ( $content ) {
			$row['content'] = $p->post_content;
		}
		return $row;
	}

	/**
	 * Tool: list_library_layouts.
	 *
	 * @param array $args Args.
	 * @return array
	 */
	public static function list_library_layouts( $args ) {
		$q   = array(
			'post_type'      => 'et_pb_layout',
			'post_status'    => array( 'publish', 'draft', 'private' ),
			'posts_per_page' => isset( $args['per_page'] ) ? (int) $args['per_page'] : 50,
			'orderby'        => 'modified',
			'order'          => 'DESC',
		);
		$tax = array();
		if ( ! empty( $args['layout_type'] ) ) {
			$tax[] = array(
				'taxonomy' => 'layout_type',
				'field'    => 'slug',
				'terms'    => $args['layout_type'],
			);
		}
		if ( ! empty( $args['scope'] ) ) {
			$tax[] = array(
				'taxonomy' => 'scope',
				'field'    => 'slug',
				'terms'    => $args['scope'],
			);
		}
		if ( $tax ) {
			$q['tax_query'] = $tax; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		}
		if ( ! empty( $args['search'] ) ) {
			$q['s'] = $args['search'];
		}
		$items = array();
		foreach ( get_posts( $q ) as $p ) {
			$items[] = self::describe( $p, ! empty( $args['include_content'] ) );
		}
		return array( 'items' => $items );
	}

	/**
	 * Tool: save_library_layout.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On failure.
	 */
	public static function save_library_layout( $args ) {
		$v = TWDB_Markup::validate( $args['content'], true );
		if ( ! $v['valid'] ) {
			throw new TWDB_Tool_Error( 'invalid_markup', 'Markup failed validation; nothing was saved.', $v );
		}
		$backup = 0;
		if ( ! empty( $args['id'] ) ) {
			$post = get_post( (int) $args['id'] );
			if ( ! $post || 'et_pb_layout' !== $post->post_type ) {
				throw new TWDB_Tool_Error( 'not_found', 'No Divi Library item with that id.' );
			}
			$args['content'] = TWDB_Code_Policy::clean_markup( $args['content'], (string) $post->post_content );
			TWDB_Tools::need( 'edit_post', $post->ID );
			$backup = TWDB_Backups::backup_post( $post->ID, 'before save_library_layout' );
			$arr    = array(
				'ID'           => $post->ID,
				'post_content' => $args['content'],
			);
			if ( ! empty( $args['title'] ) ) {
				$arr['post_title'] = TWDB_Code_Policy::clean_text( $args['title'], $post->post_title );
			}
			$id = wp_update_post( wp_slash( $arr ), true );
		} else {
			if ( empty( $args['title'] ) ) {
				throw new TWDB_Tool_Error( 'invalid_arguments', 'title is required when creating a library item.' );
			}
			$args['content'] = TWDB_Code_Policy::clean_markup( $args['content'] );
			$id              = wp_insert_post(
				wp_slash(
					array(
						'post_type'    => 'et_pb_layout',
						'post_status'  => 'publish',
						'post_title'   => TWDB_Code_Policy::clean_text( $args['title'] ),
						'post_content' => $args['content'],
					)
				),
				true
			);
		}
		if ( is_wp_error( $id ) ) {
			throw new TWDB_Tool_Error( 'save_failed', $id->get_error_message() );
		}
		$existing_type = self::term( $id, 'layout_type' );
		$type          = ! empty( $args['layout_type'] ) ? $args['layout_type'] : ( $existing_type ? $existing_type : 'section' );
		wp_set_object_terms( $id, $type, 'layout_type' );
		update_post_meta( $id, '_et_pb_template_type', $type );
		if ( isset( $args['global'] ) || empty( $args['id'] ) ) {
			wp_set_object_terms( $id, ! empty( $args['global'] ) ? 'global' : 'non_global', 'scope' );
		}
		if ( 'module' === $type && ! empty( $args['module_type'] ) ) {
			update_post_meta( $id, '_et_pb_module_type', sanitize_text_field( $args['module_type'] ) );
		}
		if ( ! empty( $args['categories'] ) ) {
			wp_set_object_terms( $id, array_map( 'sanitize_text_field', $args['categories'] ), 'layout_category' );
		}
		update_post_meta( $id, '_et_pb_use_builder', 'on' );
		update_post_meta( $id, '_et_pb_use_divi_5', 'on' );
		update_post_meta( $id, '_et_pb_built_for_post_type', 'page' );
		TWDB_Divi::clear_cache( $id );

		$p     = get_post( $id );
		$desc  = self::describe( $p, false );
		$block = 'layout' === $type ? '' : ( 'module' === $type ? ( ! empty( $args['module_type'] ) ? $args['module_type'] : 'divi/<module>' ) : 'divi/' . $type );
		return array(
			'message'   => sprintf( '%s library item #%d "%s" (%s, %s).%s', empty( $args['id'] ) ? 'Created' : 'Updated', $id, $p->post_title, $type, $desc['scope'], $backup ? ' Restore point #' . $backup . '.' : '' ),
			'item'      => $desc,
			'backup_id' => $backup,
			'usage'     => ( 'global' === $desc['scope'] && $block ) ? '<!-- wp:divi/global-layout {"globalModule":"' . $id . '","blockName":"' . $block . '","builderVersion":"' . TWDB_Divi::builder_version() . '"} /-->' : '',
			'warnings'  => $v['warnings'],
		);
	}
}
