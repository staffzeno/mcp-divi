<?php
/**
 * Media tools.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Media tools.
 */
class TWDB_Tools_Media {

	/**
	 * Definitions.
	 *
	 * @return array
	 */
	public static function definitions() {
		return array(
			array(
				'name'         => 'upload_media_from_url',
				'group'        => 'media',
				'title'        => 'Upload media from URL',
				'description'  => 'Downloads an image/file from a public http(s) URL into the Media Library (WordPress blocks private/internal addresses; only file types WordPress allows). Sets title and alt text, optionally attaches to a post. Re-uploading the same URL returns the existing item unless force is true. Returns the attachment id and URLs to use in image modules.',
				'write'        => true,
				'capability'   => 'upload_files',
				'input_schema' => array(
					'type'       => 'object',
					'required'   => array( 'url' ),
					'properties' => array(
						'url'       => TWDB_Tools::prop( 'string', 'Public http(s) URL.', array( 'format' => 'uri' ) ),
						'title'     => TWDB_Tools::prop( 'string', 'Attachment title.' ),
						'alt'       => TWDB_Tools::prop( 'string', 'Alt text (recommended for images).' ),
						'caption'   => TWDB_Tools::prop( 'string', 'Caption.' ),
						'filename'  => TWDB_Tools::prop( 'string', 'Filename to save as, e.g. hero.jpg (default from URL).' ),
						'attach_to' => TWDB_Tools::prop( 'integer', 'Post ID to attach to.', array( 'minimum' => 1 ) ),
						'force'     => TWDB_Tools::prop( 'boolean', 'Upload again even if this URL was imported before.' ),
					),
				),
				'callback'     => array( __CLASS__, 'upload' ),
			),
		);
	}

	/**
	 * Describe an attachment.
	 *
	 * @param int $id Attachment.
	 * @return array
	 */
	private static function describe( $id ) {
		$meta  = wp_get_attachment_metadata( $id );
		$sizes = array();
		if ( is_array( $meta ) && ! empty( $meta['sizes'] ) ) {
			foreach ( array_keys( $meta['sizes'] ) as $size ) {
				$src = wp_get_attachment_image_src( $id, $size );
				if ( $src ) {
					$sizes[ $size ] = $src[0];
				}
			}
		}
		return array(
			'id'        => $id,
			'url'       => wp_get_attachment_url( $id ),
			'title'     => html_entity_decode( (string) get_post_field( 'post_title', $id ), ENT_QUOTES, 'UTF-8' ),
			'alt'       => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'mime_type' => get_post_mime_type( $id ),
			'width'     => is_array( $meta ) && isset( $meta['width'] ) ? (int) $meta['width'] : null,
			'height'    => is_array( $meta ) && isset( $meta['height'] ) ? (int) $meta['height'] : null,
			'sizes'     => $sizes,
		);
	}

	/**
	 * upload_mimes during an import: keep only passive media and document types.
	 *
	 * @param array $mimes Allowed types (ext regex => mime).
	 * @return array
	 */
	public static function restrict_mimes( $mimes ) {
		$out = array();
		foreach ( (array) $mimes as $ext => $mime ) {
			$mime = (string) $mime;
			$ok   = 0 === strpos( $mime, 'image/' ) || 0 === strpos( $mime, 'audio/' ) || 0 === strpos( $mime, 'video/' )
				|| in_array( $mime, array( 'application/pdf', 'text/plain', 'text/csv', 'application/msword', 'application/vnd.ms-excel', 'application/vnd.ms-powerpoint' ), true )
				|| 0 === strpos( $mime, 'application/vnd.openxmlformats-officedocument.' )
				|| 0 === strpos( $mime, 'application/vnd.oasis.opendocument.' );
			// Active or script-capable formats stay out even if another plugin allowed them.
			if ( $ok && ! preg_match( '/svg|xml|html|javascript|x-shockwave|x-php/i', $mime ) ) {
				$out[ $ext ] = $mime;
			}
		}
		/**
		 * Filter the file types upload_media_from_url accepts.
		 *
		 * @param array $out   Allowed types.
		 * @param array $mimes Types the user could otherwise upload.
		 */
		return apply_filters( 'twdb_import_mimes', $out, $mimes );
	}

	/**
	 * Tool: upload_media_from_url.
	 *
	 * @param array $args Args.
	 * @return array
	 * @throws TWDB_Tool_Error On failure.
	 */
	public static function upload( $args ) {
		$url = esc_url_raw( trim( (string) $args['url'] ), array( 'http', 'https' ) );
		if ( '' === $url || strlen( $url ) > 2048 ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'URL must be a public http(s) address.' );
		}
		$chk = TWDB_Security::check_url( $url );
		if ( is_wp_error( $chk ) ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'URL refused: ' . $chk->get_error_message() );
		}
		if ( ! empty( $args['attach_to'] ) ) {
			$parent = get_post( (int) $args['attach_to'] );
			if ( ! $parent || 'attachment' === $parent->post_type ) {
				throw new TWDB_Tool_Error( 'not_found', 'attach_to must be an existing post or page.' );
			}
			TWDB_Tools::need( 'edit_post', (int) $args['attach_to'] );
		}

		if ( empty( $args['force'] ) ) {
			$existing = get_posts(
				array(
					'post_type'      => 'attachment',
					'post_status'    => 'inherit',
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'meta_key'       => '_twdb_source_url', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
					'meta_value'     => $url, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				)
			);
			if ( $existing ) {
				return array_merge(
					self::describe( (int) $existing[0] ),
					array(
						'message' => 'This URL was already imported as attachment #' . (int) $existing[0] . ' (pass force true to upload again).',
						'reused'  => true,
					)
				);
			}
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		if ( ! TWDB_Security::rate_ok( 'media_import', 100, HOUR_IN_SECONDS ) ) {
			throw new TWDB_Tool_Error( 'rate_limited', 'Too many media imports in the last hour. Try again later.' );
		}

		// Server-side fetch of a client-chosen URL: every hop is checked against private / link-local / metadata
		// addresses, redirects are re-validated, the connection is pinned to the checked address and the
		// download is capped while streaming.
		$max = (int) apply_filters( 'twdb_max_upload_bytes', 25 * MB_IN_BYTES );
		TWDB_Security::extend_time_limit( 120 );
		$tmp = TWDB_Security::download( $url, $max, 60 );
		if ( is_wp_error( $tmp ) ) {
			throw new TWDB_Tool_Error( 'download_failed', 'Could not download the file: ' . $tmp->get_error_message() );
		}

		$name = ! empty( $args['filename'] ) ? sanitize_file_name( wp_basename( (string) $args['filename'] ) ) : sanitize_file_name( wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ) );
		if ( '' === $name || false === strpos( $name, '.' ) ) {
			// Derive an extension from the real file type.
			$mime = function_exists( 'wp_get_image_mime' ) ? wp_get_image_mime( $tmp ) : false;
			$ext  = $mime ? array_search( $mime, wp_get_mime_types(), true ) : false;
			$ext  = $ext ? explode( '|', $ext )[0] : '';
			if ( '' === $ext ) {
				wp_delete_file( $tmp );
				throw new TWDB_Tool_Error( 'invalid_file', 'Could not determine the file type; pass a filename with an extension.' );
			}
			$name = ( '' !== $name ? $name : 'image' ) . '.' . $ext;
		}

		$file      = array(
			'name'     => $name,
			'tmp_name' => $tmp,
		);
		$post_data = array();
		if ( ! empty( $args['title'] ) ) {
			$post_data['post_title'] = sanitize_text_field( $args['title'] );
		}
		if ( ! empty( $args['caption'] ) ) {
			$post_data['post_excerpt'] = sanitize_text_field( $args['caption'] );
		}
		// Only media / document types, whatever the acting user could upload by hand (an administrator may
		// otherwise upload .html, .js or other active content). Contents are checked by WordPress against the
		// extension (wp_check_filetype_and_ext).
		$restrict = array( __CLASS__, 'restrict_mimes' );
		add_filter( 'upload_mimes', $restrict, 999 );
		$id = media_handle_sideload( $file, ! empty( $args['attach_to'] ) ? (int) $args['attach_to'] : 0, null, $post_data );
		remove_filter( 'upload_mimes', $restrict, 999 );
		if ( is_wp_error( $id ) ) {
			if ( file_exists( $tmp ) ) {
				wp_delete_file( $tmp );
			}
			throw new TWDB_Tool_Error( 'upload_failed', $id->get_error_message() );
		}
		if ( ! empty( $args['alt'] ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $args['alt'] ) );
		}
		update_post_meta( $id, '_twdb_source_url', $url );
		return array_merge(
			self::describe( $id ),
			array(
				'message' => sprintf( 'Uploaded attachment #%d (%s).', $id, $name ),
				'reused'  => false,
			)
		);
	}
}
