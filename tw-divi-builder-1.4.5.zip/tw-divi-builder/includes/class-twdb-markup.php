<?php
/**
 * Divi 5 block markup validation (rules from reference/DIVI5-BASE.md / SKILL.md).
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Markup validator.
 */
class TWDB_Markup {

	const PLACEHOLDER_OPEN  = '<!-- wp:divi/placeholder -->';
	const PLACEHOLDER_CLOSE = '<!-- /wp:divi/placeholder -->';

	/**
	 * Rewrite Divi block markup in WordPress's canonical serialization, in which "<", ">", "&" and quotes
	 * inside block attributes are JSON-escaped (\u003c ...), the form Divi's own builder saves.
	 *
	 * Needed before WordPress's HTML filter (kses) runs: kses understands canonical block markup and filters
	 * each attribute value, but raw HTML inside a block comment (as AI clients write it) makes kses escape the
	 * whole comment, which destroys the module.
	 *
	 * @param string $markup Markup.
	 * @return string
	 */
	public static function canonical( $markup ) {
		$markup = (string) $markup;
		if ( false === strpos( $markup, '<!-- wp:' ) || ! function_exists( 'parse_blocks' ) ) {
			return $markup;
		}
		return serialize_blocks( parse_blocks( $markup ) );
	}

	/**
	 * content_save_pre (priority 8, before kses at 10): canonicalise Divi markup when the content is going to
	 * be filtered, i.e. when the current user lacks unfiltered_html. Receives and returns slashed data.
	 *
	 * @param string $slashed Slashed post content.
	 * @return string
	 */
	public static function canonical_before_kses( $slashed ) {
		if ( current_user_can( 'unfiltered_html' ) || ! is_string( $slashed ) || false === strpos( $slashed, '<!-- wp:divi/' ) ) {
			return $slashed;
		}
		return wp_slash( self::canonical( wp_unslash( $slashed ) ) );
	}

	/**
	 * Validate markup.
	 *
	 * @param string $markup              Markup.
	 * @param bool   $require_placeholder Require the divi/placeholder wrapper.
	 * @return array { valid: bool, errors: string[], warnings: string[], stats: array }
	 */
	public static function validate( $markup, $require_placeholder = true ) {
		$errors   = array();
		$warnings = array();
		$markup   = (string) $markup;
		$trimmed  = trim( $markup );

		if ( '' === $trimmed ) {
			return array(
				'valid'    => false,
				'errors'   => array( 'Markup is empty.' ),
				'warnings' => array(),
				'stats'    => array(),
			);
		}

		if ( $require_placeholder ) {
			if ( 0 !== strpos( $trimmed, self::PLACEHOLDER_OPEN ) ) {
				$errors[] = 'Markup must start with "<!-- wp:divi/placeholder -->" (the whole page is wrapped in one divi/placeholder block).';
			}
			if ( substr( $trimmed, -strlen( self::PLACEHOLDER_CLOSE ) ) !== self::PLACEHOLDER_CLOSE ) {
				$errors[] = 'Markup must end with "<!-- /wp:divi/placeholder -->".';
			}
		}

		// 1. Every block comment's JSON must decode, and open/close tags must balance.
		$stack = array();
		$count = 0;
		$names = array();
		if ( preg_match_all( '/<!--\s+(?P<closer>\/)?wp:(?P<name>[a-z][a-z0-9_-]*(?:\/[a-z][a-z0-9_-]*)?)\s+(?P<attrs>{(?:(?:[^}]+|}+(?=})|(?!}\s+\/?-->).)*+)?}\s+)?(?P<void>\/)?-->/s', $markup, $m, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			foreach ( $m as $tok ) {
				$name   = $tok['name'][0];
				$closer = isset( $tok['closer'] ) && '' !== $tok['closer'][0] && -1 !== $tok['closer'][1];
				$void   = isset( $tok['void'] ) && '' !== $tok['void'][0] && -1 !== $tok['void'][1];
				$attrs  = ( isset( $tok['attrs'] ) && -1 !== $tok['attrs'][1] ) ? trim( $tok['attrs'][0] ) : '';
				$line   = substr_count( substr( $markup, 0, $tok[0][1] ), "\n" ) + 1;
				if ( $closer ) {
					$open = array_pop( $stack );
					if ( null === $open || $open !== $name ) {
						$errors[] = sprintf( 'Line %d: closing tag for "%s" does not match the open block "%s".', $line, $name, null === $open ? '(none)' : $open );
					}
					continue;
				}
				++$count;
				$names[ $name ] = isset( $names[ $name ] ) ? $names[ $name ] + 1 : 1;
				if ( '' !== $attrs ) {
					json_decode( $attrs, true );
					if ( JSON_ERROR_NONE !== json_last_error() ) {
						$errors[] = sprintf( 'Line %d: block "%s" has invalid JSON attributes (%s).', $line, $name, json_last_error_msg() );
					}
				}
				if ( ! $void ) {
					$stack[] = $name;
				}
			}
		}
		if ( ! empty( $stack ) ) {
			$errors[] = 'Unclosed block(s): ' . implode( ', ', array_unique( $stack ) ) . '. Container blocks need a closing "<!-- /wp:name -->"; leaf modules must self-close with " /-->".';
		}

		// 2. Parse with WordPress and walk the tree.
		$blocks = function_exists( 'parse_blocks' ) ? parse_blocks( $markup ) : array();
		$top    = array();
		foreach ( $blocks as $b ) {
			if ( empty( $b['blockName'] ) ) {
				if ( '' !== trim( (string) $b['innerHTML'] ) ) {
					$warnings[] = 'Content outside any block was found at the top level; it will not be part of the Divi layout.';
				}
				continue;
			}
			$top[] = $b['blockName'];
		}
		if ( $require_placeholder && ( 1 !== count( $top ) || 'divi/placeholder' !== $top[0] ) ) {
			$errors[] = 'There must be exactly one top-level block and it must be divi/placeholder. Found: ' . ( $top ? implode( ', ', $top ) : 'none' ) . '.';
		}

		$issues = array(
			'errors'   => array(),
			'warnings' => array(),
		);
		self::walk( $blocks, null, $issues );
		self::check_section_repetition( $blocks, $issues );
		$errors   = array_merge( $errors, array_unique( $issues['errors'] ) );
		$warnings = array_merge( $warnings, array_slice( array_unique( $issues['warnings'] ), 0, 40 ) );

		return array(
			'valid'    => empty( $errors ),
			'errors'   => array_values( $errors ),
			'warnings' => array_values( $warnings ),
			'stats'    => array(
				'blocks'      => $count,
				'block_types' => $names,
				'bytes'       => strlen( $markup ),
			),
		);
	}

	/**
	 * Recursive checks of block attributes.
	 *
	 * @param array       $blocks Blocks.
	 * @param string|null $parent Parent name.
	 * @param array       $issues Issues (by ref).
	 */
	private static function walk( $blocks, $parent, &$issues ) {
		foreach ( $blocks as $b ) {
			$name = isset( $b['blockName'] ) ? $b['blockName'] : null;
			if ( ! $name ) {
				continue;
			}
			$attrs = isset( $b['attrs'] ) && is_array( $b['attrs'] ) ? $b['attrs'] : array();

			if ( 0 !== strpos( $name, 'divi/' ) ) {
				$issues['warnings'][] = sprintf( 'Block "%s" is not a Divi block; Divi may not render it inside the layout.', $name );
			} elseif ( 'divi/placeholder' !== $name ) {
				if ( isset( $attrs['attrs'] ) && is_array( $attrs['attrs'] ) ) {
					$issues['errors'][] = sprintf( '"%s": module attributes are wrapped in "attrs". Put title/content/module/builderVersion at the top level of the JSON (wrapping renders an empty module).', $name );
				}
				if ( 'divi/text' === $name && ! isset( $attrs['content'] ) && ( isset( $attrs['body'] ) || isset( $attrs['text'] ) ) ) {
					$issues['errors'][] = '"divi/text": the content key must be "content" (not "body" or "text"), otherwise the module renders empty.';
				}
				if ( ! isset( $attrs['builderVersion'] ) ) {
					$issues['warnings'][] = sprintf( '"%s" has no "builderVersion"; add "builderVersion":"%s" to every block.', $name, TWDB_Divi::builder_version() );
				}
				if ( 'divi/section' === $name && null !== $parent && ! in_array( $parent, array( 'divi/placeholder', 'divi/global-slot' ), true ) ) {
					$issues['warnings'][] = sprintf( 'divi/section is nested inside "%s"; sections normally sit directly inside divi/placeholder.', $parent );
				}
				if ( 'divi/row' === $name && null !== $parent && ! in_array( $parent, array( 'divi/section', 'divi/column', 'divi/group', 'divi/global-slot', 'divi/placeholder' ), true ) ) {
					$issues['warnings'][] = sprintf( 'divi/row is inside "%s"; rows belong in a section (or a column for nested rows).', $parent );
				}
				if ( 'divi/column' === $name && null !== $parent && ! in_array( $parent, array( 'divi/row', 'divi/row-inner', 'divi/section' ), true ) ) {
					$issues['warnings'][] = sprintf( 'divi/column is inside "%s"; columns belong in a row.', $parent );
				}
				self::check_button_hover( $name, $attrs, $issues );
				$flat = wp_json_encode( $attrs );
				if ( is_string( $flat ) && preg_match( '/&lt;\/?(p|h[1-6]|strong|em|a|br|ul|li|span)\b/i', $flat ) ) {
					$issues['warnings'][] = sprintf( '"%s" contains pre-escaped HTML (&lt;p&gt;). HTML inside a value must be raw (<p>), not escaped.', $name );
				}
			}
			if ( ! empty( $b['innerBlocks'] ) ) {
				self::walk( $b['innerBlocks'], $name, $issues );
			}
		}
	}

	/**
	 * Collect divi/section blocks in document order.
	 *
	 * @param array $blocks Blocks.
	 * @param array $out    Sections (by ref).
	 */
	private static function collect_sections( $blocks, &$out ) {
		foreach ( $blocks as $b ) {
			if ( empty( $b['blockName'] ) ) {
				continue;
			}
			if ( 'divi/section' === $b['blockName'] ) {
				$out[] = $b;
				continue;
			}
			if ( ! empty( $b['innerBlocks'] ) ) {
				self::collect_sections( $b['innerBlocks'], $out );
			}
		}
	}

	/**
	 * Structure signature of a block: names, column widths, nesting. Content and colours are ignored.
	 *
	 * @param array $b Block.
	 * @return array [ signature string, number of columns ]
	 */
	private static function structure_signature( $b ) {
		$sig  = $b['blockName'];
		$cols = 0;
		if ( 'divi/column' === $b['blockName'] ) {
			$cols = 1;
			$w    = isset( $b['attrs']['module']['decoration']['sizing']['desktop']['value']['flexType'] ) ? $b['attrs']['module']['decoration']['sizing']['desktop']['value']['flexType'] : '';
			$sig .= '[' . $w . ']';
		}
		$kids = array();
		if ( ! empty( $b['innerBlocks'] ) ) {
			foreach ( $b['innerBlocks'] as $c ) {
				if ( empty( $c['blockName'] ) ) {
					continue;
				}
				$r      = self::structure_signature( $c );
				$kids[] = $r[0];
				$cols  += $r[1];
			}
		}
		return array( $sig . ( $kids ? '(' . implode( ',', $kids ) . ')' : '' ), $cols );
	}

	/**
	 * Warn when sections repeat the same layout (e.g. two card grids back to back).
	 *
	 * @param array $blocks Blocks.
	 * @param array $issues Issues (by ref).
	 */
	private static function check_section_repetition( $blocks, &$issues ) {
		$sections = array();
		self::collect_sections( $blocks, $sections );
		if ( count( $sections ) < 2 ) {
			return;
		}
		$sigs   = array();
		$counts = array();
		foreach ( $sections as $i => $sec ) {
			$r          = self::structure_signature( $sec );
			$sigs[ $i ] = $r;
			if ( $r[1] >= 2 ) {
				$counts[ $r[0] ] = isset( $counts[ $r[0] ] ) ? $counts[ $r[0] ] + 1 : 1;
			}
		}
		$n_sigs = count( $sigs );
		for ( $i = 1; $i < $n_sigs; $i++ ) {
			if ( $sigs[ $i ][1] >= 2 && $sigs[ $i ][0] === $sigs[ $i - 1 ][0] ) {
				$issues['warnings'][] = sprintf( 'Sections %d and %d have the identical layout (same columns and modules). Do not build symmetric look-alike sections (e.g. two card grids in a row): vary the shape of one of them. Ignore only if the supplied design repeats it.', $i, $i + 1 );
			}
		}
		foreach ( $counts as $n ) {
			if ( $n >= 3 ) {
				$issues['warnings'][] = sprintf( '%d sections share the same multi-column layout. Vary the layouts across the page unless the supplied design repeats them.', $n );
				break;
			}
		}
	}

	/**
	 * Buttons must not change letter-spacing on hover: warn when the hover state is unstated or differs.
	 *
	 * @param string $name   Block name.
	 * @param array  $attrs  Block attributes.
	 * @param array  $issues Issues (by ref).
	 */
	private static function check_button_hover( $name, $attrs, &$issues ) {
		if ( ! isset( $attrs['button'] ) || ! is_array( $attrs['button'] ) ) {
			return;
		}
		$norm  = static function ( $v ) {
			$v = strtolower( preg_replace( '/\s+/', '', (string) $v ) );
			return in_array( $v, array( '', '0', '0px', '0em', '0rem', 'normal' ), true ) ? '0' : $v;
		};
		$fonts = isset( $attrs['button']['decoration']['font']['font'] ) && is_array( $attrs['button']['decoration']['font']['font'] ) ? $attrs['button']['decoration']['font']['font'] : array();
		$desk  = isset( $fonts['desktop'] ) && is_array( $fonts['desktop'] ) ? $fonts['desktop'] : array();
		if ( ! isset( $desk['hover']['letterSpacing'] ) ) {
			$issues['warnings'][] = sprintf( '"%s": the button has no hover letterSpacing, so its text may spread out on hover (inherited from the preset or Customizer). Add "letterSpacing" to button.decoration.font.font.desktop.hover with the same value as the resting state (default "0px").', $name );
		}
		foreach ( $fonts as $bp => $state ) {
			if ( ! is_array( $state ) || ! isset( $state['hover']['letterSpacing'] ) ) {
				continue;
			}
			$rest = isset( $state['value']['letterSpacing'] ) ? $state['value']['letterSpacing'] : '';
			if ( $norm( $rest ) !== $norm( $state['hover']['letterSpacing'] ) ) {
				$issues['warnings'][] = sprintf( '"%s" (%s): hover letterSpacing "%s" differs from the resting "%s"; buttons must not change letter-spacing on hover.', $name, $bp, $state['hover']['letterSpacing'], '' === $rest ? '0px' : $rest );
			}
		}
	}

	/**
	 * Wrap markup in the placeholder if it is missing.
	 *
	 * @param string $markup Markup.
	 * @return string
	 */
	public static function ensure_wrapper( $markup ) {
		$t = trim( (string) $markup );
		if ( 0 === strpos( $t, self::PLACEHOLDER_OPEN ) ) {
			return $t;
		}
		return self::PLACEHOLDER_OPEN . "\n" . $t . "\n" . self::PLACEHOLDER_CLOSE;
	}
}
