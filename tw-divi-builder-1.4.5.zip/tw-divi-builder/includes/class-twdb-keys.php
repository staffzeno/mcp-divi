<?php
/**
 * Named connector keys.
 *
 * A key can be carried three ways: "Authorization: Bearer <key>", "X-TW-Divi-Key: <key>", or inside the
 * connector address (.../mcp/<key>) for apps such as claude.ai that have no header field. Only an HMAC of each
 * key is stored, so a key is shown once, when it is made.
 *
 * The single key of earlier versions (option twdb_api_key_hash) keeps working: see TWDB_Auth.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keys.
 */
class TWDB_Keys {

	const OPTION      = 'twdb_keys';
	const USED_OPTION = 'twdb_keys_used';
	const PREFIX      = 'twk_';
	const MAX         = 20;

	/**
	 * All keys, newest first. Hashes are included; never print them.
	 *
	 * @return array<string,array>
	 */
	public static function all() {
		$keys = get_option( self::OPTION, array() );
		if ( ! is_array( $keys ) ) {
			return array();
		}
		$used = get_option( self::USED_OPTION, array() );
		foreach ( $keys as $id => $rec ) {
			if ( is_array( $used ) && isset( $used[ $id ] ) && (int) $used[ $id ] > (int) ( isset( $rec['last_used'] ) ? $rec['last_used'] : 0 ) ) {
				$keys[ $id ]['last_used'] = (int) $used[ $id ];
			}
		}
		uasort(
			$keys,
			static function ( $a, $b ) {
				return (int) $b['created'] <=> (int) $a['created'];
			}
		);
		return $keys;
	}

	/**
	 * Create a key. Returns the plain key once.
	 *
	 * @param string $name Label shown in the list.
	 * @return array|WP_Error { id, key }
	 */
	public static function create( $name ) {
		$keys = self::all();
		if ( count( $keys ) >= self::MAX ) {
			return new WP_Error( 'twdb_too_many_keys', 'This site already has the maximum number of keys. Revoke one first.' );
		}
		$name = trim( TWDB_Text::substr( sanitize_text_field( (string) $name ), 0, 60 ) );
		if ( '' === $name ) {
			$name = 'Connector key';
		}
		$key = self::PREFIX . wp_generate_password( 40, false, false );
		$id  = strtolower( wp_generate_password( 10, false, false ) );

		$keys[ $id ] = array(
			'name'      => $name,
			'hash'      => TWDB_Settings::hash_key( $key ),
			'last4'     => substr( $key, -4 ),
			'created'   => time(),
			'by'        => get_current_user_id(),
			'last_used' => 0,
		);
		update_option( self::OPTION, $keys, false );
		return array(
			'id'  => $id,
			'key' => $key,
		);
	}

	/**
	 * Revoke one key.
	 *
	 * @param string $id Key id.
	 * @return bool
	 */
	public static function revoke( $id ) {
		$keys = TWDB_Security::fresh_option( self::OPTION, array() );
		if ( ! is_array( $keys ) || ! isset( $keys[ $id ] ) ) {
			return false;
		}
		unset( $keys[ $id ] );
		update_option( self::OPTION, $keys, false );
		$used = get_option( self::USED_OPTION, array() );
		if ( is_array( $used ) && isset( $used[ $id ] ) ) {
			unset( $used[ $id ] );
			update_option( self::USED_OPTION, $used, false );
		}
		return true;
	}

	/**
	 * Find the record for a presented key (constant-time compare). Touches last_used at most once a minute.
	 *
	 * @param string $key Presented key.
	 * @return array|null Record plus 'id'.
	 */
	public static function match( $key ) {
		if ( ! is_string( $key ) || '' === $key ) {
			return null;
		}
		$keys = self::all();
		if ( ! $keys ) {
			return null;
		}
		$hash  = TWDB_Settings::hash_key( $key );
		$found = null;
		foreach ( $keys as $id => $rec ) {
			// Compare every record (no early exit) so timing does not depend on the key's position.
			if ( isset( $rec['hash'] ) && hash_equals( (string) $rec['hash'], $hash ) && null === $found ) {
				$rec['id'] = $id;
				$found     = $rec;
			}
		}
		if ( $found ) {
			// last_used lives in its own option: writing the key list back from a request could otherwise
			// restore a key an administrator revoked a moment earlier.
			$used = get_option( self::USED_OPTION, array() );
			$used = is_array( $used ) ? $used : array();
			if ( time() - (int) ( isset( $used[ $found['id'] ] ) ? $used[ $found['id'] ] : 0 ) > 60 ) {
				$used[ $found['id'] ] = time();
				update_option( self::USED_OPTION, array_intersect_key( $used, $keys ), false );
			}
			$found['last_used'] = (int) $used[ $found['id'] ];
		}
		return $found;
	}
}
