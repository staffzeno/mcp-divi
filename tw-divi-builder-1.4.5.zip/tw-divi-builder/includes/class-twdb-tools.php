<?php
/**
 * Tool registry and dispatcher (shared by MCP and the REST mirror).
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tools registry.
 */
class TWDB_Tools {

	/**
	 * Cached definitions.
	 *
	 * @var array|null
	 */
	private static $tools = null;

	/**
	 * Tool groups (key => label).
	 *
	 * @return array
	 */
	public static function groups() {
		return array(
			'site'          => __( 'Site info & reference docs (read-only)', 'tw-divi-builder' ),
			'pages'         => __( 'Pages & posts (create, edit, trash, backups, render)', 'tw-divi-builder' ),
			'design'        => __( 'Design system (global colors, variables, presets)', 'tw-divi-builder' ),
			'theme_builder' => __( 'Theme Builder (headers, footers, body templates)', 'tw-divi-builder' ),
			'library'       => __( 'Divi Library & Components', 'tw-divi-builder' ),
			'css'           => __( 'Custom CSS (site-wide and per page)', 'tw-divi-builder' ),
			'menus'         => __( 'Navigation menus', 'tw-divi-builder' ),
			'media'         => __( 'Media uploads', 'tw-divi-builder' ),
			'settings'      => __( 'Reading settings (front page / posts page)', 'tw-divi-builder' ),
			'seo'           => __( 'SEO title & description (Yoast / Rank Math)', 'tw-divi-builder' ),
			'cache'         => __( 'Cache clearing', 'tw-divi-builder' ),
		);
	}

	/**
	 * All tool definitions keyed by name.
	 *
	 * @return array
	 */
	public static function all() {
		if ( null !== self::$tools ) {
			return self::$tools;
		}
		$defs = array_merge(
			TWDB_Tools_Site::definitions(),
			TWDB_Tools_Reference::definitions(),
			TWDB_Tools_Pages::definitions(),
			TWDB_Tools_Modules::definitions(),
			TWDB_Tools_Design::definitions(),
			TWDB_Tools_Theme_Builder::definitions(),
			TWDB_Tools_Library::definitions(),
			TWDB_Tools_CSS::definitions(),
			TWDB_Tools_Menus::definitions(),
			TWDB_Tools_Media::definitions(),
			TWDB_Tools_SEO::definitions(),
			TWDB_Tools_Cache::definitions()
		);
		/**
		 * Filter the tool definitions.
		 *
		 * @param array $defs Definitions.
		 */
		$defs  = apply_filters( 'twdb_tools', $defs );
		$tools = array();
		foreach ( $defs as $d ) {
			$d = array_merge(
				array(
					'title'       => '',
					'write'       => false,
					'divi'        => false,
					'beta'        => false,
					'destructive' => false,
					'capability'  => 'edit_pages',
				),
				$d
			);
			if ( empty( $d['input_schema'] ) ) {
				$d['input_schema'] = array(
					'type'       => 'object',
					'properties' => array(),
				);
			}
			$tools[ $d['name'] ] = $d;
		}
		self::$tools = $tools;
		return $tools;
	}

	/**
	 * Is a tool currently callable under the settings (group enabled, read-only)?
	 *
	 * @param array $tool Tool.
	 * @return true|string True or reason.
	 */
	public static function availability( $tool ) {
		$settings = TWDB_Settings::get();
		if ( ! in_array( $tool['group'], (array) $settings['groups'], true ) ) {
			return 'The "' . $tool['group'] . '" tool group is disabled in Settings > TW Divi Builder.';
		}
		if ( $tool['write'] && ! empty( $settings['read_only'] ) ) {
			return 'Read-only mode is on in Settings > TW Divi Builder, so tools that change the site are disabled.';
		}
		return true;
	}

	/**
	 * Tools for tools/list.
	 *
	 * @return array
	 */
	public static function list_for_client() {
		$out = array();
		foreach ( self::all() as $tool ) {
			if ( true !== self::availability( $tool ) ) {
				continue;
			}
			$desc = $tool['description'];
			if ( $tool['beta'] ) {
				$desc = '[BETA: storage format not yet verified on every Divi 5 version; check the result in the Visual Builder.] ' . $desc;
			}
			if ( $tool['divi'] ) {
				$desc .= ' Requires Divi 5 to be active.';
			}
			$schema = $tool['input_schema'];
			if ( empty( $schema['properties'] ) ) {
				$schema['properties'] = new stdClass();
			}
			$out[] = array(
				'name'        => $tool['name'],
				'title'       => $tool['title'],
				'description' => $desc,
				'inputSchema' => $schema,
				'annotations' => array(
					'title'           => $tool['title'],
					'readOnlyHint'    => ! $tool['write'],
					'destructiveHint' => (bool) $tool['destructive'],
					'idempotentHint'  => ! $tool['write'],
					'openWorldHint'   => false,
				),
			);
		}
		return $out;
	}

	/**
	 * Execute a tool.
	 *
	 * @param string $name Tool name.
	 * @param mixed  $args Arguments.
	 * @return array { ok: bool, data?: mixed, error?: array }
	 */
	public static function call( $name, $args ) {
		$tools = self::all();
		if ( ! isset( $tools[ $name ] ) ) {
			return self::fail( 'unknown_tool', 'Unknown tool: ' . $name );
		}
		$tool = $tools[ $name ];

		$avail = self::availability( $tool );
		if ( true !== $avail ) {
			return self::fail( 'tool_disabled', $avail );
		}

		if ( null === $args ) {
			$args = array();
		}
		if ( ! is_array( $args ) ) {
			return self::fail( 'invalid_arguments', 'Tool arguments must be a JSON object.' );
		}

		$valid = rest_validate_value_from_schema( $args, $tool['input_schema'], 'arguments' );
		if ( is_wp_error( $valid ) ) {
			return self::fail( 'invalid_arguments', $valid->get_error_message() );
		}
		$args = rest_sanitize_value_from_schema( $args, $tool['input_schema'], 'arguments' );
		if ( is_wp_error( $args ) ) {
			return self::fail( 'invalid_arguments', $args->get_error_message() );
		}

		$cap = $tool['capability'];
		if ( is_string( $cap ) && '' !== $cap && ! current_user_can( $cap ) ) {
			return self::log_result( $tool, $args, self::fail( 'forbidden', sprintf( 'The acting user lacks the "%s" capability needed for %s.', $cap, $name ) ) );
		}

		try {
			if ( $tool['divi'] ) {
				TWDB_Divi::require_divi();
			}
			TWDB_Code_Policy::reset();
			$data  = call_user_func( $tool['callback'], $args );
			$notes = TWDB_Code_Policy::notes();
			if ( $notes && is_array( $data ) ) {
				$data['warnings'] = array_merge( isset( $data['warnings'] ) ? (array) $data['warnings'] : array(), $notes );
				$data['message']  = ( isset( $data['message'] ) ? $data['message'] . ' ' : '' ) . 'Executable code was removed before saving (see warnings).';
			}
			$result = array(
				'ok'   => true,
				'data' => $data,
			);
		} catch ( TWDB_Tool_Error $e ) {
			$result = self::fail( $e->error_code, $e->getMessage(), $e->data );
		} catch ( Throwable $e ) {
			// Details (paths, SQL, stack) stay on the server; the client gets a generic message.
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
				error_log( sprintf( '[tw-divi-builder] %s failed: %s in %s:%d', $name, $e->getMessage(), $e->getFile(), $e->getLine() ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug log only, when WP_DEBUG_LOG is on.
			}
			$result = self::fail( 'internal_error', 'The tool failed with an internal error. An administrator can find details in the PHP error log when WP_DEBUG_LOG is enabled.' );
		}

		return self::log_result( $tool, $args, $result );
	}

	/**
	 * Audit-log write tools.
	 *
	 * @param array $tool   Tool.
	 * @param array $args   Args.
	 * @param array $result Result.
	 * @return array
	 */
	private static function log_result( $tool, $args, $result ) {
		if ( $tool['write'] ) {
			$summary = '';
			if ( $result['ok'] && is_array( $result['data'] ) && isset( $result['data']['message'] ) ) {
				$summary = (string) $result['data']['message'];
			} elseif ( ! $result['ok'] ) {
				$summary = $result['error']['message'];
			}
			TWDB_Audit_Log::add( $tool['name'], $args, $result['ok'], $summary );
		}
		return $result;
	}

	/**
	 * Failure envelope.
	 *
	 * @param string $code Code.
	 * @param string $msg  Message.
	 * @param array  $data Extra.
	 * @return array
	 */
	public static function fail( $code, $msg, $data = array() ) {
		$err = array(
			'code'    => $code,
			'message' => $msg,
		);
		if ( $data ) {
			$err['details'] = $data;
		}
		return array(
			'ok'    => false,
			'error' => $err,
		);
	}

	/* -------- Small helpers used by tool classes -------- */

	/**
	 * Throw unless the current user has a capability.
	 *
	 * @param string $cap  Capability.
	 * @param mixed  $arg  Optional object id.
	 * @throws TWDB_Tool_Error When missing.
	 */
	public static function need( $cap, $arg = null ) {
		$ok = null === $arg ? current_user_can( $cap ) : current_user_can( $cap, $arg );
		if ( ! $ok ) {
			throw new TWDB_Tool_Error( 'forbidden', sprintf( 'The acting user lacks the "%s" capability for this action.', $cap ) );
		}
	}

	/**
	 * Common JSON schema snippets.
	 *
	 * @param string $type Type.
	 * @param string $desc Description.
	 * @param array  $extra Extra keys.
	 * @return array
	 */
	public static function prop( $type, $desc, $extra = array() ) {
		return array_merge(
			array(
				'type'        => $type,
				'description' => $desc,
			),
			$extra
		);
	}
}
