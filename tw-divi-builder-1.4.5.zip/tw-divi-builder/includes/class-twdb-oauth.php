<?php
/**
 * "Sign in with WordPress" for the MCP endpoint: an OAuth 2.1 authorization server built on the published
 * specifications (RFC 6749, 7009, 7591, 7636, 8414, 9728 and the OAuth client ID metadata document draft).
 *
 * Developed by Deepak Juneja, Tech Webers - https://www.techwebers.com/
 *
 * The work is split into:
 *   TWDB_OAuth_Discovery   metadata documents and /.well-known/ addresses
 *   TWDB_OAuth_Clients     app registration, return-address rules, client metadata documents
 *   TWDB_OAuth_Consent     the administrator's Allow / Deny step (admin-post.php)
 *   TWDB_OAuth_Tokens      token endpoint, refresh rotation, revocation, bearer check
 *   TWDB_OAuth_Repository  locked storage
 * This class wires them up and is the interface the rest of the plugin uses.
 *
 * Who may approve: a user with manage_options. What a connection acts as: the "AI acts as user" setting.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once TWDB_DIR . 'includes/oauth/class-twdb-oauth-response.php';
require_once TWDB_DIR . 'includes/oauth/class-twdb-oauth-repository.php';
require_once TWDB_DIR . 'includes/oauth/class-twdb-oauth-discovery.php';
require_once TWDB_DIR . 'includes/oauth/class-twdb-oauth-clients.php';
require_once TWDB_DIR . 'includes/oauth/class-twdb-oauth-consent.php';
require_once TWDB_DIR . 'includes/oauth/class-twdb-oauth-tokens.php';

/**
 * OAuth facade.
 */
class TWDB_OAuth {

	const SCOPE            = 'tw-divi';
	const PREFIX_ACCESS    = 'twoa_';
	const PREFIX_REFRESH   = 'twor_';
	const ACTION_AUTHORIZE = 'twdb_oauth_authorize';
	const ACTION_REVOKE    = 'twdb_oauth_revoke';

	/**
	 * Hook everything (called once from the plugin bootstrap).
	 */
	public static function init() {
		TWDB_OAuth_Discovery::hook();
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'admin_post_nopriv_' . self::ACTION_AUTHORIZE, array( 'TWDB_OAuth_Consent', 'handle_logged_out' ) );
		add_action( 'admin_post_' . self::ACTION_AUTHORIZE, array( 'TWDB_OAuth_Consent', 'handle' ) );
		add_action( 'admin_post_' . self::ACTION_REVOKE, array( __CLASS__, 'handle_revoke' ) );
	}

	/**
	 * Is "Sign in with WordPress" turned on?
	 *
	 * @return bool
	 */
	public static function enabled() {
		return ! empty( TWDB_Settings::value( 'allow_oauth' ) );
	}

	/**
	 * REST routes. Discovery, registration, token and revocation are public by definition: the app calling
	 * them is not signed in yet. Each verifies its own credential (code + PKCE verifier, refresh token, client
	 * secret) inside.
	 */
	public static function routes() {
		if ( ! self::enabled() ) {
			return;
		}
		TWDB_OAuth_Discovery::routes();
		$post = array(
			'/oauth/register' => array( 'TWDB_OAuth_Clients', 'register' ),
			'/oauth/token'    => array( 'TWDB_OAuth_Tokens', 'exchange' ),
			'/oauth/revoke'   => array( 'TWDB_OAuth_Tokens', 'revoke' ),
		);
		foreach ( $post as $route => $callback ) {
			register_rest_route(
				TWDB_REST_NS,
				$route,
				array(
					'methods'             => 'POST',
					'callback'            => $callback,
					'permission_callback' => '__return_true', // Public endpoint; see the method comment.
				)
			);
		}
	}

	/**
	 * Body values of an OAuth request: real clients send JSON or form encoding.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function request_values( WP_REST_Request $request ) {
		foreach ( array( $request->get_json_params(), $request->get_body_params(), $request->get_query_params() ) as $values ) {
			if ( is_array( $values ) && $values ) {
				return $values;
			}
		}
		return array();
	}

	/**
	 * 503 when the store is locked by another request.
	 *
	 * @return WP_REST_Response
	 */
	public static function busy() {
		$r = TWDB_OAuth_Response::error( 'temporarily_unavailable', 'The sign-in service is busy. Please retry in a moment.', 503 );
		$r->header( 'Retry-After', '2' );
		return $r;
	}

	/* -------------------- Used by the MCP endpoint -------------------- */

	/**
	 * Does this value look like one of our access tokens?
	 *
	 * @param string $value Value.
	 * @return bool
	 */
	public static function looks_like_token( $value ) {
		return 0 === strpos( (string) $value, self::PREFIX_ACCESS );
	}

	/**
	 * The live grant behind an access token, or null.
	 *
	 * @param string $token Token.
	 * @return array|null Grant with 'client_name' and 'approver' (display name).
	 */
	public static function resolve_bearer( $token ) {
		if ( ! self::enabled() || ! self::looks_like_token( $token ) ) {
			return null;
		}
		$g = TWDB_OAuth_Tokens::check( $token );
		if ( ! $g ) {
			return null;
		}
		$g['approver'] = $g['approver_name'];
		return $g;
	}

	/**
	 * WWW-Authenticate value for a 401 from the MCP endpoint.
	 *
	 * @param string $error OAuth error code.
	 * @param string $desc  Description.
	 * @return string
	 */
	public static function www_authenticate( $error = '', $desc = '' ) {
		return TWDB_OAuth_Discovery::challenge( $error, $desc );
	}

	/* -------------------- Used by the settings screen -------------------- */

	/**
	 * Live connections.
	 *
	 * @return array[]
	 */
	public static function connections() {
		return TWDB_OAuth_Tokens::connections();
	}

	/**
	 * End a connection.
	 *
	 * @param string $id Grant id.
	 * @return string|null App name.
	 */
	public static function revoke_grant( $id ) {
		return TWDB_OAuth_Tokens::end_connection( $id );
	}

	/**
	 * Does WordPress live under a sub-path (e.g. example.com/shop/)?
	 *
	 * @return bool
	 */
	public static function in_subfolder() {
		return '' !== rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	}

	/**
	 * The /.well-known/ paths this install answers.
	 *
	 * @return array<string,string>
	 */
	public static function well_known_paths() {
		return TWDB_OAuth_Discovery::well_known_paths();
	}

	/**
	 * admin-post: the Revoke button beside a connection.
	 */
	public static function handle_revoke() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'tw-divi-builder' ), 403 );
		}
		check_admin_referer( self::ACTION_REVOKE );
		$id   = isset( $_POST['grant'] ) ? sanitize_key( wp_unslash( $_POST['grant'] ) ) : '';
		$name = self::revoke_grant( $id );
		if ( null !== $name ) {
			TWDB_Audit_Log::$via   = 'admin';
			TWDB_Audit_Log::$actor = wp_get_current_user()->display_name . ' (WP Admin)';
			TWDB_Audit_Log::add( 'oauth.revoke', array( 'client' => $name ), true, $name . ' connection ended in WP Admin' );
		}
		wp_safe_redirect( TWDB_Settings::page_url( 'people', array( 'twdb_msg' => 'conn_revoked' ) ) );
		exit;
	}
}
