<?php
/**
 * Restore points saved before every overwrite (pages, layouts, design system, CSS).
 *
 * Backups are private posts of type twdb_backup. The saved payload lives in post
 * meta so it is never filtered or rendered.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Backups.
 */
class TWDB_Backups {

	const POST_TYPE  = 'twdb_backup';
	const KEEP_EACH  = 25;
	const DIVI_METAS = array( '_et_pb_use_builder', '_et_pb_use_divi_5', '_et_pb_page_layout', '_et_pb_custom_css', '_wp_page_template', '_et_pb_built_for_post_type' );

	/**
	 * Register the private post type.
	 */
	public static function register_post_type() {
		register_post_type(
			self::POST_TYPE,
			array(
				'label'               => 'TW Divi Backups',
				'public'              => false,
				'show_ui'             => false,
				'show_in_rest'        => false,
				'exclude_from_search' => true,
				'publicly_queryable'  => false,
				'rewrite'             => false,
				'query_var'           => false,
				'can_export'          => false,
				'supports'            => array( 'title' ),
				'capability_type'     => 'page',
			)
		);
	}

	/**
	 * Create a backup record.
	 *
	 * @param string     $kind    Kind (post|global_colors|global_variables|presets|plugin_css|wp_custom_css).
	 * @param string|int $object  Object key (post id or option name).
	 * @param mixed      $payload Data to keep.
	 * @param string     $label   Human label.
	 * @param string     $reason  Why.
	 * @return int Backup ID.
	 */
	public static function create( $kind, $object, $payload, $label, $reason ) {
		$id = wp_insert_post(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'private',
				'post_title'  => sanitize_text_field( TWDB_Text::substr( $label, 0, 180 ) ),
				'post_parent' => 'post' === $kind ? (int) $object : 0,
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			return 0;
		}
		update_post_meta( $id, '_twdb_kind', $kind );
		update_post_meta( $id, '_twdb_object', (string) $object );
		update_post_meta( $id, '_twdb_reason', sanitize_text_field( $reason ) );
		update_post_meta( $id, '_twdb_user', get_current_user_id() );
		update_post_meta( $id, '_twdb_payload', wp_slash( wp_json_encode( $payload ) ) );
		self::prune( $kind, (string) $object );
		return (int) $id;
	}

	/**
	 * Snapshot a post (content + title/status/slug + Divi meta).
	 *
	 * @param int    $post_id Post.
	 * @param string $reason  Reason.
	 * @return int Backup ID.
	 */
	public static function backup_post( $post_id, $reason ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return 0;
		}
		$meta = array();
		foreach ( self::DIVI_METAS as $key ) {
			$meta[ $key ] = get_post_meta( $post_id, $key, true );
		}
		$payload = array(
			'post_type'    => $post->post_type,
			'post_title'   => $post->post_title,
			'post_status'  => $post->post_status,
			'post_name'    => $post->post_name,
			'post_parent'  => $post->post_parent,
			'post_content' => $post->post_content,
			'meta'         => $meta,
		);
		return self::create( 'post', $post_id, $payload, sprintf( '%s #%d: %s', $post->post_type, $post_id, $post->post_title ), $reason );
	}

	/**
	 * Delete old backups for one object beyond KEEP_EACH.
	 *
	 * @param string $kind   Kind.
	 * @param string $object Object.
	 */
	private static function prune( $kind, $object ) {
		$ids = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'private',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'orderby'        => 'ID',
				'order'          => 'DESC',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
			'key'   => '_twdb_kind',
			'value' => $kind,
				),
					array(
				'key'   => '_twdb_object',
				'value' => $object,
				),
				),
			)
		);
		foreach ( array_slice( $ids, self::KEEP_EACH ) as $old ) {
			wp_delete_post( $old, true );
		}
	}

	/**
	 * List backups.
	 *
	 * @param string $kind   Optional kind filter.
	 * @param string $object Optional object filter.
	 * @param int    $limit  Max.
	 * @return array
	 */
	public static function list_backups( $kind = '', $object = '', $limit = 50 ) {
		$mq = array();
		if ( $kind ) {
			$mq[] = array(
				'key'   => '_twdb_kind',
				'value' => $kind,
			);
		}
		if ( '' !== $object ) {
			$mq[] = array(
				'key'   => '_twdb_object',
				'value' => (string) $object,
			);
		}
		$q = array(
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'private',
			'posts_per_page' => max( 1, min( 200, (int) $limit ) ),
			'orderby'        => 'ID',
			'order'          => 'DESC',
		);
		if ( $mq ) {
			$q['meta_query'] = $mq; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		}
		$out = array();
		foreach ( get_posts( $q ) as $p ) {
			$out[] = array(
				'backup_id' => $p->ID,
				'kind'      => get_post_meta( $p->ID, '_twdb_kind', true ),
				'object'    => get_post_meta( $p->ID, '_twdb_object', true ),
				'label'     => $p->post_title,
				'reason'    => get_post_meta( $p->ID, '_twdb_reason', true ),
				'created'   => get_post_time( 'c', false, $p ),
				'user'      => (int) get_post_meta( $p->ID, '_twdb_user', true ),
			);
		}
		return $out;
	}

	/**
	 * Load a backup.
	 *
	 * @param int $backup_id ID.
	 * @return array|null
	 */
	public static function get( $backup_id ) {
		$p = get_post( $backup_id );
		if ( ! $p || self::POST_TYPE !== $p->post_type ) {
			return null;
		}
		$payload = json_decode( (string) get_post_meta( $p->ID, '_twdb_payload', true ), true );
		return array(
			'backup_id' => $p->ID,
			'kind'      => get_post_meta( $p->ID, '_twdb_kind', true ),
			'object'    => get_post_meta( $p->ID, '_twdb_object', true ),
			'label'     => $p->post_title,
			'payload'   => $payload,
		);
	}
}
