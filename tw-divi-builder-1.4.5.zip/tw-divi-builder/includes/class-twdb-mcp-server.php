<?php
/**
 * MCP server over Streamable HTTP (JSON-RPC 2.0, JSON responses, no SSE).
 *
 * Endpoint: POST /wp-json/tw-divi/v1/mcp (and /mcp/<connector key> for apps that cannot send a header)
 * REST mirror: GET /wp-json/tw-divi/v1/tools, POST /wp-json/tw-divi/v1/tools/{name}
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MCP server.
 */
class TWDB_MCP_Server {

	const SUPPORTED_VERSIONS = array( '2025-11-25', '2025-06-18', '2025-03-26', '2024-11-05' );
	const DEFAULT_VERSION    = '2025-06-18';
	const MAX_BATCH          = 25;

	/**
	 * Largest request body accepted, in bytes (filter twdb_max_request_bytes).
	 *
	 * @return int
	 */
	public static function max_body() {
		return (int) apply_filters( 'twdb_max_request_bytes', 8 * MB_IN_BYTES );
	}

	/**
	 * Refuse an oversized body before it is decoded.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */
	private static function too_large( WP_REST_Request $request ) {
		$len = (int) $request->get_header( 'content_length' );
		return $len > self::max_body() || strlen( (string) $request->get_body() ) > self::max_body();
	}

	/**
	 * Register routes. Authentication is enforced inside each handler so the
	 * endpoint can answer with proper JSON-RPC errors and WWW-Authenticate.
	 */
	public static function register_routes() {
		register_rest_route(
			TWDB_REST_NS,
			'/mcp',
			array(
				'methods'             => array( 'GET', 'POST', 'DELETE' ),
				'callback'            => array( __CLASS__, 'handle' ),
				'permission_callback' => '__return_true', // Auth is checked in handle() (API key / app password / cookie+nonce).
			)
		);
		// The same endpoint with a connector key inside the address, for apps that have no header field (claude.ai).
		register_rest_route(
			TWDB_REST_NS,
			'/mcp/(?P<key>(?:twk|twdb)_[A-Za-z0-9]+)',
			array(
				'methods'             => array( 'GET', 'POST', 'DELETE' ),
				'callback'            => array( __CLASS__, 'handle' ),
				'permission_callback' => '__return_true', // Auth is checked in handle().
			)
		);
		register_rest_route(
			TWDB_REST_NS,
			'/tools',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_list' ),
				'permission_callback' => '__return_true', // Auth is checked in the callback.
			)
		);
		register_rest_route(
			TWDB_REST_NS,
			'/tools/(?P<tool>[a-z0-9_]+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_call' ),
				'permission_callback' => '__return_true', // Auth is checked in the callback.
			)
		);
	}

	/**
	 * Main MCP handler.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function handle( WP_REST_Request $request ) {
		$method = $request->get_method();
		if ( 'POST' !== $method ) {
			$r = self::rpc_error_response( null, -32000, 'Method not allowed. This MCP server accepts JSON-RPC over HTTP POST only (no SSE stream).', 405 );
			$r->header( 'Allow', 'POST' );
			return $r;
		}

		$auth = TWDB_Auth::authenticate( $request );
		if ( is_wp_error( $auth ) ) {
			$data   = $auth->get_error_data();
			$status = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 401;
			$r      = self::rpc_error_response( null, -32001, $auth->get_error_message(), $status );
			if ( 401 === $status ) {
				$code = $auth->get_error_code();
				if ( TWDB_OAuth::enabled() && in_array( $code, array( 'twdb_auth_required', 'twdb_oauth_invalid' ), true ) ) {
					// Point the client at the sign-in: this 401 is what starts "Sign in with WordPress".
					$r->header( 'WWW-Authenticate', 'twdb_oauth_invalid' === $code ? TWDB_OAuth::www_authenticate( 'invalid_token', 'The access token is expired or revoked.' ) : TWDB_OAuth::www_authenticate() );
				} else {
					$r->header( 'WWW-Authenticate', 'Bearer realm="tw-divi-builder"' );
				}
			}
			return $r;
		}

		if ( self::too_large( $request ) ) {
			return self::rpc_error_response( null, -32600, 'Request too large.', 413 );
		}
		$raw = $request->get_body();
		$msg = json_decode( (string) $raw, true, 64 );
		if ( null === $msg && JSON_ERROR_NONE !== json_last_error() ) {
			return self::rpc_error_response( null, -32700, 'Parse error: ' . json_last_error_msg(), 400 );
		}
		if ( ! is_array( $msg ) || empty( $msg ) ) {
			return self::rpc_error_response( null, -32600, 'Invalid Request: expected a JSON-RPC 2.0 object or batch array.', 400 );
		}

		// MCP 2025-06-18+: after initialization a client sends the negotiated version in MCP-Protocol-Version;
		// an unsupported value must be answered with 400 Bad Request.
		$proto = trim( (string) $request->get_header( 'mcp_protocol_version' ) );
		if ( '' !== $proto && ! in_array( $proto, self::SUPPORTED_VERSIONS, true ) ) {
			return self::rpc_error_response( null, -32600, 'Unsupported MCP-Protocol-Version "' . substr( preg_replace( '/[^0-9A-Za-z._-]/', '', $proto ), 0, 20 ) . '". Supported: ' . implode( ', ', self::SUPPORTED_VERSIONS ) . '.', 400 );
		}
		$session = substr( preg_replace( '/[^\x21-\x7E]/', '', (string) $request->get_header( 'mcp_session_id' ) ), 0, 128 );

		if ( wp_is_numeric_array( $msg ) ) {
			if ( count( $msg ) > (int) apply_filters( 'twdb_max_batch', self::MAX_BATCH ) ) {
				return self::rpc_error_response( null, -32600, 'Invalid Request: too many messages in one batch.', 413 );
			}
			$responses = array();
			foreach ( $msg as $one ) {
				$res = self::process_message( $one, $session );
				if ( null !== $res ) {
					$responses[] = $res;
				}
			}
			if ( empty( $responses ) ) {
				return self::accepted();
			}
			return self::json_response( $responses, 200, $session );
		}

		$res = self::process_message( $msg, $session );
		if ( null === $res ) {
			return self::accepted();
		}
		return self::json_response( $res, 200, $session );
	}

	/**
	 * Process one JSON-RPC message. Returns null for notifications/responses.
	 *
	 * @param mixed  $msg     Message.
	 * @param string $session Session id (by ref for initialize).
	 * @return array|null
	 */
	private static function process_message( $msg, &$session ) {
		if ( ! is_array( $msg ) || ! isset( $msg['jsonrpc'] ) || '2.0' !== $msg['jsonrpc'] ) {
			$bad_id = ( is_array( $msg ) && isset( $msg['id'] ) && ( is_string( $msg['id'] ) || is_int( $msg['id'] ) ) ) ? $msg['id'] : null;
			return self::rpc_error( $bad_id, -32600, 'Invalid Request: "jsonrpc" must be "2.0".' );
		}
		$has_id = array_key_exists( 'id', $msg );
		$id     = $has_id ? $msg['id'] : null;
		if ( $has_id && ! is_string( $id ) && ! is_int( $id ) ) {
			// MCP: request ids are strings or integers and must not be null.
			return self::rpc_error( null, -32600, 'Invalid Request: "id" must be a string or an integer.' );
		}

		if ( ! isset( $msg['method'] ) ) {
			// A response from the client (we never send requests) - acknowledge.
			if ( array_key_exists( 'result', $msg ) || array_key_exists( 'error', $msg ) ) {
				return null;
			}
			return self::rpc_error( $id, -32600, 'Invalid Request: missing "method".' );
		}
		if ( ! is_string( $msg['method'] ) ) {
			return self::rpc_error( $id, -32600, 'Invalid Request: "method" must be a string.' );
		}

		$method = $msg['method'];
		$params = isset( $msg['params'] ) ? $msg['params'] : array();
		if ( ! is_array( $params ) ) {
			return $has_id ? self::rpc_error( $id, -32602, 'Invalid params: "params" must be an object.' ) : null;
		}

		// Notifications never get a response.
		if ( ! $has_id ) {
			return null;
		}

		switch ( $method ) {
			case 'initialize':
				$requested = isset( $params['protocolVersion'] ) && is_string( $params['protocolVersion'] ) ? $params['protocolVersion'] : '';
				$version   = in_array( $requested, self::SUPPORTED_VERSIONS, true ) ? $requested : self::DEFAULT_VERSION;
				if ( '' === $session ) {
					$session = wp_generate_uuid4();
				}
				return self::rpc_result(
					$id,
					array(
						'protocolVersion' => $version,
						'capabilities'    => array(
							'tools'   => array( 'listChanged' => false ),
							'logging' => new stdClass(),
						),
						'serverInfo'      => array(
							'name'    => 'tw-divi-builder',
							'title'   => 'Tech Webers MCP Builder for Divi 5',
							'version' => TWDB_VERSION,
						),
						'instructions'    => self::instructions(),
					)
				);

			case 'ping':
				return self::rpc_result( $id, new stdClass() );

			case 'logging/setLevel':
				return self::rpc_result( $id, new stdClass() );

			case 'tools/list':
				return self::rpc_result( $id, array( 'tools' => TWDB_Tools::list_for_client() ) );

			case 'tools/call':
				$name = isset( $params['name'] ) && is_string( $params['name'] ) ? $params['name'] : '';
				$all  = TWDB_Tools::all();
				if ( '' === $name || ! isset( $all[ $name ] ) ) {
					return self::rpc_error( $id, -32602, 'Unknown tool: ' . ( '' === $name ? '(missing name)' : $name ) );
				}
				$args = isset( $params['arguments'] ) ? $params['arguments'] : array();
				if ( ! is_array( $args ) || ( $args && wp_is_numeric_array( $args ) ) ) {
					return self::rpc_error( $id, -32602, 'Invalid params: "arguments" must be a JSON object.' );
				}
				$result = TWDB_Tools::call( $name, $args );
				return self::rpc_result( $id, self::tool_result( $result ) );

			case 'resources/list':
				return self::rpc_result( $id, array( 'resources' => array() ) );

			case 'resources/templates/list':
				return self::rpc_result( $id, array( 'resourceTemplates' => array() ) );

			case 'prompts/list':
				return self::rpc_result( $id, array( 'prompts' => array() ) );

			default:
				return self::rpc_error( $id, -32601, 'Method not found: ' . $method );
		}
	}

	/**
	 * Convert an internal tool result to an MCP CallToolResult.
	 *
	 * @param array $result Result.
	 * @return array
	 */
	private static function tool_result( $result ) {
		if ( $result['ok'] ) {
			$text = wp_json_encode( $result['data'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			return array(
				'content' => array(
					array(
						'type' => 'text',
						'text' => false === $text ? '{}' : $text,
					),
				),
				'isError' => false,
			);
		}
		return array(
			'content' => array(
				array(
					'type' => 'text',
					'text' => wp_json_encode( array( 'error' => $result['error'] ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
				),
			),
			'isError' => true,
		);
	}

	/**
	 * Server instructions sent on initialize.
	 *
	 * @return string
	 */
	private static function instructions() {
		return 'You are connected to a WordPress site through the Tech Webers MCP Builder for Divi 5 plugin. '
			. 'Always read get_divi_reference topic "house-rules" before writing markup (owner defaults: section side padding 50/30/20px, rows 100% wide, 16px gaps, equal-size cards, native tabs, no look-alike sections, responsive mobile menu). '
			. 'If the user supplies a mockup, Figma, PDF or HTML, call get_divi_reference topic "mockup" first and reproduce their design exactly (native Divi modules, 99% visual match, measured) instead of designing your own; an uploaded image or HTML file is the specification: copy it exactly and add nothing. '
			. 'Workflow: 1) call site_info, 2) call get_divi_reference (topic "rules" first, then the topics you need) to learn the Divi 5 block markup, '
			. '3) call get_design_system and build with its exact $variable(...)$ tokens (never invent gcid-/gvid- ids), '
			. '4) create_page / update_page with markup wrapped in <!-- wp:divi/placeholder --> ... <!-- /wp:divi/placeholder -->, every block with "builderVersion", '
			. 'module attributes at the top level of the JSON (never inside "attrs"), raw HTML in values, '
			. 'on every button write letterSpacing in BOTH the resting and the hover state with the same value (default "0px") so button text never changes spacing on hover, '
			. '5) verify with render_page. For small changes to an existing page use get_page_tree then edit_page_modules (edit/replace/add/delete/move modules by path) instead of rewriting the whole page. Every overwrite saves a restore point (list_backups / restore_backup). '
			. 'Use template "default" when the site has a Theme Builder header/footer; "blank" hides it. Ask the user before trashing content or changing site-wide settings. '
			. 'This site does not accept executable code from AI clients: scripts, iframes, objects/embeds, inline event handlers, javascript:/data: URLs and script-like CSS are removed before saving (tool results list what was removed). Build with native Divi modules instead (divi/video for videos, divi/map for maps, divi/svg for graphics); existing content you do not change is kept as it is.';
	}

	/* -------------------- REST mirror -------------------- */

	/**
	 * GET /tools.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_list( WP_REST_Request $request ) {
		$auth = TWDB_Auth::authenticate( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		return new WP_REST_Response( array( 'tools' => TWDB_Tools::list_for_client() ), 200 );
	}

	/**
	 * POST /tools/{tool} with the arguments object as JSON body.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_call( WP_REST_Request $request ) {
		$auth = TWDB_Auth::authenticate( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		if ( self::too_large( $request ) ) {
			return new WP_REST_Response( TWDB_Tools::fail( 'invalid_arguments', 'Request too large.' ), 413 );
		}
		$name = (string) $request->get_param( 'tool' );
		$raw  = trim( (string) $request->get_body() );
		$body = array();
		if ( '' !== $raw ) {
			$body = json_decode( $raw, true, 64 );
			if ( null === $body && JSON_ERROR_NONE !== json_last_error() ) {
				// Never run a tool with defaults because its arguments could not be read.
				return new WP_REST_Response( TWDB_Tools::fail( 'invalid_arguments', 'The request body is not valid JSON.' ), 400 );
			}
		}
		$result = TWDB_Tools::call( $name, $body );
		$status = 200;
		if ( ! $result['ok'] ) {
			$map    = array(
				'unknown_tool'      => 404,
				'invalid_arguments' => 400,
				'forbidden'         => 403,
				'tool_disabled'     => 403,
				'not_found'         => 404,
				'invalid_markup'    => 422,
				'divi_not_active'   => 503,
			);
			$status = isset( $map[ $result['error']['code'] ] ) ? $map[ $result['error']['code'] ] : 400;
		}
		return new WP_REST_Response( $result, $status );
	}

	/* -------------------- Helpers -------------------- */

	/**
	 * JSON-RPC result.
	 *
	 * @param mixed $id     Id.
	 * @param mixed $result Result.
	 * @return array
	 */
	private static function rpc_result( $id, $result ) {
		return array(
			'jsonrpc' => '2.0',
			'id'      => $id,
			'result'  => $result,
		);
	}

	/**
	 * JSON-RPC error.
	 *
	 * @param mixed  $id   Id.
	 * @param int    $code Code.
	 * @param string $msg  Message.
	 * @return array
	 */
	private static function rpc_error( $id, $code, $msg ) {
		return array(
			'jsonrpc' => '2.0',
			'id'      => $id,
			'error'   => array(
				'code'    => $code,
				'message' => $msg,
			),
		);
	}

	/**
	 * HTTP response wrapping a JSON-RPC error.
	 *
	 * @param mixed  $id     Id.
	 * @param int    $code   JSON-RPC code.
	 * @param string $msg    Message.
	 * @param int    $status HTTP status.
	 * @return WP_REST_Response
	 */
	private static function rpc_error_response( $id, $code, $msg, $status ) {
		return self::json_response( self::rpc_error( $id, $code, $msg ), $status, '' );
	}

	/**
	 * JSON response with MCP headers.
	 *
	 * @param mixed  $data    Data.
	 * @param int    $status  Status.
	 * @param string $session Session id.
	 * @return WP_REST_Response
	 */
	private static function json_response( $data, $status, $session ) {
		$r = new WP_REST_Response( $data, $status );
		$r->header( 'Content-Type', 'application/json; charset=utf-8' );
		$r->header( 'Cache-Control', 'no-store' );
		$r->header( 'X-Robots-Tag', 'noindex' );
		if ( '' !== $session ) {
			$r->header( 'Mcp-Session-Id', $session );
		}
		return $r;
	}

	/**
	 * 202 Accepted with no body.
	 *
	 * @return WP_REST_Response
	 */
	private static function accepted() {
		$r = new WP_REST_Response( null, 202 );
		$r->header( 'X-TWDB-Empty', '1' );
		return $r;
	}

	/**
	 * Convert WordPress-level REST errors on the MCP route (e.g. invalid JSON body,
	 * which WordPress rejects before our callback runs) into JSON-RPC errors.
	 *
	 * @param WP_HTTP_Response $result  Result.
	 * @param WP_REST_Server   $server  Server.
	 * @param WP_REST_Request  $request Request.
	 * @return WP_HTTP_Response
	 */
	public static function post_dispatch( $result, $server, $request ) {
		$route = (string) $request->get_route();
		if ( '/' . TWDB_REST_NS . '/mcp' !== $route && 0 !== strpos( $route, '/' . TWDB_REST_NS . '/mcp/' ) ) {
			return $result;
		}
		if ( ! ( $result instanceof WP_HTTP_Response ) ) {
			return $result;
		}
		$data = $result->get_data();
		if ( ! is_array( $data ) || isset( $data['jsonrpc'] ) || wp_is_numeric_array( $data ) || ! isset( $data['code'], $data['message'] ) ) {
			return $result;
		}
		$code = 'rest_invalid_json' === $data['code'] ? -32700 : -32600;
		$msg  = 'rest_invalid_json' === $data['code'] ? 'Parse error: invalid JSON body.' : (string) $data['message'];
		$new  = self::rpc_error_response( null, $code, $msg, $result->get_status() >= 400 ? $result->get_status() : 400 );
		return $new;
	}

	/**
	 * Suppress the "null" body WordPress would print for 202 responses.
	 *
	 * @param bool             $served  Served.
	 * @param WP_HTTP_Response $result  Result.
	 * @param WP_REST_Request  $request Request.
	 * @param WP_REST_Server   $server  Server.
	 * @return bool
	 */
	public static function maybe_serve_empty( $served, $result, $request, $server ) {
		if ( $served || ! ( $result instanceof WP_HTTP_Response ) ) {
			return $served;
		}
		$headers = $result->get_headers();
		if ( 202 === $result->get_status() && isset( $headers['X-TWDB-Empty'] ) && 0 === strpos( (string) $request->get_route(), '/' . TWDB_REST_NS . '/' ) ) {
			return true;
		}
		return $served;
	}
}
