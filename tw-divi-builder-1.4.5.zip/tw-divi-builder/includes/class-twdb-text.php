<?php
/**
 * UTF-8 text helpers that need neither mbstring nor intl:
 *  - substr() / length(): CHARACTER offsets and lengths (a drop-in for mb_substr( $s, $start, $length, 'UTF-8' )
 *    and mb_strlen() on valid UTF-8), for limiting names, labels and log entries;
 *  - cut() / range(): BYTE offsets and lengths, for paging large documents by byte offset.
 *
 * The byte helpers work as follows.
 * Offsets and lengths are counted in bytes of the original string (so pagination by byte offset is exact),
 * but a returned piece never starts or ends inside a character:
 *  - a start offset that falls inside a multibyte character moves FORWARD to the next character, so a chunk
 *    never contains text from before the requested offset;
 *  - the end moves back so the last character is complete and the byte budget is never exceeded.
 *
 * Invalid UTF-8 bytes (stray continuation bytes, truncated or overlong sequences, surrogates, values above
 * U+10FFFF) count as single-byte units for offsets, so consecutive chunks still tile the input exactly, but
 * they are left out of the returned text, which is therefore always valid UTF-8.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Text helpers.
 */
class TWDB_Text {

	/**
	 * Length in bytes of the valid UTF-8 character that starts at byte $i, or 0 when no valid character starts
	 * there (a continuation byte, an invalid lead byte, or a malformed / truncated sequence).
	 *
	 * @param string $text Text.
	 * @param int    $i    Byte position (0 <= $i < $len).
	 * @param int    $len  strlen( $text ).
	 * @return int 0-4
	 */
	public static function char_length( $text, $i, $len ) {
		$b = ord( $text[ $i ] );
		if ( $b < 0x80 ) {
			return 1;
		}
		if ( $b >= 0xC2 && $b <= 0xDF ) {
			$n = 2;
		} elseif ( $b >= 0xE0 && $b <= 0xEF ) {
			$n = 3;
		} elseif ( $b >= 0xF0 && $b <= 0xF4 ) {
			$n = 4;
		} else {
			return 0; // Continuation byte (0x80-0xBF), overlong lead (0xC0/0xC1) or 0xF5-0xFF.
		}
		if ( $i + $n > $len ) {
			return 0;
		}
		for ( $k = 1; $k < $n; $k++ ) {
			if ( 0x80 !== ( ord( $text[ $i + $k ] ) & 0xC0 ) ) {
				return 0;
			}
		}
		// Second-byte ranges that rule out overlong forms, UTF-16 surrogates and code points above U+10FFFF.
		$c = ord( $text[ $i + 1 ] );
		if ( ( 0xE0 === $b && $c < 0xA0 ) || ( 0xED === $b && $c > 0x9F ) || ( 0xF0 === $b && $c < 0x90 ) || ( 0xF4 === $b && $c > 0x8F ) ) {
			return 0;
		}
		return $n;
	}

	/**
	 * Is byte position $pos inside (not at the start of) a valid multibyte character? Returns the position
	 * just after that character, or -1 when $pos is a boundary.
	 *
	 * @param string $text Text.
	 * @param int    $pos  Position (0 < $pos < $len).
	 * @param int    $len  strlen( $text ).
	 * @param int    $min Do not look before this position.
	 * @return int
	 */
	private static function inside_char( $text, $pos, $len, $min = 0 ) {
		for ( $back = 1; $back <= 3 && $pos - $back >= $min; $back++ ) {
			$p = $pos - $back;
			$n = self::char_length( $text, $p, $len );
			if ( $n > $back ) {
				return $p + $n; // A valid character starts before $pos and covers it.
			}
			if ( $n > 0 ) {
				return -1; // A complete character ends at or before $pos.
			}
		}
		return -1;
	}

	/**
	 * Byte range [from, to) that cut() returns for these arguments. Use it for pagination: the next chunk
	 * starts at "to", so consecutive chunks neither overlap nor skip anything.
	 *
	 * @param string $text  Text.
	 * @param int    $start Requested byte offset.
	 * @param int    $bytes Maximum bytes.
	 * @return int[] array( from, to )
	 */
	public static function range( $text, $start, $bytes ) {
		$text  = (string) $text;
		$len   = strlen( $text );
		$start = max( 0, (int) $start );
		$bytes = max( 0, (int) $bytes );
		if ( $start >= $len ) {
			return array( $len, $len );
		}
		$from = $start;
		if ( $from > 0 ) {
			$after = self::inside_char( $text, $from, $len );
			if ( $after > $from ) {
				$from = min( $after, $len ); // Inside a character: move forward to the next one.
			}
		}
		$to = min( $len, $from + $bytes );
		if ( $to < $len && $to > $from ) {
			$after = self::inside_char( $text, $to, $len, $from );
			if ( $after > $to ) {
				// The budget ends inside a character: stop before it.
				$to -= self::char_start_offset( $text, $to, $from, $len );
			}
		}
		return array( $from, max( $from, $to ) );
	}

	/**
	 * How many bytes back from $pos the character covering $pos starts.
	 *
	 * @param string $text Text.
	 * @param int    $pos  Position inside a character.
	 * @param int    $min  Lower bound.
	 * @param int    $len  strlen( $text ).
	 * @return int
	 */
	private static function char_start_offset( $text, $pos, $min, $len ) {
		for ( $back = 1; $back <= 3 && $pos - $back >= $min; $back++ ) {
			if ( self::char_length( $text, $pos - $back, $len ) > $back ) {
				return $back;
			}
		}
		return 0;
	}

	/**
	 * Up to $bytes bytes of $text starting at byte $start, never splitting a character, and always valid
	 * UTF-8. A start offset inside a character advances to the next character.
	 *
	 * @param string $text  Text.
	 * @param int    $start Byte offset.
	 * @param int    $bytes Maximum bytes.
	 * @param bool   $no_mb Kept for backward compatibility; the result no longer depends on mbstring.
	 * @return string
	 */
	public static function cut( $text, $start, $bytes, $no_mb = false ) {
		unset( $no_mb );
		$text              = (string) $text;
		list( $from, $to ) = self::range( $text, $start, $bytes );
		if ( $to <= $from ) {
			return '';
		}
		return self::valid_only( substr( $text, $from, $to - $from ) );
	}

	/**
	 * Smallest byte budget that always makes progress on valid UTF-8: the longest UTF-8 character is 4 bytes.
	 * With a budget of at least this many bytes, range() always returns to > from while from < strlen( $text ),
	 * so a pager that continues at "to" ends after at most strlen( $text ) steps and never skips or splits a
	 * character. With a smaller budget, a character longer than the budget yields an empty range (to === from):
	 * nothing is split or skipped, but the caller must not loop on it (see next_offset()).
	 */
	const MIN_PAGE_BYTES = 4;

	/**
	 * Where the next page starts, or null when the text is finished or no progress is possible (the budget is
	 * smaller than the next character). Callers that loop on this value cannot loop forever.
	 *
	 * @param string $text  Text.
	 * @param int    $start Requested byte offset.
	 * @param int    $bytes Maximum bytes per page.
	 * @return int|null
	 */
	public static function next_offset( $text, $start, $bytes ) {
		$len          = strlen( (string) $text );
		list( , $to ) = self::range( $text, $start, $bytes );
		return ( $to < $len && $to > max( 0, (int) $start ) ) ? $to : null;
	}

	/**
	 * Number of characters (valid UTF-8 sequences; each invalid byte counts as one), like mb_strlen( $s, 'UTF-8' )
	 * on valid input.
	 *
	 * @param string $text Text.
	 * @return int
	 */
	public static function length( $text ) {
		$text = (string) $text;
		$len  = strlen( $text );
		if ( '' === $text || 1 !== preg_match( '/[\x80-\xFF]/', $text ) ) {
			return $len; // ASCII: one byte per character.
		}
		$n = 0;
		for ( $i = 0; $i < $len; ++$n ) {
			$i += max( 1, self::char_length( $text, $i, $len ) );
		}
		return $n;
	}

	/**
	 * Character-based substring, the UTF-8 equivalent of mb_substr( $text, $start, $length, 'UTF-8' ) without
	 * mbstring. Offsets and lengths count characters, never bytes, so a multibyte character is never split.
	 * Negative $start counts from the end, negative $length leaves that many characters off the end, and null
	 * $length means "to the end", as in mb_substr(). Each invalid UTF-8 byte counts as one character but is
	 * left out of the result, which is therefore always valid UTF-8.
	 *
	 * @param string   $text   Text.
	 * @param int      $start  Character offset.
	 * @param int|null $length Number of characters, or null for the rest.
	 * @return string
	 */
	public static function substr( $text, $start, $length = null ) {
		$text  = (string) $text;
		$start = (int) $start;
		$len   = strlen( $text );
		if ( '' === $text ) {
			return '';
		}
		$ascii = 1 !== preg_match( '/[\x80-\xFF]/', $text );
		if ( $ascii ) {
			$out = null === $length ? substr( $text, $start ) : substr( $text, $start, (int) $length );
			return false === $out ? '' : (string) $out; // PHP 7.4 substr() returns false when out of range.
		}
		$needs_total = $start < 0 || ( null !== $length && (int) $length < 0 );
		$total       = $needs_total ? self::length( $text ) : 0;
		if ( $start < 0 ) {
			$start = max( 0, $total + $start );
		}
		if ( null === $length ) {
			$stop = PHP_INT_MAX;
		} elseif ( (int) $length < 0 ) {
			$stop = $total + (int) $length;
		} else {
			$stop = $start + (int) $length;
		}
		if ( $stop <= $start ) {
			return '';
		}
		// Walk characters once: find the byte where character $start begins and where character $stop begins.
		$from = -1;
		$i    = 0;
		for ( $c = 0; $i < $len && $c < $stop; ++$c ) {
			if ( $c === $start ) {
				$from = $i;
			}
			$i += max( 1, self::char_length( $text, $i, $len ) );
		}
		if ( $from < 0 ) {
			return ''; // $start is at or beyond the end.
		}
		return self::valid_only( substr( $text, $from, $i - $from ) );
	}

	/**
	 * The text with invalid UTF-8 bytes removed.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	public static function valid_only( $text ) {
		$text = (string) $text;
		if ( '' === $text || 1 === preg_match( '//u', $text ) ) {
			return $text; // Already valid (PCRE is part of PHP; no mbstring needed).
		}
		$len = strlen( $text );
		$out = '';
		for ( $i = 0; $i < $len; ) {
			$n = self::char_length( $text, $i, $len );
			if ( $n > 0 ) {
				$out .= substr( $text, $i, $n );
				$i   += $n;
			} else {
				++$i; // Skip one invalid byte.
			}
		}
		return $out;
	}
}
