<?php
/**
 * Plugin bootstrap.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once TWDB_DIR . 'includes/class-twdb-text.php';
require_once TWDB_DIR . 'includes/class-twdb-security.php';
require_once TWDB_DIR . 'includes/class-twdb-settings.php';
require_once TWDB_DIR . 'includes/class-twdb-audit-log.php';
require_once TWDB_DIR . 'includes/class-twdb-diagnostics.php';
require_once TWDB_DIR . 'includes/class-twdb-divi.php';
require_once TWDB_DIR . 'includes/class-twdb-markup.php';
require_once TWDB_DIR . 'includes/class-twdb-code-policy.php';
require_once TWDB_DIR . 'includes/class-twdb-backups.php';
require_once TWDB_DIR . 'includes/class-twdb-keys.php';
require_once TWDB_DIR . 'includes/class-twdb-oauth.php';
require_once TWDB_DIR . 'includes/class-twdb-auth.php';
require_once TWDB_DIR . 'includes/class-twdb-tool-error.php';
require_once TWDB_DIR . 'includes/class-twdb-tools.php';
require_once TWDB_DIR . 'includes/class-twdb-mcp-server.php';
require_once TWDB_DIR . 'includes/class-twdb-frontend.php';
require_once TWDB_DIR . 'includes/tools/class-twdb-tools-site.php';
require_once TWDB_DIR . 'includes/tools/class-twdb-tools-pages.php';
require_once TWDB_DIR . 'includes/tools/class-twdb-tools-modules.php';
require_once TWDB_DIR . 'includes/tools/class-twdb-tools-design.php';
require_once TWDB_DIR . 'includes/tools/class-twdb-tools-theme-builder.php';
require_once TWDB_DIR . 'includes/tools/class-twdb-tools-library.php';
require_once TWDB_DIR . 'includes/tools/class-twdb-tools-css.php';
require_once TWDB_DIR . 'includes/tools/class-twdb-tools-menus.php';
require_once TWDB_DIR . 'includes/tools/class-twdb-tools-media.php';
require_once TWDB_DIR . 'includes/tools/class-twdb-tools-seo.php';
require_once TWDB_DIR . 'includes/tools/class-twdb-tools-reference.php';
require_once TWDB_DIR . 'includes/tools/class-twdb-tools-cache.php';

/**
 * Main plugin class.
 */
final class TWDB_Plugin {

	/**
	 * Singleton.
	 *
	 * @var TWDB_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get instance.
	 *
	 * @return TWDB_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'init', array( __CLASS__, 'maybe_upgrade' ), 1 );
		add_action( 'init', array( 'TWDB_Backups', 'register_post_type' ) );
		add_action( 'rest_api_init', array( 'TWDB_MCP_Server', 'register_routes' ) );
		add_filter( 'rest_pre_serve_request', array( 'TWDB_MCP_Server', 'maybe_serve_empty' ), 10, 4 );
		add_filter( 'rest_post_dispatch', array( 'TWDB_MCP_Server', 'post_dispatch' ), 10, 3 );
		TWDB_OAuth::init();
		TWDB_Frontend::init();
		if ( is_admin() ) {
			TWDB_Settings::init();
		}
	}

	/**
	 * Activation: seed defaults. The acting user defaults to the activating admin.
	 */
	public static function activate() {
		$settings = get_option( 'twdb_settings' );
		if ( ! is_array( $settings ) ) {
			$settings = TWDB_Settings::defaults();
		}
		if ( empty( $settings['acting_user'] ) ) {
			$settings['acting_user'] = get_current_user_id();
		}
		self::save_settings( $settings );
		if ( false === get_option( 'twdb_audit_log' ) ) {
			add_option( 'twdb_audit_log', array(), '', 'no' );
		}
	}

	/**
	 * Store the settings option with autoload on: it is read on every front-end request (helper assets and
	 * the /.well-known/ responder), so loading it with the other autoloaded options saves a query per page.
	 *
	 * @param array $settings Settings.
	 */
	public static function save_settings( array $settings ) {
		if ( false === get_option( 'twdb_settings' ) ) {
			add_option( 'twdb_settings', $settings, '', 'yes' );
			return;
		}
		update_option( 'twdb_settings', $settings, true );
	}

	/**
	 * Run one-time upgrade steps when the stored version differs from the code (fresh installs included).
	 */
	public static function maybe_upgrade() {
		$stored = (string) get_option( 'twdb_version', '' );
		if ( TWDB_VERSION === $stored ) {
			return;
		}
		$settings = get_option( 'twdb_settings' );
		if ( ! is_array( $settings ) && ( '' === $stored || version_compare( $stored, '1.4.3', '<' ) ) && self::has_legacy_keys() ) {
			// A site upgraded from 1.4.2 or earlier that never saved its settings (for example a network
			// sub-site) ran with keys inside the connector address allowed and has connector keys: keep that
			// behaviour. Sites without keys, and new installations, get the new default (off).
			$settings                   = TWDB_Settings::defaults();
			$settings['allow_path_key'] = true;
		}
		if ( is_array( $settings ) ) {
			// 1.4.3: AI clients can no longer add executable code on any site, so the 1.4.2 opt-in is removed.
			unset( $settings['allow_ai_code'] );
			// Existing sites keep their stored choice for keys inside the connector address (it is in the saved
			// settings); only new installations start with it off.
			if ( ! array_key_exists( 'allow_path_key', $settings ) ) {
				$settings['allow_path_key'] = true;
			}
			// Earlier versions stored the option with autoload off; re-create it autoloaded.
			delete_option( 'twdb_settings' );
			self::save_settings( $settings );
		}
		// Connections stored by 1.4.1 and earlier in a single option are converted once.
		TWDB_OAuth_Repository::upgrade();
		update_option( 'twdb_version', TWDB_VERSION, true );
	}

	/**
	 * Does this site have connector keys created before the upgrade?
	 *
	 * @return bool
	 */
	private static function has_legacy_keys() {
		$keys = get_option( 'twdb_keys', array() );
		$hash = get_option( 'twdb_api_key_hash' );
		return ( is_array( $keys ) && ! empty( $keys ) ) || ( is_string( $hash ) && '' !== $hash );
	}

	/**
	 * Deactivation: nothing destructive.
	 */
	public static function deactivate() {
	}
}
