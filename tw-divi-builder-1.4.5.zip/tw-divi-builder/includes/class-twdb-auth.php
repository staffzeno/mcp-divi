<?php
/**
 * Authentication for the MCP endpoint.
 *
 * Accepted credentials, in order:
 *  1. Connector key in the address: .../mcp/<key> (for apps with no header field, such as claude.ai). Runs as the
 *     configured acting user.
 *  2. OAuth access token ("Authorization: Bearer twoa_..."), minted after a WordPress login. Runs as the acting user;
 *     the activity log names the app and the administrator who approved it.
 *  3. Connector key as "Authorization: Bearer <key>" or "X-TW-Divi-Key: <key>" (optionally ?tw_key=<key> when
 *     enabled). The single key of earlier versions still works. Runs as the acting user.
 *  4. WordPress Application Password (Basic auth, validated by core). Runs as that user.
 *  5. Logged-in cookie session with a valid REST nonce (for admins testing in the browser).
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Auth.
 */
class TWDB_Auth {

	const MAX_FAILURES   = 30;
	const FAILURE_TTL    = 900;
	const MIN_CAPABILITY = 'edit_pages';

	/**
	 * Authenticate a request. On success the current user is switched.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return true|WP_Error
	 */
	public static function authenticate( WP_REST_Request $request ) {
		TWDB_Audit_Log::$actor = '';
		TWDB_Audit_Log::$via   = 'admin';

		if ( self::is_rate_limited() ) {
			return new WP_Error( 'twdb_rate_limited', 'Too many failed authentication attempts. Try again in 15 minutes.', array( 'status' => 429 ) );
		}

		$settings = TWDB_Settings::get();

		// 1. A key carried in the connector address. Read from the route only, never from ?key=.
		$url_params = $request->get_url_params();
		$path_key   = isset( $url_params['key'] ) ? (string) $url_params['key'] : '';
		if ( '' !== $path_key ) {
			if ( empty( $settings['allow_path_key'] ) ) {
				return new WP_Error( 'twdb_path_key_disabled', 'Keys inside the connector address are switched off in Settings > TW Divi Builder > Access settings.', array( 'status' => 403 ) );
			}
			// 403 and not 401: a wrong key is a key problem, and a 401 would send the client hunting for a sign-in.
			return self::authenticate_key( $path_key, 'url_key', 403 );
		}

		$header = trim( (string) $request->get_header( 'x_tw_divi_key' ) );
		$bearer = self::bearer( $request );

		// 2. An OAuth access token.
		if ( null !== $bearer && TWDB_OAuth::looks_like_token( $bearer ) ) {
			$grant = TWDB_OAuth::resolve_bearer( $bearer );
			if ( ! $grant ) {
				// Expired or revoked: not counted as a failed attempt; the client refreshes or signs in again.
				return new WP_Error( 'twdb_oauth_invalid', 'The access token is expired or has been revoked.', array( 'status' => 401 ) );
			}
			$user_id = TWDB_Settings::acting_user_id();
			if ( ! $user_id ) {
				return new WP_Error( 'twdb_no_user', 'No acting user is configured. Choose one in Settings > TW Divi Builder.', array( 'status' => 403 ) );
			}
			wp_set_current_user( $user_id );
			TWDB_Audit_Log::$via   = 'oauth';
			TWDB_Audit_Log::$actor = sprintf( '%1$s (approved by %2$s)', isset( $grant['client_name'] ) ? $grant['client_name'] : 'OAuth app', $grant['approver'] );
			return self::check_capability();
		}

		// 3. A key in a header (or, when allowed, ?tw_key=).
		$key = '' !== $header ? $header : $bearer;
		if ( null === $key && ! empty( $settings['allow_url_key'] ) ) {
			$q = $request->get_param( 'tw_key' );
			if ( is_string( $q ) && '' !== $q ) {
				$key = $q;
			}
		}
		if ( null !== $key && '' !== $key ) {
			return self::authenticate_key( $key, 'api_key', 401 );
		}

		// 4 and 5. Application Password or cookie session.
		$auth_header = (string) $request->get_header( 'authorization' );
		$is_basic    = 0 === stripos( $auth_header, 'basic ' ) || ! empty( $_SERVER['PHP_AUTH_USER'] );

		if ( is_user_logged_in() ) {
			$app_password = function_exists( 'rest_get_authenticated_app_password' ) ? rest_get_authenticated_app_password() : null;
			if ( $app_password || $is_basic ) {
				if ( empty( $settings['allow_app_passwords'] ) ) {
					return new WP_Error( 'twdb_app_passwords_disabled', 'Application Passwords are disabled for this endpoint. Use a connector key or sign in with WordPress.', array( 'status' => 401 ) );
				}
				TWDB_Audit_Log::$via = 'app_password';
			} else {
				TWDB_Audit_Log::$via = 'cookie';
			}
			return self::check_capability();
		}

		if ( $is_basic ) {
			self::record_failure();
			return new WP_Error( 'twdb_invalid_basic', 'Invalid username or Application Password.', array( 'status' => 401 ) );
		}

		return new WP_Error( 'twdb_auth_required', 'Authentication required. Sign in with WordPress (OAuth), or send a connector key as "Authorization: Bearer <key>", "X-TW-Divi-Key", or inside the address (.../mcp/<key>). Create keys in WP Admin > Settings > TW Divi Builder.', array( 'status' => 401 ) );
	}

	/**
	 * Check a presented connector key (named key first, then the single key of earlier versions).
	 *
	 * @param string $key         Key.
	 * @param string $via         Channel label for the log.
	 * @param int    $fail_status HTTP status for a wrong key.
	 * @return true|WP_Error
	 */
	private static function authenticate_key( $key, $via, $fail_status ) {
		$rec = TWDB_Keys::match( $key );
		if ( $rec ) {
			$label = 'Key: ' . $rec['name'];
		} elseif ( TWDB_Settings::verify_key( $key ) ) {
			$label = 'Key: legacy key';
		} else {
			self::record_failure();
			return new WP_Error( 'twdb_invalid_key', 'Invalid or revoked API key.', array( 'status' => $fail_status ) );
		}
		$user_id = TWDB_Settings::acting_user_id();
		if ( ! $user_id ) {
			return new WP_Error( 'twdb_no_user', 'No acting user is configured. Choose one in Settings > TW Divi Builder.', array( 'status' => 403 ) );
		}
		// A key is as strong as the administrator who created it: on a network, a key made by a site
		// administrator must not act as a Super Admin (same rule as OAuth approvals).
		if ( $rec && ! empty( $rec['by'] ) && ! TWDB_Settings::may_delegate( (int) $rec['by'], $user_id ) ) {
			return new WP_Error( 'twdb_forbidden', 'This key was created by an administrator who may not let the AI act as the configured user (a network Super Admin). Choose a different "AI acts as user".', array( 'status' => 403 ) );
		}
		wp_set_current_user( $user_id );
		TWDB_Audit_Log::$via   = $via;
		TWDB_Audit_Log::$actor = $label;
		return self::check_capability();
	}

	/**
	 * The authenticated user must at least be able to edit pages.
	 *
	 * @return true|WP_Error
	 */
	private static function check_capability() {
		if ( ! current_user_can( self::MIN_CAPABILITY ) ) {
			return new WP_Error( 'twdb_forbidden', 'The authenticated user cannot edit pages, so it cannot use the Divi builder tools.', array( 'status' => 403 ) );
		}
		// Whenever WordPress will filter what this request saves, give the filter canonical block markup so it
		// cleans attribute values instead of breaking Divi modules.
		add_filter( 'content_save_pre', array( 'TWDB_Markup', 'canonical_before_kses' ), 8 );
		return true;
	}

	/**
	 * The token of an "Authorization: Bearer ..." header, or null.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return string|null
	 */
	private static function bearer( WP_REST_Request $request ) {
		$auth = trim( (string) $request->get_header( 'authorization' ) );
		if ( '' === $auth && isset( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) {
			$auth = trim( sanitize_text_field( wp_unslash( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) );
		}
		if ( 0 === stripos( $auth, 'bearer ' ) ) {
			$token = trim( substr( $auth, 7 ) );
			return '' === $token ? null : $token;
		}
		return null;
	}

	/**
	 * Failure counter key for this IP.
	 *
	 * @return string
	 */
	private static function failure_key() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
		return 'twdb_fail_' . md5( $ip );
	}

	/**
	 * Is this IP locked out?
	 *
	 * @return bool
	 */
	private static function is_rate_limited() {
		return (int) get_transient( self::failure_key() ) >= self::MAX_FAILURES;
	}

	/**
	 * Count a failure.
	 */
	private static function record_failure() {
		$k = self::failure_key();
		set_transient( $k, (int) get_transient( $k ) + 1, self::FAILURE_TTL );
	}
}
