<?php
/**
 * Shared security helpers: outbound-request (SSRF) protection, light rate limiting and a small
 * cross-process lock for read-modify-write option updates.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Security helpers.
 */
class TWDB_Security {

	/**
	 * IP the current outbound request is pinned to, keyed by "host:port".
	 *
	 * @var array<string,string>
	 */
	private static $pins = array();

	/**
	 * Give a long-running tool (download, loopback render) enough time, where the host allows it.
	 *
	 * @param int $seconds Seconds.
	 */
	public static function extend_time_limit( $seconds ) {
		$disabled = array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) );
		if ( function_exists( 'set_time_limit' ) && ! in_array( 'set_time_limit', $disabled, true ) ) {
			set_time_limit( (int) $seconds ); // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- Raised only for a download / render the client asked for.
		}
	}

	/* ------------------------------------------------------------------
	 * Client IP and rate limiting
	 * ---------------------------------------------------------------- */

	/**
	 * The connecting address. REMOTE_ADDR only: forwarded headers are client-controlled.
	 *
	 * @return string
	 */
	public static function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : 'unknown';
	}

	/**
	 * Fixed-window counter per bucket and client IP. Returns false once the limit is reached.
	 *
	 * Stored as a transient (object cache when one is present), one write per counted event.
	 *
	 * @param string $bucket Bucket name.
	 * @param int    $limit  Allowed events per window.
	 * @param int    $window Window in seconds.
	 * @param bool   $count  Count this call (false only peeks).
	 * @return bool True while under the limit.
	 */
	public static function rate_ok( $bucket, $limit, $window, $count = true ) {
		/**
		 * Filter a rate limit. Return 0 to switch this limit off.
		 *
		 * @param int    $limit  Limit.
		 * @param string $bucket Bucket.
		 */
		$limit = (int) apply_filters( 'twdb_rate_limit', (int) $limit, $bucket );
		if ( $limit <= 0 ) {
			return true;
		}
		$key = 'twdb_rl_' . md5( $bucket . '|' . self::client_ip() );
		$cur = get_transient( $key );
		$cur = is_array( $cur ) ? $cur : array(
			'n' => 0,
			't' => time(),
		);
		if ( (int) $cur['t'] + $window < time() ) {
			$cur = array(
				'n' => 0,
				't' => time(),
			);
		}
		if ( (int) $cur['n'] >= $limit ) {
			return false;
		}
		if ( $count ) {
			$cur['n'] = (int) $cur['n'] + 1;
			set_transient( $key, $cur, $window );
		}
		return true;
	}

	/* ------------------------------------------------------------------
	 * Lock (atomic INSERT IGNORE on a dedicated options row)
	 * ---------------------------------------------------------------- */

	/**
	 * Acquire a named lock. Used around read-modify-write updates of a single option so that concurrent
	 * requests cannot overwrite each other (lost updates could resurrect a revoked token).
	 *
	 * @param string $name  Lock name (a-z0-9_).
	 * @param float  $wait  Seconds to wait.
	 * @param int    $stale Seconds after which a held lock is considered abandoned.
	 * @return bool
	 */
	public static function lock( $name, $wait = 5.0, $stale = 30 ) {
		global $wpdb;
		$opt      = 'twdb_lock_' . preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) $name ) );
		$deadline = microtime( true ) + (float) $wait;
		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Atomic lock row; must bypass the options cache.
			$rows = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", $opt, (string) time() ) );
			if ( 1 === (int) $rows ) {
				return true;
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Lock row; must bypass the options cache.
			$since = (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $opt ) );
			if ( $since && time() - $since > $stale ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Releasing an abandoned lock row.
				$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $opt, (string) $since ) );
				continue;
			}
			usleep( 50000 );
		} while ( microtime( true ) < $deadline );
		return false;
	}

	/**
	 * Release a named lock.
	 *
	 * @param string $name Lock name.
	 */
	public static function unlock( $name ) {
		global $wpdb;
		$opt = 'twdb_lock_' . preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) $name ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Lock row.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s", $opt ) );
	}

	/**
	 * Read an option straight from the database, skipping this request's options cache.
	 *
	 * @param string $name    Option.
	 * @param mixed  $default Default.
	 * @return mixed
	 */
	public static function fresh_option( $name, $default = false ) {
		wp_cache_delete( $name, 'options' );
		return get_option( $name, $default );
	}

	/* ------------------------------------------------------------------
	 * Outbound requests (SSRF)
	 * ---------------------------------------------------------------- */

	/**
	 * Is this a publicly routable address? Blocks loopback, private (RFC 1918 / ULA), link-local (including
	 * cloud metadata at 169.254.169.254), CGNAT, documentation, benchmark, multicast and reserved ranges, and
	 * IPv6 forms that embed an IPv4 address (mapped, NAT64, 6to4).
	 *
	 * @param string $ip IP address.
	 * @return bool
	 */
	public static function is_public_ip( $ip ) {
		$ip = trim( (string) $ip, '[] ' );
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return false;
		}
		$bin = inet_pton( $ip );
		if ( false === $bin ) {
			return false;
		}
		if ( 4 === strlen( $bin ) ) {
			$blocked = array( '0.0.0.0/8', '10.0.0.0/8', '100.64.0.0/10', '127.0.0.0/8', '169.254.0.0/16', '172.16.0.0/12', '192.0.0.0/24', '192.0.2.0/24', '192.88.99.0/24', '192.168.0.0/16', '198.18.0.0/15', '198.51.100.0/24', '203.0.113.0/24', '224.0.0.0/4', '240.0.0.0/4' );
		} else {
			// IPv4 embedded in IPv6: judge the embedded address.
			$prefix12 = substr( $bin, 0, 12 );
			if ( str_repeat( "\0", 10 ) . "\xff\xff" === $prefix12 || "\x00\x64\xff\x9b" . str_repeat( "\0", 8 ) === $prefix12 ) {
				return self::is_public_ip( inet_ntop( substr( $bin, 12 ) ) );
			}
			if ( "\x20\x02" === substr( $bin, 0, 2 ) ) {
				return self::is_public_ip( inet_ntop( substr( $bin, 2, 4 ) ) );
			}
			$blocked = array( '::/128', '::1/128', '::/96', '100::/64', '2001::/32', '2001:db8::/32', 'fc00::/7', 'fe80::/10', 'fec0::/10', 'ff00::/8' );
		}
		foreach ( $blocked as $cidr ) {
			if ( self::in_cidr( $bin, $cidr ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Is a packed address inside a CIDR range of the same family?
	 *
	 * @param string $bin  Packed address.
	 * @param string $cidr Range.
	 * @return bool
	 */
	private static function in_cidr( $bin, $cidr ) {
		list( $net, $bits ) = explode( '/', $cidr );
		$net                = inet_pton( $net );
		if ( false === $net || strlen( $net ) !== strlen( $bin ) ) {
			return false;
		}
		$bits  = (int) $bits;
		$bytes = intdiv( $bits, 8 );
		if ( substr( $bin, 0, $bytes ) !== substr( $net, 0, $bytes ) ) {
			return false;
		}
		$rem = $bits % 8;
		if ( 0 === $rem ) {
			return true;
		}
		$mask = ( 0xFF << ( 8 - $rem ) ) & 0xFF;
		return ( ord( $bin[ $bytes ] ) & $mask ) === ( ord( $net[ $bytes ] ) & $mask );
	}

	/**
	 * Resolve a host to all its addresses (A and AAAA).
	 *
	 * @param string $host Host.
	 * @return string[]
	 */
	private static function resolve( $host ) {
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return array( $host );
		}
		$ips = array();
		if ( strlen( $host ) > 253 ) {
			return $ips; // Not a valid DNS name; the lookup functions would only warn.
		}
		if ( function_exists( 'dns_get_record' ) ) {
			$recs = @dns_get_record( $host, DNS_A | DNS_AAAA ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- A failed lookup is handled below.
			foreach ( (array) $recs as $r ) {
				if ( ! empty( $r['ip'] ) ) {
					$ips[] = $r['ip'];
				} elseif ( ! empty( $r['ipv6'] ) ) {
					$ips[] = $r['ipv6'];
				}
			}
		}
		if ( ! $ips ) {
			$v4 = gethostbynamel( $host );
			if ( is_array( $v4 ) ) {
				$ips = $v4;
			}
		}
		return array_values( array_unique( $ips ) );
	}

	/**
	 * Check that a URL is safe to fetch from the server: http(s), standard port, no credentials, and every
	 * address its host resolves to is public. Returns the address to pin the connection to.
	 *
	 * @param string $url     URL.
	 * @param bool   $https   Require https.
	 * @return array|WP_Error { host, port, ip }
	 */
	public static function check_url( $url, $https = false ) {
		$p = wp_parse_url( (string) $url );
		if ( ! is_array( $p ) || empty( $p['scheme'] ) || empty( $p['host'] ) ) {
			return new WP_Error( 'twdb_unsafe_url', 'The URL is not a valid absolute address.' );
		}
		$scheme = strtolower( $p['scheme'] );
		if ( ! in_array( $scheme, $https ? array( 'https' ) : array( 'http', 'https' ), true ) ) {
			return new WP_Error( 'twdb_unsafe_url', $https ? 'Only https addresses are allowed.' : 'Only http and https addresses are allowed.' );
		}
		if ( isset( $p['user'] ) || isset( $p['pass'] ) ) {
			return new WP_Error( 'twdb_unsafe_url', 'Addresses with a user name or password are not allowed.' );
		}
		$port = isset( $p['port'] ) ? (int) $p['port'] : ( 'https' === $scheme ? 443 : 80 );
		/**
		 * Ports outbound fetches may use.
		 *
		 * @param int[] $ports Ports.
		 */
		$ports = (array) apply_filters( 'twdb_allowed_fetch_ports', array( 80, 443, 8080, 8443 ) );
		if ( ! in_array( $port, array_map( 'intval', $ports ), true ) ) {
			return new WP_Error( 'twdb_unsafe_url', 'That port is not allowed.' );
		}
		$host = strtolower( trim( $p['host'], '[]' ) );
		$host = rtrim( $host, '.' );
		if ( 'localhost' === $host || '.localhost' === substr( $host, -10 ) ) {
			return new WP_Error( 'twdb_unsafe_url', 'Internal addresses are not allowed.' );
		}
		if ( '' === $host || strlen( $host ) > 253 ) {
			return new WP_Error( 'twdb_unsafe_url', 'The host name is not valid.' );
		}
		$ips = self::resolve( $host );
		if ( ! $ips ) {
			return new WP_Error( 'twdb_unsafe_url', 'The host name could not be resolved.' );
		}
		foreach ( $ips as $ip ) {
			if ( ! self::is_public_ip( $ip ) ) {
				return new WP_Error( 'twdb_unsafe_url', 'The address points to a private, local or reserved network, which is not allowed.' );
			}
		}
		// Prefer IPv4 for the pin: some hosts lack IPv6 routing.
		$pin = $ips[0];
		foreach ( $ips as $ip ) {
			if ( false !== filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
				$pin = $ip;
				break;
			}
		}
		return array(
			'host' => $host,
			'port' => $port,
			'ip'   => $pin,
		);
	}

	/**
	 * Did the transport pin the connection of the current fetch, and did a real transport run at all?
	 *
	 * @var array{pinned:bool,ran:bool}
	 */
	private static $pin_state = array(
		'pinned' => false,
		'ran'    => false,
	);

	/**
	 * Pin key ("host:port") of a URL.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	private static function pin_key( $url ) {
		$host = strtolower( rtrim( trim( (string) wp_parse_url( $url, PHP_URL_HOST ), '[]' ), '.' ) );
		$port = (int) wp_parse_url( $url, PHP_URL_PORT );
		if ( ! $port ) {
			$port = 'https' === strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) ) ? 443 : 80;
		}
		return $host . ':' . $port;
	}

	/**
	 * http_api_curl (cURL transport): connect to the address that was validated, not to a fresh DNS answer
	 * (DNS rebinding), and never through a proxy taken from the environment (it would resolve the name
	 * itself).
	 *
	 * @param resource|object $handle cURL handle.
	 * @param array           $args   Request args.
	 * @param string          $url    URL.
	 */
	public static function pin_curl( $handle, $args, $url ) {
		$k = self::pin_key( $url );
		if ( isset( self::$pins[ $k ] ) && defined( 'CURLOPT_RESOLVE' ) ) {
			$ip = self::$pins[ $k ];
			if ( false !== strpos( $ip, ':' ) ) {
				$ip = '[' . $ip . ']';
			}
			// phpcs:disable WordPress.WP.AlternativeFunctions.curl_curl_setopt -- Pinning the validated address on WordPress's own handle.
			curl_setopt( $handle, CURLOPT_RESOLVE, array( $k . ':' . $ip ) );
			curl_setopt( $handle, CURLOPT_PROXY, '' );
			// phpcs:enable
			self::$pin_state['pinned'] = true;
		}
	}

	/**
	 * requests-fsockopen.remote_socket (streams transport, plain HTTP only): open the socket to the validated
	 * address. The Host header is built from the URL, so the request itself is unchanged.
	 *
	 * @param string $remote_socket Socket address, e.g. "tcp://example.com:80" (by reference).
	 */
	public static function pin_socket( &$remote_socket ) {
		if ( ! preg_match( '#^tcp://(\[[^\]]+\]|[^:/]+):(\d+)$#i', (string) $remote_socket, $m ) ) {
			return; // TLS sockets are never pinned here: safe_get() refuses HTTPS on this transport.
		}
		$k = strtolower( rtrim( trim( $m[1], '[]' ), '.' ) ) . ':' . (int) $m[2];
		if ( isset( self::$pins[ $k ] ) ) {
			$ip                        = self::$pins[ $k ];
			$remote_socket             = 'tcp://' . ( false !== strpos( $ip, ':' ) ? '[' . $ip . ']' : $ip ) . ':' . (int) $m[2];
			self::$pin_state['pinned'] = true;
		}
	}

	/**
	 * http_api_debug: a real transport request happened (a pre_http_request short-circuit does not fire it).
	 */
	public static function transport_ran() {
		self::$pin_state['ran'] = true;
	}

	/**
	 * Will WordPress use the cURL transport for this request?
	 *
	 * @param bool $https HTTPS request.
	 * @return bool
	 */
	public static function curl_transport( $https ) {
		$caps = $https ? array( 'ssl' => true ) : array();
		if ( class_exists( '\WpOrg\Requests\Transport\Curl' ) ) {
			return (bool) \WpOrg\Requests\Transport\Curl::test( $caps );
		}
		if ( class_exists( 'Requests_Transport_cURL' ) ) {
			return (bool) Requests_Transport_cURL::test( $caps );
		}
		return function_exists( 'curl_init' ) && function_exists( 'curl_exec' );
	}

	/**
	 * GET a URL that a client chose, safely: validated before each hop, redirects followed manually (each new
	 * destination validated again), the connection pinned to the validated address on both WordPress
	 * transports, and the body capped. When pinning cannot be guaranteed (HTTPS without cURL, an HTTP proxy,
	 * or a transport that ignored the pin) the fetch fails instead of running unprotected.
	 *
	 * @param string $url           URL.
	 * @param array  $args          wp_safe_remote_get() args (redirection is forced to 0).
	 * @param int    $max_redirects Redirects to follow.
	 * @param bool   $https         Require https on every hop.
	 * @return array|WP_Error Response array, with 'twdb_final_url'.
	 */
	public static function safe_get( $url, $args = array(), $max_redirects = 3, $https = false ) {
		$args['redirection'] = 0;
		$hops                = 0;
		while ( true ) {
			$chk = self::check_url( $url, $https );
			if ( is_wp_error( $chk ) ) {
				return $chk;
			}
			$is_https = 0 === stripos( $url, 'https:' );
			$proxy    = new WP_HTTP_Proxy();
			if ( $proxy->is_enabled() && $proxy->send_through_proxy( $url ) ) {
				/**
				 * Allow client-chosen fetches through the HTTP proxy configured in wp-config.php. The proxy
				 * resolves host names itself, so the plugin cannot pin the address: only allow this when the
				 * proxy refuses private and internal destinations on its own.
				 *
				 * @param bool   $allow Allow.
				 * @param string $url   URL.
				 */
				if ( ! apply_filters( 'twdb_allow_proxied_fetch', false, $url ) ) {
					return new WP_Error( 'twdb_unpinnable', 'This site sends HTTP requests through a proxy, so the destination address cannot be pinned; the fetch was refused for safety.' );
				}
			} elseif ( $is_https && ! self::curl_transport( true ) ) {
				return new WP_Error( 'twdb_unpinnable', 'This server has no cURL with TLS support, so an HTTPS download cannot be pinned to the checked address; the fetch was refused for safety.' );
			}

			$key                = self::pin_key( $url );
			self::$pins[ $key ] = $chk['ip'];
			self::$pin_state    = array(
				'pinned' => false,
				'ran'    => false,
			);
			add_action( 'http_api_curl', array( __CLASS__, 'pin_curl' ), 10, 3 );
			add_action( 'requests-fsockopen.remote_socket', array( __CLASS__, 'pin_socket' ), 10, 1 );
			add_action( 'http_api_debug', array( __CLASS__, 'transport_ran' ), 10, 0 );
			$res = wp_safe_remote_get( $url, $args );
			remove_action( 'http_api_curl', array( __CLASS__, 'pin_curl' ), 10 );
			remove_action( 'requests-fsockopen.remote_socket', array( __CLASS__, 'pin_socket' ), 10 );
			remove_action( 'http_api_debug', array( __CLASS__, 'transport_ran' ), 10 );
			unset( self::$pins[ $key ] );

			if ( is_wp_error( $res ) ) {
				return $res; // Nothing was fetched: report the transport's own error.
			}
			$unpinned = self::$pin_state['ran'] && ! self::$pin_state['pinned'] && ! ( $proxy->is_enabled() && $proxy->send_through_proxy( $url ) );
			if ( $unpinned ) {
				// A transport ran without applying the pin (e.g. a custom transport): discard what it fetched.
				if ( ! empty( $args['filename'] ) && file_exists( $args['filename'] ) ) {
					wp_delete_file( $args['filename'] );
				}
				return new WP_Error( 'twdb_unpinned', 'The HTTP transport did not connect to the checked address, so its response was discarded for safety.' );
			}
			$code = (int) wp_remote_retrieve_response_code( $res );
			if ( $code >= 300 && $code < 400 && in_array( $code, array( 301, 302, 303, 307, 308 ), true ) ) {
				$loc = (string) wp_remote_retrieve_header( $res, 'location' );
				if ( '' === $loc ) {
					return $res;
				}
				if ( ++$hops > $max_redirects ) {
					if ( ! empty( $args['filename'] ) && file_exists( $args['filename'] ) ) {
						wp_delete_file( $args['filename'] );
					}
					return new WP_Error( 'twdb_too_many_redirects', 'Too many redirects.' );
				}
				$url = WP_Http::make_absolute_url( $loc, $url );
				continue;
			}
			$res['twdb_final_url'] = $url;
			return $res;
		}
	}

	/**
	 * Download a client-chosen URL to a temporary file with the SSRF protections of safe_get() and a hard
	 * size cap enforced while streaming.
	 *
	 * @param string $url       URL.
	 * @param int    $max_bytes Maximum size.
	 * @param int    $timeout   Timeout.
	 * @return string|WP_Error Temporary file path.
	 */
	public static function download( $url, $max_bytes, $timeout = 60 ) {
		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = wp_tempnam( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		if ( ! $tmp ) {
			return new WP_Error( 'twdb_tmp', 'Could not create a temporary file.' );
		}
		$res = self::safe_get(
			$url,
			array(
				'timeout'             => $timeout,
				'stream'              => true,
				'filename'            => $tmp,
				'limit_response_size' => $max_bytes + 1,
			)
		);
		if ( is_wp_error( $res ) ) {
			if ( file_exists( $tmp ) ) {
				wp_delete_file( $tmp );
			}
			return $res;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( 200 !== $code ) {
			wp_delete_file( $tmp );
			return new WP_Error( 'twdb_http', sprintf( 'The server answered HTTP %d.', $code ) );
		}
		clearstatcache( true, $tmp );
		if ( filesize( $tmp ) > $max_bytes ) {
			wp_delete_file( $tmp );
			return new WP_Error( 'twdb_too_large', 'The file is larger than ' . size_format( $max_bytes ) . '.' );
		}
		return $tmp;
	}
}
