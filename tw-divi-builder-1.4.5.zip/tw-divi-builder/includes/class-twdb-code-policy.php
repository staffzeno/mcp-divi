<?php
/**
 * Code insertion policy: AI clients can build layouts, text, images and design, but cannot add executable code
 * (JavaScript, iframes, objects/embeds, inline event handlers, javascript:/data: URLs, CSS expressions) to the
 * site. Enforced on the server, in every tool that saves content or design data.
 *
 * How it works: the incoming markup is parsed into blocks and every string value (block attributes such as
 * Divi module settings, and HTML between blocks) is compared with the values already stored for the same
 * page or layout. Values that are byte-for-byte unchanged are kept as they are, so existing content made by
 * people, including existing Divi Code modules, survives an AI edit untouched. Every new or changed value is
 * sanitised with WordPress's own HTML allow-list, extended with static SVG graphics and <style>.
 *
 * Reading is not affected: tools return stored content as data and never execute it.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Code insertion policy.
 */
class TWDB_Code_Policy {

	/**
	 * Messages for the AI about what was removed during the current tool call.
	 *
	 * @var string[]
	 */
	private static $notes = array();

	/**
	 * Start a tool call.
	 */
	public static function reset() {
		self::$notes = array();
	}

	/**
	 * Messages collected since reset().
	 *
	 * @return string[]
	 */
	public static function notes() {
		return array_values( array_unique( self::$notes ) );
	}

	/**
	 * Record a removal.
	 *
	 * @param string $what What was removed.
	 */
	private static function note( $what ) {
		self::$notes[] = 'Removed ' . $what . ': this site does not let AI clients add scripts, iframes, embeds, event handlers or executable URLs. Use native Divi modules (e.g. divi/video for videos, divi/map for maps).';
	}

	/* -------------------- Allowed HTML -------------------- */

	/**
	 * WordPress's post allow-list plus static SVG graphics and <style> blocks (CSS is design, not code).
	 *
	 * @return array
	 */
	public static function allowed_html() {
		static $allowed = null;
		if ( null !== $allowed ) {
			return $allowed;
		}
		$allowed = wp_kses_allowed_html( 'post' );
		foreach ( array( 'script', 'iframe', 'object', 'embed', 'applet', 'frame', 'frameset', 'base', 'meta', 'link', 'foreignobject' ) as $never ) {
			unset( $allowed[ $never ] );
		}
		$presentation = array(
			'class'             => true,
			'id'                => true,
			'style'             => true,
			'fill'              => true,
			'fill-rule'         => true,
			'fill-opacity'      => true,
			'clip-rule'         => true,
			'clip-path'         => true,
			'stroke'            => true,
			'stroke-width'      => true,
			'stroke-linecap'    => true,
			'stroke-linejoin'   => true,
			'stroke-dasharray'  => true,
			'stroke-dashoffset' => true,
			'stroke-opacity'    => true,
			'opacity'           => true,
			'transform'         => true,
			'mask'              => true,
			'aria-hidden'       => true,
			'aria-label'        => true,
			'role'              => true,
			'focusable'         => true,
		);
		$shapes       = array(
			'svg'            => array(
				'xmlns'               => true,
				'viewbox'             => true,
				'width'               => true,
				'height'              => true,
				'preserveaspectratio' => true,
				'version'             => true,
			),
			'g'              => array(),
			'path'           => array(
				'd'          => true,
				'pathlength' => true,
			),
			'circle'         => array(
				'cx' => true,
				'cy' => true,
				'r'  => true,
			),
			'ellipse'        => array(
				'cx' => true,
				'cy' => true,
				'rx' => true,
				'ry' => true,
			),
			'rect'           => array(
				'x'      => true,
				'y'      => true,
				'width'  => true,
				'height' => true,
				'rx'     => true,
				'ry'     => true,
			),
			'line'           => array(
				'x1' => true,
				'y1' => true,
				'x2' => true,
				'y2' => true,
			),
			'polyline'       => array( 'points' => true ),
			'polygon'        => array( 'points' => true ),
			'defs'           => array(),
			'symbol'         => array( 'viewbox' => true ),
			'title'          => array(),
			'desc'           => array(),
			'clippath'       => array( 'clippathunits' => true ),
			'lineargradient' => array(
				'x1'                => true,
				'y1'                => true,
				'x2'                => true,
				'y2'                => true,
				'gradientunits'     => true,
				'gradienttransform' => true,
			),
			'radialgradient' => array(
				'cx'                => true,
				'cy'                => true,
				'r'                 => true,
				'fx'                => true,
				'fy'                => true,
				'gradientunits'     => true,
				'gradienttransform' => true,
			),
			'stop'           => array(
				'offset'       => true,
				'stop-color'   => true,
				'stop-opacity' => true,
			),
			'text'           => array(
				'x'           => true,
				'y'           => true,
				'dx'          => true,
				'dy'          => true,
				'text-anchor' => true,
				'font-size'   => true,
				'font-family' => true,
				'font-weight' => true,
			),
			'tspan'          => array(
				'x'  => true,
				'y'  => true,
				'dx' => true,
				'dy' => true,
			),
		);
		foreach ( $shapes as $tag => $attrs ) {
			$allowed[ $tag ] = $attrs + $presentation;
		}
		$allowed['style'] = array(
			'media' => true,
			'type'  => true,
		);
		return $allowed;
	}

	/* -------------------- Strings -------------------- */

	/**
	 * Decoded text without the characters browsers ignore inside a URL scheme (tab, CR, LF, NUL).
	 *
	 * @param string $v Value.
	 * @return string
	 */
	private static function decoded( $v ) {
		$v = html_entity_decode( (string) $v, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		return (string) preg_replace( '/[\x00-\x08\x0A-\x0D\x7F]/', '', str_replace( "\t", '', $v ) );
	}

	/**
	 * Is this whole value an executable URL: javascript:/vbscript:/livescript:, or a data: URL other than a
	 * raster image? Applies to plain values (link fields, image fields), not to prose: HTML is checked by
	 * WordPress's allow-list, which validates link protocols itself.
	 *
	 * @param string $v Value.
	 * @return bool
	 */
	public static function has_executable_url( $v, $url_field = false ) {
		$t = ltrim( self::decoded( $v ) );
		// Prose such as "JavaScript: the basics" is not a link: a value is treated as a URL when it contains no
		// spaces, or when it sits in a link-type setting.
		if ( ! $url_field && preg_match( '/\s/', $t ) ) {
			return false;
		}
		if ( preg_match( '/^(?:java|vb|live)script\s*:/i', $t ) ) {
			return true;
		}
		return (bool) preg_match( '#^data\s*:\s*(?!image/(?:png|jpe?g|gif|webp|avif)[;,])[a-z]+/[a-z0-9.+-]+#i', $t );
	}

	/**
	 * Does this value contain script-like CSS: an expression() value, a behavior or -moz-binding property, or
	 * a url() pointing at javascript:/vbscript:? Matches CSS syntax only, so ordinary prose is not affected.
	 *
	 * @param string $css CSS (or a string that may hold a <style> block or declarations).
	 * @return bool
	 */
	public static function has_executable_css( $css ) {
		$c = self::decoded( $css );
		$c = (string) preg_replace( '#/\*.*?\*/#s', '', str_replace( '\\', '', $c ) ); // Comments and CSS escapes.
		return (bool) preg_match( '/[a-z-]+\s*:\s*expression\s*\(|\bbehavior\s*:\s*url\s*\(|-moz-binding\s*:|url\s*\(\s*[\'"]?\s*(?:java|vb)script\s*:/i', $c );
	}

	/**
	 * Sanitise one new or changed string value.
	 *
	 * @param string $v Value.
	 * @return string
	 */
	public static function clean_string( $v, $key = '' ) {
		$v = (string) $v;
		if ( false !== strpos( $v, '<' ) ) {
			$clean = wp_kses( $v, self::allowed_html() );
			// Report only real removals, not formatting kses normalises ("/>" spacing, "&" to "&amp;", and on
			// WordPress 7.1+ lower-case attribute names such as viewBox, which HTML parsers restore for SVG).
			$shape = static function ( $h ) {
				return strtolower( (string) preg_replace( '/[\s\/]+/', '', wp_kses_normalize_entities( $h ) ) );
			};
			if ( $shape( $v ) !== $shape( $clean ) ) {
				self::note( 'HTML that is not allowed' );
			}
			$v = $clean;
		} elseif ( self::has_executable_url( $v, (bool) preg_match( '/(url|href|src|link|image|action|background)$/i', (string) $key ) ) ) {
			self::note( 'an executable URL' );
			return '';
		}
		if ( self::has_executable_css( $v ) ) {
			self::note( 'script-like CSS' );
			$v = (string) preg_replace( '/\bexpression\s*\(|\bbehavior\s*:|-moz-binding\s*:|(?:java|vb)script\s*:/i', 'blocked-', $v );
		}
		return $v;
	}

	/* -------------------- Structures -------------------- */

	/**
	 * Sanitise a nested array, leaving strings found in $known untouched. Drops custom-attribute entries that
	 * define event handlers (e.g. Divi's Attributes option: {"name":"onclick","value":"..."}).
	 *
	 * @param mixed $value Value.
	 * @param array $known Strings already stored.
	 * @return mixed
	 */
	public static function clean_value( $value, array $known = array(), $key = '' ) {
		return self::walk( $value, $known, $key, null );
	}

	/**
	 * Is this existing value allowed to stay? With $path === null, $known is a plain set (string => true). With a
	 * path, $known maps "path|value" to how many times it is stored; every preserved copy uses one up, so
	 * existing code cannot be copied to another module or attribute, or duplicated.
	 *
	 * @param array       $known Known values (by reference).
	 * @param string|null $path  Attribute path, or null.
	 * @param string      $v     Value.
	 * @return bool
	 */
	private static function keep( array &$known, $path, $v ) {
		if ( null === $path ) {
			return isset( $known[ $v ] );
		}
		$id = $path . '|' . $v;
		if ( empty( $known[ $id ] ) ) {
			return false;
		}
		--$known[ $id ];
		return true;
	}

	/**
	 * Path segment for an array key: list positions are not part of the path, so reordering a list keeps it.
	 *
	 * @param int|string $k Key.
	 * @return string
	 */
	private static function seg( $k ) {
		return is_int( $k ) ? '#' : (string) $k;
	}

	/**
	 * Sanitise a nested value (see clean_value()).
	 *
	 * @param mixed       $value Value.
	 * @param array       $known Known values (by reference).
	 * @param string      $key   Nearest string key.
	 * @param string|null $path  Attribute path for counted preservation, or null for set semantics.
	 * @return mixed
	 */
	private static function walk( $value, array &$known, $key, $path ) {
		if ( is_string( $value ) ) {
			return self::keep( $known, $path, $value ) ? $value : self::clean_string( $value, $key );
		}
		if ( ! is_array( $value ) ) {
			return $value;
		}
		$is_list = wp_is_numeric_array( $value );
		foreach ( $value as $k => $v ) {
			$sub = null === $path ? null : $path . '/' . self::seg( $k );
			if ( is_array( $v ) && isset( $v['name'] ) && is_string( $v['name'] ) && preg_match( '/^\s*(on[a-z]+|srcdoc|formaction)\s*$/i', $v['name'] ) ) {
				$kept = isset( $v['value'] ) && is_string( $v['value'] ) && self::keep( $known, null === $sub ? null : $sub . '/name', $v['name'] ) && self::keep( $known, null === $sub ? null : $sub . '/value', $v['value'] );
				if ( ! $kept ) {
					self::note( 'an event-handler attribute (' . sanitize_key( $v['name'] ) . ')' );
					unset( $value[ $k ] );
				}
				continue;
			}
			if ( is_string( $k ) && preg_match( '/^on[a-z]+$/i', $k ) && is_string( $v ) ) {
				if ( ! self::keep( $known, $sub, $v ) ) {
					self::note( 'an event-handler attribute (' . sanitize_key( $k ) . ')' );
					unset( $value[ $k ] );
				}
				continue;
			}
			$value[ $k ] = self::walk( $v, $known, is_string( $k ) ? $k : $key, $sub );
		}
		return $is_list ? array_values( $value ) : $value;
	}

	/**
	 * Strings stored in existing markup: block attribute values and the HTML between and around blocks.
	 *
	 * @param string $markup Markup.
	 * @return array string => true
	 */
	public static function known_strings( $markup ) {
		$set = array();
		if ( '' === (string) $markup ) {
			return $set;
		}
		$counts = array();
		self::collect_blocks( parse_blocks( (string) $markup ), $counts );
		foreach ( array_keys( $counts ) as $id ) {
			$parts                = explode( '|', (string) $id, 3 );
			$set[ end( $parts ) ] = true;
		}
		return $set;
	}
	/**
	 * Stored values of parsed blocks, keyed "blockName|attribute path|value" with how often each occurs.
	 *
	 * @param array  $blocks Blocks.
	 * @param array  $set    Counts (by reference).
	 */
	private static function collect_blocks( array $blocks, array &$set ) {
		foreach ( $blocks as $b ) {
			$name = isset( $b['blockName'] ) ? (string) $b['blockName'] : '';
			self::count_values( isset( $b['attrs'] ) ? $b['attrs'] : array(), $name, $set );
			foreach ( (array) $b['innerContent'] as $chunk ) {
				if ( is_string( $chunk ) ) {
					$id         = $name . '|html|' . $chunk;
					$set[ $id ] = isset( $set[ $id ] ) ? $set[ $id ] + 1 : 1;
				}
			}
			if ( ! empty( $b['innerBlocks'] ) ) {
				self::collect_blocks( $b['innerBlocks'], $set );
			}
		}
	}

	/**
	 * Count string values by path.
	 *
	 * @param mixed  $value Value.
	 * @param string $path  Path so far.
	 * @param array  $set   Counts (by reference).
	 */
	private static function count_values( $value, $path, array &$set ) {
		if ( is_string( $value ) ) {
			$id         = $path . '|' . $value;
			$set[ $id ] = isset( $set[ $id ] ) ? $set[ $id ] + 1 : 1;
		} elseif ( is_array( $value ) ) {
			foreach ( $value as $k => $v ) {
				self::count_values( $v, $path . '/' . self::seg( $k ), $set );
			}
		}
	}

	/**
	 * Sanitise parsed blocks in place.
	 *
	 * @param array $blocks Blocks.
	 * @param array $known  Stored values with counts (by reference).
	 * @return array
	 */
	private static function clean_blocks( array $blocks, array &$known ) {
		foreach ( $blocks as &$b ) {
			$name = isset( $b['blockName'] ) ? (string) $b['blockName'] : '';
			if ( ! empty( $b['attrs'] ) ) {
				$b['attrs'] = self::walk( $b['attrs'], $known, '', $name );
			}
			$changed = false;
			foreach ( (array) $b['innerContent'] as $i => $chunk ) {
				if ( is_string( $chunk ) && '' !== trim( $chunk ) && ! self::keep( $known, $name . '|html', $chunk ) ) {
					$clean = self::clean_string( $chunk );
					if ( $clean !== $chunk ) {
						$b['innerContent'][ $i ] = $clean;
						$changed                 = true;
					}
				}
			}
			if ( $changed ) {
				$b['innerHTML'] = implode( '', array_filter( $b['innerContent'], 'is_string' ) );
			}
			if ( ! empty( $b['innerBlocks'] ) ) {
				$b['innerBlocks'] = self::clean_blocks( $b['innerBlocks'], $known );
			}
		}
		unset( $b );
		return $blocks;
	}

	/**
	 * Defense in depth: how many executable constructs the markup contains (tags that run or embed code, and
	 * event-handler attributes), counted in the block comment JSON as well as the HTML.
	 *
	 * @param string $markup Markup.
	 * @return int
	 */
	public static function executable_count( $markup ) {
		$m  = str_ireplace( array( '\u003c', '\u003e', '\u0022', '\u0027', '\/' ), array( '<', '>', '"', "'", '/' ), (string) $markup );
		$n  = preg_match_all( '/<\s*(?:script|iframe|object|embed|applet|frame|frameset|base|meta|link|foreignobject)\b/i', $m );
		$n += preg_match_all( '/<[a-z][^<>]*?[\s\/"\']on[a-z]+\s*=/i', $m );
		return (int) $n;
	}

	/**
	 * Apply the policy to markup about to be saved over $old (the content currently stored for the same post,
	 * '' for a new one). Returns the markup to save; unchanged input is returned byte for byte.
	 *
	 * @param string $markup New markup.
	 * @param string $old    Stored markup.
	 * @return string
	 */
	public static function clean_markup( $markup, $old = '' ) {
		$markup = (string) $markup;
		if ( '' === trim( $markup ) || $markup === (string) $old ) {
			return $markup;
		}
		$known = array();
		if ( '' !== (string) $old ) {
			self::collect_blocks( parse_blocks( (string) $old ), $known );
		}
		$before = count( self::$notes );
		$blocks = self::clean_blocks( parse_blocks( $markup ), $known );
		$out    = count( self::$notes ) === $before ? $markup : serialize_blocks( $blocks ); // Nothing removed: keep the client's formatting exactly.
		// Final check, independent of the per-value rules: the result may not contain more executable
		// constructs than the stored content already had. Refuse the save rather than store new code.
		if ( self::executable_count( $out ) > self::executable_count( (string) $old ) ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'The content still contained executable code (scripts, embeds or event handlers) after cleaning, so nothing was saved. Remove the code and try again.' );
		}
		return $out;
	}

	/**
	 * Clean a plain text field such as a title or excerpt (keeps allowed inline HTML, removes code).
	 *
	 * @param string $text New text.
	 * @param string $old  Stored text: an unchanged value is kept.
	 * @return string
	 */
	public static function clean_text( $text, $old = '' ) {
		$text = (string) $text;
		return $text === (string) $old ? $text : self::clean_string( $text );
	}

	/**
	 * Reject CSS with script-like constructs (used by the CSS tools).
	 *
	 * @param string $css CSS.
	 * @throws TWDB_Tool_Error When found.
	 */
	public static function assert_css( $css ) {
		if ( self::has_executable_css( (string) $css ) ) {
			throw new TWDB_Tool_Error( 'invalid_arguments', 'CSS must not contain expression(), behavior:, -moz-binding or javascript:/vbscript: URLs. Nothing was saved.' );
		}
	}
}
