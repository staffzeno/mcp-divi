<?php
/**
 * JSON responses for the OAuth endpoints.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Uncached JSON REST responses shared by the OAuth classes.
 */
class TWDB_OAuth_Response {

	/**
	 * JSON response that clients and proxies must not cache.
	 *
	 * @param array $body   Body.
	 * @param int   $status Status.
	 * @return WP_REST_Response
	 */
	public static function json( array $body, $status = 200 ) {
		$response = new WP_REST_Response( $body, $status );
		$response->header( 'Cache-Control', 'no-store' );
		$response->header( 'Pragma', 'no-cache' );
		return $response;
	}

	/**
	 * OAuth error body (RFC 6749 section 5.2).
	 *
	 * @param string $error       Error code.
	 * @param string $description Description.
	 * @param int    $status      Status.
	 * @return WP_REST_Response
	 */
	public static function error( $error, $description, $status = 400 ) {
		return self::json(
			array(
				'error'             => $error,
				'error_description' => $description,
			),
			$status
		);
	}
}
