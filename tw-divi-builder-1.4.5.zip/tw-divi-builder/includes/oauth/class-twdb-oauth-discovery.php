<?php
/**
 * OAuth discovery: the metadata documents an MCP client reads before it signs in.
 *
 *  - Protected-resource metadata (RFC 9728) tells the client which authorization server protects the MCP
 *    endpoint. Its address is sent in the WWW-Authenticate header of every 401 from the MCP endpoint.
 *  - Authorization-server metadata (RFC 8414), plus the OpenID Connect discovery form of the same document,
 *    lists the endpoints and what they support.
 *
 * Two issuers are published. The REST issuer (…/wp-json/tw-divi/v1/oauth) is preferred because every request
 * under /wp-json/ reaches WordPress, while some hosts answer /.well-known/ themselves. The site root is the
 * issuer when pretty permalinks are off (an issuer must not contain a query string).
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * OAuth discovery documents.
 */
class TWDB_OAuth_Discovery {

	/**
	 * Hook the /.well-known/ responder and the REST routes.
	 */
	public static function hook() {
		add_action( 'init', array( __CLASS__, 'answer_well_known' ), 0 );
	}

	/* -------------------- Addresses -------------------- */

	/**
	 * The site root without a trailing slash.
	 *
	 * @return string
	 */
	public static function site_issuer() {
		return untrailingslashit( home_url( '/' ) );
	}

	/**
	 * The issuer advertised to clients.
	 *
	 * @return string
	 */
	public static function issuer() {
		$rest = rest_url( TWDB_REST_NS . '/oauth' );
		return false === strpos( $rest, '?' ) ? untrailingslashit( $rest ) : self::site_issuer();
	}

	/**
	 * A REST route of this plugin written in its /wp-json/ form (used for the path-issuer well-known forms,
	 * which must be real paths even when rest_url() would return a query-string address).
	 *
	 * @param string $route Route under the namespace.
	 * @return string
	 */
	private static function path_form( $route ) {
		return home_url( '/' . rest_get_url_prefix() . '/' . TWDB_REST_NS . '/' . ltrim( $route, '/' ) );
	}

	/**
	 * The protected MCP resource.
	 *
	 * @return string
	 */
	public static function resource() {
		return rest_url( TWDB_REST_NS . '/mcp' );
	}

	/**
	 * Endpoint addresses.
	 *
	 * @return array<string,string>
	 */
	public static function endpoints() {
		return array(
			'authorization' => admin_url( 'admin-post.php?action=' . TWDB_OAuth::ACTION_AUTHORIZE ),
			'token'         => rest_url( TWDB_REST_NS . '/oauth/token' ),
			'registration'  => rest_url( TWDB_REST_NS . '/oauth/register' ),
			'revocation'    => rest_url( TWDB_REST_NS . '/oauth/revoke' ),
			'jwks'          => rest_url( TWDB_REST_NS . '/oauth/jwks' ),
			'resource_meta' => rest_url( TWDB_REST_NS . '/oauth/resource' ),
		);
	}

	/* -------------------- Documents -------------------- */

	/**
	 * Protected-resource metadata (RFC 9728).
	 *
	 * @return array
	 */
	public static function resource_document() {
		return array(
			'resource'                 => self::resource(),
			'authorization_servers'    => array( self::issuer() ),
			'scopes_supported'         => array( TWDB_OAuth::SCOPE ),
			'bearer_methods_supported' => array( 'header' ),
			'resource_name'            => 'Tech Webers MCP Builder for Divi 5 - ' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
		);
	}

	/**
	 * Authorization-server metadata (RFC 8414). With $openid, the OpenID Connect discovery form: this server
	 * issues no ID tokens, so it publishes an empty key set.
	 *
	 * @param string $issuer Issuer to state ('' = the advertised one).
	 * @param bool   $openid OpenID form.
	 * @return array
	 */
	public static function server_document( $issuer = '', $openid = false ) {
		$e   = self::endpoints();
		$doc = array(
			'issuer'                                     => '' === $issuer ? self::issuer() : $issuer,
			'authorization_endpoint'                     => $e['authorization'],
			'token_endpoint'                             => $e['token'],
			'registration_endpoint'                      => $e['registration'],
			'revocation_endpoint'                        => $e['revocation'],
			'scopes_supported'                           => array( TWDB_OAuth::SCOPE ),
			'response_types_supported'                   => array( 'code' ),
			'response_modes_supported'                   => array( 'query' ),
			'grant_types_supported'                      => array( 'authorization_code', 'refresh_token' ),
			'code_challenge_methods_supported'           => array( 'S256' ),
			'token_endpoint_auth_methods_supported'      => array( 'none', 'client_secret_post' ),
			'revocation_endpoint_auth_methods_supported' => array( 'none', 'client_secret_post' ),
			'client_id_metadata_document_supported'      => true,
		);
		if ( $openid ) {
			$doc['jwks_uri']                              = $e['jwks'];
			$doc['subject_types_supported']               = array( 'public' );
			$doc['id_token_signing_alg_values_supported'] = array( 'none' );
		}
		return $doc;
	}

	/**
	 * The WWW-Authenticate value for a 401 from the MCP endpoint.
	 *
	 * @param string $error       OAuth error code ('' for none).
	 * @param string $description Optional description.
	 * @return string
	 */
	public static function challenge( $error = '', $description = '' ) {
		$parts = array( 'resource_metadata="' . self::endpoints()['resource_meta'] . '"' );
		if ( '' !== $error ) {
			$parts[] = 'error="' . preg_replace( '/[^a-z_]/', '', $error ) . '"';
			if ( '' !== $description ) {
				$parts[] = 'error_description="' . str_replace( array( '"', '\\' ), "'", $description ) . '"';
			}
		}
		return 'Bearer ' . implode( ', ', $parts );
	}

	/* -------------------- /.well-known/ -------------------- */

	/**
	 * Every /.well-known/ path this install answers, mapped to the document it returns.
	 *
	 * Clients build these addresses in two ways: RFC 8414 / 9728 insert the well-known segment between the
	 * host and the issuer's (or resource's) path; OpenID Connect discovery appends it to the issuer. Only the
	 * exact addresses below are answered.
	 *
	 * @return array<string,string> path => resource|server|openid|server_rest|openid_rest
	 */
	public static function well_known_paths() {
		$site     = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		$rest_iss = rtrim( (string) wp_parse_url( self::path_form( 'oauth' ), PHP_URL_PATH ), '/' );
		$rest_mcp = rtrim( (string) wp_parse_url( self::path_form( 'mcp' ), PHP_URL_PATH ), '/' );
		$res_path = rtrim( (string) wp_parse_url( self::resource(), PHP_URL_PATH ), '/' );

		$paths = array(
			// Resource metadata: site-level, and inserted before the MCP endpoint's path.
			$site . '/.well-known/oauth-protected-resource' => 'resource',
			'/.well-known/oauth-protected-resource' . $rest_mcp => 'resource',
			// Site-root issuer: inserted and appended forms.
			'/.well-known/oauth-authorization-server' . $site => 'server',
			$site . '/.well-known/oauth-authorization-server' => 'server',
			'/.well-known/openid-configuration' . $site => 'openid',
			$site . '/.well-known/openid-configuration' => 'openid',
			// REST-path issuer: inserted forms (the appended forms are REST routes).
			'/.well-known/oauth-authorization-server' . $rest_iss => 'server_rest',
			'/.well-known/openid-configuration' . $rest_iss => 'openid_rest',
		);
		if ( '' === (string) wp_parse_url( self::resource(), PHP_URL_QUERY ) ) {
			$paths[ '/.well-known/oauth-protected-resource' . $res_path ] = 'resource';
		}
		return $paths;
	}

	/**
	 * Answer a /.well-known/ request before WordPress routes it.
	 */
	public static function answer_well_known() {
		if ( ! TWDB_OAuth::enabled() || empty( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$uri = esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) );
		if ( false === strpos( $uri, '/.well-known/' ) ) {
			return;
		}
		$path  = rtrim( (string) wp_parse_url( $uri, PHP_URL_PATH ), '/' );
		$paths = self::well_known_paths();
		if ( ! isset( $paths[ $path ] ) ) {
			return;
		}
		$rest_issuer = untrailingslashit( self::path_form( 'oauth' ) );
		switch ( $paths[ $path ] ) {
			case 'server':
				$doc = self::server_document( self::site_issuer() );
				break;
			case 'openid':
				$doc = self::server_document( self::site_issuer(), true );
				break;
			case 'server_rest':
				$doc = self::server_document( $rest_issuer );
				break;
			case 'openid_rest':
				$doc = self::server_document( $rest_issuer, true );
				break;
			default:
				$doc = self::resource_document();
		}
		status_header( 200 );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Access-Control-Allow-Origin: *' );
		echo wp_json_encode( $doc ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON document.
		exit;
	}

	/* -------------------- REST -------------------- */

	/**
	 * Register the public GET routes for the documents.
	 */
	public static function routes() {
		$docs = array(
			'/oauth/metadata'                          => static function () {
				return TWDB_OAuth_Response::json( self::server_document() );
			},
			'/oauth/openid'                            => static function () {
				return TWDB_OAuth_Response::json( self::server_document( '', true ) );
			},
			'/oauth/resource'                          => static function () {
				return TWDB_OAuth_Response::json( self::resource_document() );
			},
			'/oauth/jwks'                              => static function () {
				return TWDB_OAuth_Response::json( array( 'keys' => array() ) );
			},
			// Appended forms for the REST issuer.
			'/oauth/\.well-known/oauth-authorization-server' => static function () {
				return TWDB_OAuth_Response::json( self::server_document( self::issuer() ) );
			},
			'/oauth/\.well-known/openid-configuration' => static function () {
				return TWDB_OAuth_Response::json( self::server_document( self::issuer(), true ) );
			},
		);
		foreach ( $docs as $route => $callback ) {
			register_rest_route(
				TWDB_REST_NS,
				$route,
				array(
					'methods'             => 'GET',
					'callback'            => $callback,
					'permission_callback' => '__return_true', // Public by definition (RFC 8414 / 9728).
				)
			);
		}
	}
}
