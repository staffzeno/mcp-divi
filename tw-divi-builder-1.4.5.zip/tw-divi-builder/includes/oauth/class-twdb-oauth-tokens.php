<?php
/**
 * Tokens: the token endpoint (RFC 6749 sections 4.1.3 and 6), revocation (RFC 7009) and the bearer check
 * the MCP endpoint runs on every request.
 *
 * Lifetimes: access token 1 hour, refresh token 30 days. Each refresh issues a new pair and retires the old
 * refresh token; presenting a retired refresh token again (other than an immediate retry) ends the whole
 * connection, as RFC 9700 section 4.14.2 recommends, because it means the token was copied.
 *
 * A grant stays usable only while the administrator who approved it is still an administrator allowed to
 * delegate to the "AI acts as user" account.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * OAuth tokens.
 */
class TWDB_OAuth_Tokens {

	const ACCESS_TTL   = HOUR_IN_SECONDS;
	const REFRESH_TTL  = 30 * DAY_IN_SECONDS;
	const RETRY_WINDOW = 10;
	const FAILS        = 30;
	const FAIL_WINDOW  = 900;

	/**
	 * The grant that authenticated the current request.
	 *
	 * @var array|null
	 */
	private static $active = null;

	/**
	 * New random token with a prefix.
	 *
	 * @param string $prefix Prefix.
	 * @return string
	 */
	private static function token( $prefix ) {
		return $prefix . bin2hex( random_bytes( 32 ) );
	}

	/**
	 * May this approver still grant access to the configured acting user?
	 *
	 * @param int $approver User id.
	 * @return WP_User|null
	 */
	private static function approver_ok( $approver ) {
		$user = get_userdata( (int) $approver );
		if ( ! $user || ! user_can( $user, 'manage_options' ) || ! TWDB_Settings::may_delegate( $user->ID, TWDB_Settings::acting_user_id() ) ) {
			return null;
		}
		return $user;
	}

	/**
	 * Put a fresh access/refresh pair on a grant and return the response body.
	 *
	 * @param array $grant Grant (by reference).
	 * @return array
	 */
	private static function issue( array &$grant ) {
		$access  = self::token( TWDB_OAuth::PREFIX_ACCESS );
		$refresh = self::token( TWDB_OAuth::PREFIX_REFRESH );

		$grant['access']  = array(
			'hash'    => TWDB_OAuth_Repository::digest( $access ),
			'expires' => time() + self::ACCESS_TTL,
		);
		$grant['refresh'] = array(
			'hash'    => TWDB_OAuth_Repository::digest( $refresh ),
			'expires' => time() + self::REFRESH_TTL,
		);
		return array(
			'access_token'  => $access,
			'token_type'    => 'Bearer',
			'expires_in'    => self::ACCESS_TTL,
			'refresh_token' => $refresh,
			'scope'         => TWDB_OAuth::SCOPE,
		);
	}

	/* -------------------- Token endpoint -------------------- */

	/**
	 * POST /oauth/token.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function exchange( WP_REST_Request $request ) {
		if ( ! TWDB_Security::rate_ok( 'oauth_token_fail', self::FAILS, self::FAIL_WINDOW, false ) ) {
			$r = TWDB_OAuth_Response::error( 'invalid_request', 'Too many failed token requests from this address. Try again in 15 minutes.', 429 );
			$r->header( 'Retry-After', (string) self::FAIL_WINDOW );
			return $r;
		}
		$in   = TWDB_OAuth::request_values( $request );
		$type = isset( $in['grant_type'] ) && is_string( $in['grant_type'] ) ? $in['grant_type'] : '';

		$outcome = TWDB_OAuth_Repository::transaction(
			static function ( array &$data ) use ( $in, $type ) {
				if ( 'authorization_code' === $type ) {
					return self::redeem_code( $data, $in );
				}
				if ( 'refresh_token' === $type ) {
					return self::rotate( $data, $in );
				}
				return array( 'unsupported_grant_type', 'grant_type must be authorization_code or refresh_token.', 400 );
			}
		);
		if ( is_wp_error( $outcome ) ) {
			return TWDB_OAuth::busy();
		}
		if ( isset( $outcome['access_token'] ) ) {
			return TWDB_OAuth_Response::json( $outcome );
		}
		TWDB_Security::rate_ok( 'oauth_token_fail', self::FAILS, self::FAIL_WINDOW );
		return TWDB_OAuth_Response::error( $outcome[0], $outcome[1], $outcome[2] );
	}

	/**
	 * A string request value.
	 *
	 * @param array  $in  Values.
	 * @param string $key Key.
	 * @return string
	 */
	private static function val( array $in, $key ) {
		return isset( $in[ $key ] ) && is_scalar( $in[ $key ] ) ? (string) $in[ $key ] : '';
	}

	/**
	 * authorization_code grant. The code is removed first, whatever happens next, so it can never be used
	 * twice (the surrounding transaction makes this atomic).
	 *
	 * @param array $data Store (by reference).
	 * @param array $in   Request values.
	 * @return array Token body, or [error, description, status].
	 */
	private static function redeem_code( array &$data, array $in ) {
		$key = TWDB_OAuth_Repository::digest( self::val( $in, 'code' ) );
		if ( '' === self::val( $in, 'code' ) || ! isset( $data['codes'][ $key ] ) ) {
			return array( 'invalid_grant', 'The authorization code is unknown, already used or expired.', 400 );
		}
		$code = $data['codes'][ $key ];
		unset( $data['codes'][ $key ] );

		$client = '' !== self::val( $in, 'client_id' ) ? self::val( $in, 'client_id' ) : (string) $code['client'];
		if ( $client !== $code['client'] || ! TWDB_OAuth_Clients::authenticates( $data['clients'], $client, self::val( $in, 'client_secret' ) ) ) {
			return array( 'invalid_client', 'This code was issued to a different app, or the app could not be authenticated.', 401 );
		}
		if ( (int) $code['expires'] < time() ) {
			return array( 'invalid_grant', 'The authorization code has expired. Start the connection again.', 400 );
		}
		$redirect = self::val( $in, 'redirect_uri' );
		if ( '' !== $redirect && $redirect !== $code['redirect_uri'] ) {
			return array( 'invalid_grant', 'redirect_uri differs from the one used to obtain the code.', 400 );
		}
		$verifier = self::val( $in, 'code_verifier' );
		if ( ! preg_match( '/^[A-Za-z0-9._~-]{43,128}$/', $verifier ) ) {
			return array( 'invalid_grant', 'A valid PKCE code_verifier is required.', 400 );
		}
		// S256: BASE64URL( SHA256( verifier ) ) without padding (RFC 7636 section 4.6).
		$computed = rtrim( strtr( base64_encode( hash( 'sha256', $verifier, true ) ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- PKCE S256.
		if ( ! hash_equals( (string) $code['challenge'], $computed ) ) {
			return array( 'invalid_grant', 'The PKCE code_verifier does not match.', 400 );
		}
		$approver = self::approver_ok( $code['approver'] );
		if ( ! $approver ) {
			return array( 'invalid_grant', 'The administrator who approved this is no longer allowed to grant it.', 400 );
		}

		$grant = array(
			'client'      => $client,
			'client_name' => (string) $code['client_name'],
			'approver'    => (int) $approver->ID,
			'resource'    => (string) $code['resource'],
			'issued'      => time(),
			'seen'        => 0,
		);
		$body  = self::issue( $grant );
		$data['grants'][ bin2hex( random_bytes( 8 ) ) ] = $grant;

		TWDB_Audit_Log::$via   = 'oauth';
		TWDB_Audit_Log::$actor = $approver->display_name . ' (approved the connection)';
		TWDB_Audit_Log::add( 'oauth.connect', array( 'client' => $grant['client_name'] ), true, sprintf( '%1$s connected (approved by %2$s)', $grant['client_name'], $approver->display_name ) );
		return $body;
	}

	/**
	 * refresh_token grant, with rotation and reuse detection.
	 *
	 * @param array $data Store (by reference).
	 * @param array $in   Request values.
	 * @return array Token body, or [error, description, status].
	 */
	private static function rotate( array &$data, array $in ) {
		$presented = self::val( $in, 'refresh_token' );
		if ( 0 !== strpos( $presented, TWDB_OAuth::PREFIX_REFRESH ) ) {
			return array( 'invalid_grant', 'The refresh token is unknown or has been revoked.', 400 );
		}
		$hash    = TWDB_OAuth_Repository::digest( $presented );
		$current = null;
		$retired = null;
		foreach ( $data['grants'] as $id => $g ) {
			if ( hash_equals( (string) $g['refresh']['hash'], $hash ) ) {
				$current = $id;
			} elseif ( isset( $g['previous_refresh']['hash'] ) && hash_equals( (string) $g['previous_refresh']['hash'], $hash ) ) {
				$retired = $id;
			}
		}

		if ( null === $current && null !== $retired ) {
			$g = $data['grants'][ $retired ];
			if ( time() - (int) $g['previous_refresh']['rotated_at'] > self::RETRY_WINDOW ) {
				unset( $data['grants'][ $retired ] );
				TWDB_Audit_Log::$via   = 'oauth';
				TWDB_Audit_Log::$actor = (string) $g['client_name'];
				TWDB_Audit_Log::add( 'oauth.refresh_reuse', array( 'client' => $g['client_name'] ), false, 'An already-used refresh token was presented again; the connection was ended as a precaution.' );
			}
			return array( 'invalid_grant', 'This refresh token has already been used.', 400 );
		}
		if ( null === $current ) {
			return array( 'invalid_grant', 'The refresh token is unknown or has been revoked.', 400 );
		}

		$grant = $data['grants'][ $current ];
		if ( (int) $grant['refresh']['expires'] < time() ) {
			unset( $data['grants'][ $current ] );
			return array( 'invalid_grant', 'The refresh token has expired. Connect again.', 400 );
		}
		$client = self::val( $in, 'client_id' );
		if ( '' !== $client && $client !== $grant['client'] ) {
			return array( 'invalid_client', 'This refresh token belongs to a different app.', 401 );
		}
		if ( ! TWDB_OAuth_Clients::authenticates( $data['clients'], (string) $grant['client'], self::val( $in, 'client_secret' ) ) ) {
			return array( 'invalid_client', 'The app could not be authenticated.', 401 );
		}
		if ( ! self::approver_ok( $grant['approver'] ) ) {
			unset( $data['grants'][ $current ] );
			return array( 'invalid_grant', 'The administrator who approved this is no longer allowed to grant it.', 400 );
		}

		$grant['previous_refresh']  = array(
			'hash'       => $grant['refresh']['hash'],
			'rotated_at' => time(),
		);
		$body                       = self::issue( $grant );
		$data['grants'][ $current ] = $grant;
		return $body;
	}

	/* -------------------- Revocation (RFC 7009) -------------------- */

	/**
	 * POST /oauth/revoke. Always answers 200, whether or not the token was known.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function revoke( WP_REST_Request $request ) {
		$in    = TWDB_OAuth::request_values( $request );
		$token = isset( $in['token'] ) && is_string( $in['token'] ) ? $in['token'] : '';
		if ( 0 === strpos( $token, TWDB_OAuth::PREFIX_ACCESS ) || 0 === strpos( $token, TWDB_OAuth::PREFIX_REFRESH ) ) {
			$hash = TWDB_OAuth_Repository::digest( $token );
			$done = TWDB_OAuth_Repository::transaction(
				static function ( array &$data ) use ( $hash ) {
					foreach ( $data['grants'] as $id => $g ) {
						if ( hash_equals( (string) $g['access']['hash'], $hash ) || hash_equals( (string) $g['refresh']['hash'], $hash ) ) {
							unset( $data['grants'][ $id ] );
						}
					}
					return true;
				}
			);
			if ( is_wp_error( $done ) ) {
				return TWDB_OAuth::busy();
			}
		}
		return TWDB_OAuth_Response::json( array( 'revoked' => true ) );
	}

	/* -------------------- Bearer check -------------------- */

	/**
	 * The live grant behind an access token, or null. Records when the grant was last used (at most once a
	 * minute, re-read under the lock so that it never overwrites a revocation).
	 *
	 * @param string $token Access token.
	 * @return array|null Grant with 'id' and 'approver_name'.
	 */
	public static function check( $token ) {
		$hash = TWDB_OAuth_Repository::digest( $token );
		foreach ( TWDB_OAuth_Repository::read( 'grants' ) as $id => $g ) {
			if ( ! isset( $g['access']['hash'] ) || ! hash_equals( (string) $g['access']['hash'], $hash ) ) {
				continue;
			}
			if ( (int) $g['access']['expires'] < time() ) {
				return null;
			}
			$approver = self::approver_ok( $g['approver'] );
			if ( ! $approver ) {
				return null;
			}
			if ( time() - (int) $g['seen'] > MINUTE_IN_SECONDS ) {
				TWDB_OAuth_Repository::transaction(
					static function ( array &$data ) use ( $id ) {
						if ( isset( $data['grants'][ $id ] ) ) {
							$data['grants'][ $id ]['seen'] = time();
						}
					}
				);
			}
			self::$active = $g + array(
				'id'            => $id,
				'approver_name' => $approver->display_name,
			);
			return self::$active;
		}
		return null;
	}

	/**
	 * The grant that authenticated this request.
	 *
	 * @return array|null
	 */
	public static function active() {
		return self::$active;
	}

	/* -------------------- Connected people -------------------- */

	/**
	 * Live connections for the admin screen, newest first.
	 *
	 * @return array[]
	 */
	public static function connections() {
		$list = array();
		foreach ( TWDB_OAuth_Repository::read( 'grants' ) as $id => $g ) {
			if ( (int) $g['refresh']['expires'] < time() ) {
				continue;
			}
			$who    = get_userdata( (int) $g['approver'] );
			$list[] = array(
				'id'        => (string) $id,
				'client'    => (string) $g['client_name'],
				'user'      => $who ? $who->display_name : 'user #' . (int) $g['approver'],
				'created'   => (int) $g['issued'],
				'last_used' => (int) $g['seen'],
			);
		}
		usort(
			$list,
			static function ( $a, $b ) {
				return $b['created'] <=> $a['created'];
			}
		);
		return $list;
	}

	/**
	 * End one connection. Returns the app name, or null when it did not exist.
	 *
	 * @param string $id Grant id.
	 * @return string|null
	 */
	public static function end_connection( $id ) {
		$name = TWDB_OAuth_Repository::transaction(
			static function ( array &$data ) use ( $id ) {
				if ( ! isset( $data['grants'][ $id ] ) ) {
					return null;
				}
				$n = (string) $data['grants'][ $id ]['client_name'];
				unset( $data['grants'][ $id ] );
				return $n;
			}
		);
		return is_wp_error( $name ) ? null : $name;
	}
}
