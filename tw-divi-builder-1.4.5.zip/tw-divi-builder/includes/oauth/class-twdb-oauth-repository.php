<?php
/**
 * Storage for the OAuth server: registered clients, pending authorization codes and grants.
 *
 * Three options (autoload off). Every change runs inside transaction(), which holds a lock, reads the
 * current values straight from the database, and writes back only what changed, so two requests can never
 * overwrite each other's work (a stale write could otherwise restore a revoked grant or let a code be
 * redeemed twice).
 *
 * Record shapes:
 *   client  id    => { name, redirect_uris[], secret_hash, registered, source: dcr|metadata, host? }
 *   code    hash  => { client, client_name, approver, redirect_uri, challenge, resource, expires }
 *   grant   id    => { client, client_name, approver, resource, issued, seen,
 *                      access: { hash, expires }, refresh: { hash, expires },
 *                      previous_refresh?: { hash, rotated_at } }
 *
 * Secrets (codes, tokens, client secrets) are stored only as SHA-256 hashes.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * OAuth storage.
 */
class TWDB_OAuth_Repository {

	const CLIENTS = 'twdb_oauth_clients';
	const CODES   = 'twdb_oauth_codes';
	const GRANTS  = 'twdb_oauth_grants';
	const LEGACY  = 'twdb_oauth';
	const LOCK    = 'oauth_store';

	/**
	 * Option name of each section.
	 *
	 * @return array<string,string>
	 */
	private static function sections() {
		return array(
			'clients' => self::CLIENTS,
			'codes'   => self::CODES,
			'grants'  => self::GRANTS,
		);
	}

	/**
	 * Hash a secret for storage or lookup.
	 *
	 * @param string $secret Secret.
	 * @return string
	 */
	public static function digest( $secret ) {
		return hash( 'sha256', (string) $secret );
	}

	/**
	 * Read one section without locking (for lookups that change nothing).
	 *
	 * @param string $section clients|codes|grants.
	 * @return array
	 */
	public static function read( $section ) {
		$all = self::sections();
		$v   = isset( $all[ $section ] ) ? get_option( $all[ $section ], array() ) : array();
		return is_array( $v ) ? $v : array();
	}

	/**
	 * Run $work with all sections loaded fresh under the lock. $work receives the data by reference and may
	 * change it; changed sections are saved (after dropping expired codes and dead grants) before the lock is
	 * released.
	 *
	 * @param callable $work function( array &$data ) returning any value.
	 * @return mixed|WP_Error The value $work returned, or twdb_busy when the lock could not be taken.
	 */
	public static function transaction( callable $work ) {
		if ( ! TWDB_Security::lock( self::LOCK ) ) {
			return new WP_Error( 'twdb_busy', 'The sign-in service is busy. Please retry in a moment.' );
		}
		try {
			$before = array();
			foreach ( self::sections() as $key => $option ) {
				$v              = TWDB_Security::fresh_option( $option, array() );
				$before[ $key ] = is_array( $v ) ? $v : array();
			}
			$data   = $before;
			$result = $work( $data );
			self::expire( $data );
			foreach ( self::sections() as $key => $option ) {
				if ( $data[ $key ] !== $before[ $key ] ) {
					update_option( $option, $data[ $key ], false );
				}
			}
			return $result;
		} finally {
			TWDB_Security::unlock( self::LOCK );
		}
	}

	/**
	 * Drop codes past their expiry and grants whose refresh token has expired.
	 *
	 * @param array $data Data (by reference).
	 */
	private static function expire( array &$data ) {
		$now = time();
		foreach ( $data['codes'] as $k => $c ) {
			if ( empty( $c['expires'] ) || (int) $c['expires'] < $now ) {
				unset( $data['codes'][ $k ] );
			}
		}
		foreach ( $data['grants'] as $k => $g ) {
			if ( empty( $g['refresh']['expires'] ) || (int) $g['refresh']['expires'] < $now ) {
				unset( $data['grants'][ $k ] );
			}
		}
	}

	/**
	 * One-time conversion of connections stored by plugin versions up to 1.4.1 (option "twdb_oauth"), so
	 * existing apps stay signed in. Pending codes are not carried over (they live five minutes).
	 */
	public static function upgrade() {
		$old = get_option( self::LEGACY, null );
		if ( ! is_array( $old ) ) {
			return;
		}
		$done = self::transaction(
			static function ( array &$data ) use ( $old ) {
				foreach ( ( isset( $old['clients'] ) && is_array( $old['clients'] ) ) ? $old['clients'] : array() as $id => $c ) {
					if ( isset( $data['clients'][ $id ] ) || empty( $c['redirect_uris'] ) ) {
						continue;
					}
					$data['clients'][ $id ] = array(
						'name'          => isset( $c['name'] ) ? (string) $c['name'] : 'MCP client',
						'redirect_uris' => array_values( (array) $c['redirect_uris'] ),
						'secret_hash'   => isset( $c['auth'], $c['secret_hash'] ) && 'client_secret_post' === $c['auth'] ? (string) $c['secret_hash'] : '',
						'registered'    => isset( $c['created'] ) ? (int) $c['created'] : time(),
						'source'        => 'dcr',
					);
				}
				foreach ( ( isset( $old['grants'] ) && is_array( $old['grants'] ) ) ? $old['grants'] : array() as $id => $g ) {
					if ( isset( $data['grants'][ $id ] ) || empty( $g['refresh_hash'] ) ) {
						continue;
					}
					$grant = array(
						'client'      => isset( $g['client_id'] ) ? (string) $g['client_id'] : '',
						'client_name' => isset( $g['client_name'] ) ? (string) $g['client_name'] : 'MCP client',
						'approver'    => isset( $g['user_id'] ) ? (int) $g['user_id'] : 0,
						'resource'    => isset( $g['resource'] ) ? (string) $g['resource'] : '',
						'issued'      => isset( $g['created'] ) ? (int) $g['created'] : time(),
						'seen'        => isset( $g['last_used'] ) ? (int) $g['last_used'] : 0,
						'access'      => array(
							'hash'    => isset( $g['access_hash'] ) ? (string) $g['access_hash'] : '',
							'expires' => isset( $g['access_exp'] ) ? (int) $g['access_exp'] : 0,
						),
						'refresh'     => array(
							'hash'    => (string) $g['refresh_hash'],
							'expires' => isset( $g['refresh_exp'] ) ? (int) $g['refresh_exp'] : 0,
						),
					);
					if ( ! empty( $g['prev_refresh_hash'] ) ) {
						$grant['previous_refresh'] = array(
							'hash'       => (string) $g['prev_refresh_hash'],
							'rotated_at' => isset( $g['rotated'] ) ? (int) $g['rotated'] : 0,
						);
					}
					$data['grants'][ (string) $id ] = $grant;
				}
				return true;
			}
		);
		if ( true === $done ) {
			delete_option( self::LEGACY );
		}
	}
}
