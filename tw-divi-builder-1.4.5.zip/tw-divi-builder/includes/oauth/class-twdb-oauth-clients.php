<?php
/**
 * OAuth clients: who may ask for a sign-in, and where the answer may be sent.
 *
 * A client is known in one of two ways:
 *  1. Dynamic client registration (RFC 7591): the app POSTs its name and return addresses to /oauth/register
 *     and receives a client_id (and a secret if it asks for client_secret_post).
 *  2. Client ID metadata document: the client_id is itself an https URL whose JSON describes the app. It is
 *     fetched only while an administrator is on the consent screen, through TWDB_Security::safe_get()
 *     (https only, no redirects, no private or reserved addresses, size-capped), and cached briefly.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * OAuth clients.
 */
class TWDB_OAuth_Clients {

	const ID_PREFIX       = 'twcc_';
	const SECRET_PREFIX   = 'twcs_';
	const LIMIT           = 200;
	const MAX_REDIRECTS   = 10;
	const DOC_MAX_BYTES   = 16384;
	const DOC_TIMEOUT     = 8;
	const DOC_CACHE_MIN   = 300;
	const DOC_CACHE_MAX   = 86400;
	const DOC_CACHE_BASIC = 3600;

	/**
	 * May a code be sent to this address? https, or plain http to the local machine for command-line apps
	 * (RFC 8252 section 7.3). No fragment, no user name or password.
	 *
	 * @param string $uri Address.
	 * @return bool
	 */
	public static function acceptable_redirect( $uri ) {
		$u = wp_parse_url( (string) $uri );
		if ( ! is_array( $u ) || empty( $u['scheme'] ) || empty( $u['host'] ) ) {
			return false;
		}
		if ( isset( $u['fragment'] ) || isset( $u['user'] ) || isset( $u['pass'] ) ) {
			return false;
		}
		$scheme = strtolower( $u['scheme'] );
		if ( 'https' === $scheme ) {
			return true;
		}
		return 'http' === $scheme && in_array( strtolower( $u['host'] ), array( 'localhost', '127.0.0.1', '[::1]' ), true );
	}

	/**
	 * Keep only acceptable return addresses from client input.
	 *
	 * @param mixed $uris String or list.
	 * @return string[]
	 */
	private static function clean_redirects( $uris ) {
		$out = array();
		foreach ( (array) $uris as $uri ) {
			if ( is_string( $uri ) && strlen( $uri ) <= 2048 && self::acceptable_redirect( $uri ) ) {
				$out[] = $uri;
			}
		}
		return array_slice( array_values( array_unique( $out ) ), 0, self::MAX_REDIRECTS );
	}

	/**
	 * A display name from client input.
	 *
	 * @param mixed  $name     Raw name.
	 * @param string $fallback Fallback.
	 * @return string
	 */
	private static function clean_name( $name, $fallback ) {
		$name = TWDB_Text::substr( trim( sanitize_text_field( is_scalar( $name ) ? (string) $name : '' ) ), 0, 80 );
		return '' === $name ? $fallback : $name;
	}

	/* -------------------- Registration (RFC 7591) -------------------- */

	/**
	 * POST /oauth/register.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function register( WP_REST_Request $request ) {
		if ( ! TWDB_Security::rate_ok( 'oauth_register', 20, HOUR_IN_SECONDS ) ) {
			return TWDB_OAuth_Response::error( 'invalid_client_metadata', 'Too many registrations from this address. Try again later.', 429 );
		}
		$in        = TWDB_OAuth::request_values( $request );
		$redirects = self::clean_redirects( isset( $in['redirect_uris'] ) ? $in['redirect_uris'] : array() );
		if ( ! $redirects ) {
			return TWDB_OAuth_Response::error( 'invalid_redirect_uri', 'redirect_uris must contain at least one https address, or an http address on localhost for command-line apps.' );
		}
		$name         = self::clean_name( isset( $in['client_name'] ) ? $in['client_name'] : '', 'MCP client' );
		$confidential = isset( $in['token_endpoint_auth_method'] ) && 'client_secret_post' === $in['token_endpoint_auth_method'];
		$id           = self::ID_PREFIX . bin2hex( random_bytes( 12 ) );
		$secret       = $confidential ? self::SECRET_PREFIX . bin2hex( random_bytes( 24 ) ) : '';

		$saved = TWDB_OAuth_Repository::transaction(
			static function ( array &$data ) use ( $id, $name, $redirects, $secret ) {
				if ( count( $data['clients'] ) >= self::LIMIT && ! self::make_room( $data ) ) {
					return false;
				}
				$data['clients'][ $id ] = array(
					'name'          => $name,
					'redirect_uris' => $redirects,
					'secret_hash'   => '' === $secret ? '' : TWDB_OAuth_Repository::digest( $secret ),
					'registered'    => time(),
					'source'        => 'dcr',
				);
				return true;
			}
		);
		if ( is_wp_error( $saved ) ) {
			return TWDB_OAuth::busy();
		}
		if ( ! $saved ) {
			return TWDB_OAuth_Response::error( 'invalid_client_metadata', 'This site has reached its limit of registered apps. End an unused connection under Connected people first.', 429 );
		}

		$body = array(
			'client_id'                  => $id,
			'client_id_issued_at'        => time(),
			'client_name'                => $name,
			'redirect_uris'              => $redirects,
			'grant_types'                => array( 'authorization_code', 'refresh_token' ),
			'response_types'             => array( 'code' ),
			'token_endpoint_auth_method' => $confidential ? 'client_secret_post' : 'none',
			'scope'                      => TWDB_OAuth::SCOPE,
		);
		if ( $confidential ) {
			$body['client_secret']            = $secret;
			$body['client_secret_expires_at'] = 0;
		}
		return TWDB_OAuth_Response::json( $body, 201 );
	}

	/**
	 * Remove the oldest registration that has no live grant. Returns false if every client is in use.
	 *
	 * @param array $data Store (by reference).
	 * @return bool
	 */
	private static function make_room( array &$data ) {
		$in_use = array();
		foreach ( $data['grants'] as $g ) {
			$in_use[ (string) $g['client'] ] = true;
		}
		$oldest = null;
		foreach ( $data['clients'] as $id => $c ) {
			if ( isset( $in_use[ $id ] ) ) {
				continue;
			}
			if ( null === $oldest || (int) $c['registered'] < (int) $data['clients'][ $oldest ]['registered'] ) {
				$oldest = $id;
			}
		}
		if ( null === $oldest ) {
			return false;
		}
		unset( $data['clients'][ $oldest ] );
		return true;
	}

	/* -------------------- Client ID metadata documents -------------------- */

	/**
	 * Is this client_id shaped like a metadata-document URL? https, a host, a path other than "/", no
	 * fragment, credentials or dot segments, at most 512 characters.
	 *
	 * @param string $id Client id.
	 * @return bool
	 */
	public static function is_document_url( $id ) {
		$id = (string) $id;
		if ( strlen( $id ) > 512 || 0 !== strpos( $id, 'https://' ) ) {
			return false;
		}
		$u = wp_parse_url( $id );
		if ( ! is_array( $u ) || empty( $u['host'] ) || empty( $u['path'] ) || '/' === $u['path'] || isset( $u['fragment'] ) || isset( $u['user'] ) || isset( $u['pass'] ) ) {
			return false;
		}
		return ! preg_match( '#(^|/)\.{1,2}(/|$)#', $u['path'] );
	}

	/**
	 * Read and validate the metadata document a client_id points to. Errors are worded for the consent
	 * screen, where they are shown to the administrator.
	 *
	 * @param string $id Client id (URL).
	 * @return array|WP_Error Client record.
	 */
	public static function from_document( $id ) {
		if ( ! self::is_document_url( $id ) ) {
			return new WP_Error( 'invalid_client', 'The app identified itself with an address that is not a valid https metadata document.' );
		}
		$cache_key = 'twdb_cimd_' . md5( $id );
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) && ! empty( $cached['redirect_uris'] ) ) {
			return $cached;
		}
		$host = (string) wp_parse_url( $id, PHP_URL_HOST );
		if ( ! TWDB_Security::rate_ok( 'oauth_cimd', 30, HOUR_IN_SECONDS ) ) {
			return new WP_Error( 'invalid_client', 'Too many app lookups from this address. Try again later.' );
		}
		$response = TWDB_Security::safe_get(
			$id,
			array(
				'timeout'             => self::DOC_TIMEOUT,
				'limit_response_size' => self::DOC_MAX_BYTES,
				'headers'             => array( 'Accept' => 'application/json' ),
				'user-agent'          => 'TechWebersMCPBuilder/' . TWDB_VERSION,
			),
			0,
			true
		);
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'invalid_client', sprintf( 'Could not read the app description at %1$s: %2$s', $host, $response->get_error_message() ) );
		}
		$status = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status ) {
			return new WP_Error( 'invalid_client', sprintf( 'The app description at %1$s answered HTTP %2$d (redirects are not followed).', $host, $status ) );
		}
		$doc = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $doc ) ) {
			return new WP_Error( 'invalid_client', sprintf( 'The app description at %s is not JSON.', $host ) );
		}
		if ( ! isset( $doc['client_id'] ) || $id !== $doc['client_id'] ) {
			return new WP_Error( 'invalid_client', sprintf( 'The app description at %s names a different client_id than its own address.', $host ) );
		}
		if ( isset( $doc['client_secret'] ) || isset( $doc['client_secret_expires_at'] ) ) {
			return new WP_Error( 'invalid_client', sprintf( 'The app description at %s contains a client secret, which a public document must not.', $host ) );
		}
		$methods = isset( $doc['token_endpoint_auth_methods_supported'] ) && is_array( $doc['token_endpoint_auth_methods_supported'] )
			? array_map( 'strval', $doc['token_endpoint_auth_methods_supported'] )
			: array( isset( $doc['token_endpoint_auth_method'] ) ? (string) $doc['token_endpoint_auth_method'] : 'none' );
		if ( ! in_array( 'none', $methods, true ) ) {
			return new WP_Error( 'invalid_client', sprintf( 'The app at %s does not support public-client sign-in ("none"), the only method this site accepts for such apps.', $host ) );
		}
		$redirects = self::clean_redirects( isset( $doc['redirect_uris'] ) ? $doc['redirect_uris'] : array() );
		if ( ! $redirects ) {
			return new WP_Error( 'invalid_client', sprintf( 'The app description at %s lists no acceptable return address.', $host ) );
		}
		$client       = array(
			'name'          => self::clean_name( isset( $doc['client_name'] ) ? $doc['client_name'] : '', $host ),
			'redirect_uris' => $redirects,
			'secret_hash'   => '',
			'registered'    => time(),
			'source'        => 'metadata',
			'host'          => $host,
		);
		$ttl          = self::DOC_CACHE_BASIC;
		$cache_header = (string) wp_remote_retrieve_header( $response, 'cache-control' );
		if ( preg_match( '/max-age=(\d+)/i', $cache_header, $m ) ) {
			$ttl = (int) $m[1];
		}
		if ( false !== stripos( $cache_header, 'no-store' ) ) {
			$ttl = self::DOC_CACHE_MIN;
		}
		set_transient( $cache_key, $client, min( self::DOC_CACHE_MAX, max( self::DOC_CACHE_MIN, $ttl ) ) );
		return $client;
	}

	/* -------------------- Lookup and authentication -------------------- */

	/**
	 * The client record for an id: a registration, else (for a URL id) its metadata document.
	 *
	 * @param string $id Client id.
	 * @return array|WP_Error|null Null when unknown.
	 */
	public static function find( $id ) {
		$id         = (string) $id;
		$registered = TWDB_OAuth_Repository::read( 'clients' );
		if ( isset( $registered[ $id ] ) ) {
			return $registered[ $id ];
		}
		return self::is_document_url( $id ) ? self::from_document( $id ) : null;
	}

	/**
	 * Does the request authenticate as this client? Public clients (no secret) always do: for them the
	 * authorization code / refresh token, bound to the client id, is the proof. Confidential clients must send
	 * their secret (client_secret_post).
	 *
	 * @param array  $clients Registered clients.
	 * @param string $id      Client id.
	 * @param string $secret  Presented secret.
	 * @return bool
	 */
	public static function authenticates( array $clients, $id, $secret ) {
		if ( ! isset( $clients[ $id ] ) ) {
			return self::is_document_url( $id );
		}
		$hash = (string) $clients[ $id ]['secret_hash'];
		if ( '' === $hash ) {
			return true;
		}
		return '' !== (string) $secret && hash_equals( $hash, TWDB_OAuth_Repository::digest( $secret ) );
	}
}
