<?php
/**
 * The authorization step (RFC 6749 section 4.1, with PKCE per RFC 7636): an administrator signs in to
 * WordPress and approves or refuses an app.
 *
 * It runs on admin-post.php rather than as a REST route because it relies on the normal WordPress login
 * cookie (REST treats cookie requests without a REST nonce as logged out).
 *
 * Order of checks:
 *   1. Who is signed in: only an administrator who may delegate to the "AI acts as user" account continues.
 *      Nothing about the client is looked up before this, so other users cannot make the site fetch URLs.
 *   2. Which app, and whether redirect_uri exactly matches one it registered. Failures are shown on screen:
 *      an unverified address must never receive a redirect.
 *   3. The request itself (response_type, PKCE S256). Failures are sent back to the verified address.
 *   4. GET shows the Allow / Deny page; POST (with a WordPress nonce) issues a single-use code.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Authorization / consent.
 */
class TWDB_OAuth_Consent {

	const NONCE    = 'twdb_oauth_consent';
	const CODE_TTL = 300;

	/**
	 * Request parameters the authorization step reads.
	 *
	 * @var string[]
	 */
	private static $fields = array( 'response_type', 'client_id', 'redirect_uri', 'state', 'scope', 'code_challenge', 'code_challenge_method', 'resource' );

	/**
	 * The authorization parameters of this request (GET, or POST from the consent form). Control characters
	 * are removed; nothing else is changed, because state and redirect_uri must come back byte for byte.
	 *
	 * @param bool $from_post Read the POST body.
	 * @return array<string,string>
	 */
	private static function params( $from_post ) {
		// phpcs:disable WordPress.Security.NonceVerification -- The GET request has no nonce by definition (it comes from the app); the POST is verified in handle() before anything is issued.
		$src = $from_post ? $_POST : $_GET;
		$out = array();
		foreach ( self::$fields as $f ) {
			$v         = isset( $src[ $f ] ) && is_scalar( $src[ $f ] ) ? wp_unslash( (string) $src[ $f ] ) : '';
			$out[ $f ] = (string) preg_replace( '/[\x00-\x1F\x7F]/', '', $v );
		}
		// phpcs:enable
		return $out;
	}

	/**
	 * The authorization address carrying these parameters.
	 *
	 * @param array $p Parameters.
	 * @return string
	 */
	private static function self_url( array $p ) {
		return add_query_arg( array_map( 'rawurlencode', array_filter( $p, 'strlen' ) ), TWDB_OAuth_Discovery::endpoints()['authorization'] );
	}

	/**
	 * Not signed in: go to the WordPress login and come back to the same request.
	 */
	public static function handle_logged_out() {
		wp_safe_redirect( wp_login_url( self::self_url( self::params( false ) ) ) );
		exit;
	}

	/**
	 * Signed in: validate, then show the decision page (GET) or act on the decision (POST).
	 */
	public static function handle() {
		$is_post = isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === strtoupper( sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) );
		$p       = self::params( $is_post );

		if ( ! TWDB_OAuth::enabled() ) {
			self::stop( __( 'Sign in with WordPress is turned off', 'tw-divi-builder' ), __( 'An administrator can turn it on under Settings > TW Divi Builder > Access settings.', 'tw-divi-builder' ) );
		}

		// 1. Who is signed in.
		$me = wp_get_current_user();
		if ( ! current_user_can( 'manage_options' ) ) {
			self::stop(
				__( 'An administrator must approve this', 'tw-divi-builder' ),
				/* translators: %s: user display name */ sprintf( __( 'You are signed in as %s. Only a site administrator can connect an AI app to this site.', 'tw-divi-builder' ), $me->display_name ),
				self::self_url( $p )
			);
		}
		$acting = TWDB_Settings::acting_user_id();
		if ( ! $acting ) {
			self::stop( __( 'Choose who the AI acts as first', 'tw-divi-builder' ), __( 'Pick a user under Settings > TW Divi Builder > Access settings > "AI acts as user", then connect again.', 'tw-divi-builder' ) );
		}
		if ( ! TWDB_Settings::may_delegate( $me->ID, $acting ) ) {
			self::stop( __( 'You cannot approve this connection', 'tw-divi-builder' ), __( 'The AI is set to act as a network Super Admin, which your account is not. Ask a Super Admin, or choose a different "AI acts as user".', 'tw-divi-builder' ) );
		}

		// 2. Which app, and is the return address one it registered?
		$client = TWDB_OAuth_Clients::find( $p['client_id'] );
		if ( is_wp_error( $client ) ) {
			self::stop( __( 'This app could not be identified', 'tw-divi-builder' ), $client->get_error_message() );
		}
		if ( ! is_array( $client ) ) {
			self::stop( __( 'This app is not registered here', 'tw-divi-builder' ), __( 'Start the connection again from the app; it registers itself automatically.', 'tw-divi-builder' ) );
		}
		if ( '' === $p['redirect_uri'] || ! in_array( $p['redirect_uri'], (array) $client['redirect_uris'], true ) ) {
			self::stop( __( 'The return address does not match', 'tw-divi-builder' ), __( 'The app asked to send the result to an address it did not register, so nothing was sent.', 'tw-divi-builder' ) );
		}

		// 3. The request itself. From here on, errors go back to the verified return address.
		if ( 'code' !== $p['response_type'] ) {
			self::send_back(
				$p,
				array(
					'error'             => 'unsupported_response_type',
					'error_description' => 'Only response_type=code is supported.',
				)
			);
		}
		if ( 'S256' !== $p['code_challenge_method'] || ! preg_match( '/^[A-Za-z0-9._~-]{43,128}$/', $p['code_challenge'] ) ) {
			self::send_back(
				$p,
				array(
					'error'             => 'invalid_request',
					'error_description' => 'PKCE is required, with code_challenge_method=S256.',
				)
			);
		}

		if ( ! $is_post ) {
			self::decision_page( $client, $p, $me, $acting );
		}

		// 4. The decision.
		check_admin_referer( self::NONCE );
		$decision = isset( $_POST['decision'] ) ? sanitize_key( wp_unslash( $_POST['decision'] ) ) : '';
		if ( 'allow' !== $decision ) {
			self::send_back(
				$p,
				array(
					'error'             => 'access_denied',
					'error_description' => 'The administrator declined the connection.',
				)
			);
		}
		$code   = bin2hex( random_bytes( 32 ) );
		$stored = TWDB_OAuth_Repository::transaction(
			static function ( array &$data ) use ( $code, $client, $p, $me ) {
				$data['codes'][ TWDB_OAuth_Repository::digest( $code ) ] = array(
					'client'       => $p['client_id'],
					'client_name'  => (string) $client['name'],
					'approver'     => (int) $me->ID,
					'redirect_uri' => $p['redirect_uri'],
					'challenge'    => $p['code_challenge'],
					'resource'     => $p['resource'],
					'expires'      => time() + self::CODE_TTL,
				);
				return true;
			}
		);
		if ( true !== $stored ) {
			self::stop( __( 'The server is busy', 'tw-divi-builder' ), __( 'Please go back and press Allow again.', 'tw-divi-builder' ) );
		}
		self::send_back( $p, array( 'code' => $code ) );
	}

	/**
	 * Redirect to the client's verified return address with the given values (plus state).
	 *
	 * @param array $p      Parameters.
	 * @param array $values Values to add.
	 */
	private static function send_back( array $p, array $values ) {
		if ( '' !== $p['state'] ) {
			$values['state'] = $p['state'];
		}
		// The return address was compared exactly with one the client registered (RFC 6749 section 3.1.2),
		// so wp_safe_redirect(), which only allows this site's host, does not apply.
		wp_redirect( add_query_arg( array_map( 'rawurlencode', $values ), $p['redirect_uri'] ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect
		exit;
	}

	/* -------------------- Pages -------------------- */

	/**
	 * The Allow / Deny page.
	 *
	 * @param array   $client Client.
	 * @param array   $p      Parameters.
	 * @param WP_User $me     Signed-in administrator.
	 * @param int     $acting Acting user id.
	 */
	private static function decision_page( array $client, array $p, WP_User $me, $acting ) {
		$as        = get_userdata( $acting );
		$return    = strtolower( (string) wp_parse_url( $p['redirect_uri'], PHP_URL_HOST ) );
		$on_device = in_array( $return, array( 'localhost', '127.0.0.1', '[::1]' ), true );
		$read_only = ! empty( TWDB_Settings::value( 'read_only' ) );
		$site      = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

		$rows = array(
			__( 'Sends the result to', 'tw-divi-builder' ) => $on_device ? /* translators: %s: host name */ sprintf( __( 'an app on this computer (%s)', 'tw-divi-builder' ), $return ) : $return,
			__( 'Will act as', 'tw-divi-builder' )         => $as ? $as->display_name . ' (' . implode( ', ', $as->roles ) . ')' : '-',
			__( 'Access', 'tw-divi-builder' )              => $read_only ? __( 'Read only (the site is in read-only mode)', 'tw-divi-builder' ) : __( 'Read and change the site, within that user\'s permissions', 'tw-divi-builder' ),
			__( 'Approved by', 'tw-divi-builder' )         => $me->user_login,
		);
		if ( 'metadata' === ( isset( $client['source'] ) ? $client['source'] : '' ) ) {
			$rows = array( __( 'Published by', 'tw-divi-builder' ) => (string) $client['host'] ) + $rows;
		}
		$facts = '';
		foreach ( $rows as $label => $value ) {
			$facts .= '<dt>' . esc_html( $label ) . '</dt><dd>' . esc_html( $value ) . '</dd>';
		}
		$hidden = '<input type="hidden" name="action" value="' . esc_attr( TWDB_OAuth::ACTION_AUTHORIZE ) . '">';
		foreach ( $p as $k => $v ) {
			if ( '' !== $v ) {
				$hidden .= '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '">';
			}
		}

		$html = '<main class="box">'
			. '<p class="eyebrow">' . esc_html( $site ) . '</p>'
			. '<h1>' . sprintf( /* translators: %s: app name */ esc_html__( 'Connect %s?', 'tw-divi-builder' ), '<strong>' . esc_html( (string) $client['name'] ) . '</strong>' ) . '</h1>'
			. '<p>' . esc_html__( 'This AI app will be able to use the site builder tools. You can end the connection at any time under Settings > TW Divi Builder > Connected people.', 'tw-divi-builder' ) . '</p>'
			. '<dl>' . $facts . '</dl>'
			. ( $on_device ? '<p class="warn">' . esc_html__( 'Allow only if you started this connection yourself from an app running on this computer.', 'tw-divi-builder' ) . '</p>' : '' )
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
			. $hidden
			. wp_nonce_field( self::NONCE, '_wpnonce', true, false )
			. '<div class="actions"><button type="submit" name="decision" value="deny" class="secondary">' . esc_html__( 'Deny', 'tw-divi-builder' ) . '</button>'
			. '<button type="submit" name="decision" value="allow" class="primary">' . esc_html__( 'Allow', 'tw-divi-builder' ) . '</button></div>'
			. '</form>'
			. '<p class="small"><a href="' . esc_url( wp_logout_url( self::self_url( $p ) ) ) . '">' . esc_html__( 'Use a different account', 'tw-divi-builder' ) . '</a></p>'
			. '</main>';
		self::output( sprintf( /* translators: %s: app name */ __( 'Connect %s', 'tw-divi-builder' ), $client['name'] ), $html, 200 );
	}

	/**
	 * Show a message and stop.
	 *
	 * @param string $title       Heading.
	 * @param string $message     Explanation.
	 * @param string $switch_back Offer "sign in with another account" returning here ('' = no).
	 */
	private static function stop( $title, $message, $switch_back = '' ) {
		$html = '<main class="box"><h1>' . esc_html( $title ) . '</h1><p>' . esc_html( $message ) . '</p>';
		if ( '' !== $switch_back ) {
			$html .= '<p class="small"><a href="' . esc_url( wp_logout_url( $switch_back ) ) . '">' . esc_html__( 'Sign in with another account', 'tw-divi-builder' ) . '</a></p>';
		}
		$html .= '</main>';
		self::output( $title, $html, 400 );
	}

	/**
	 * Print a standalone page (no theme, no admin chrome) and stop.
	 *
	 * @param string $title  Title.
	 * @param string $html   Body, already escaped by the callers.
	 * @param int    $status HTTP status.
	 */
	private static function output( $title, $html, $status ) {
		status_header( $status );
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Frame-Options: DENY' );
		header( "Content-Security-Policy: frame-ancestors 'none'" );
		header( 'Referrer-Policy: no-referrer' );
		$css = ':root{color-scheme:light}*{box-sizing:border-box}'
			. 'body{margin:0;min-height:100vh;display:grid;place-items:center;padding:20px;background:#eef1f5;color:#1e2530;font:15px/1.6 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}'
			. '.box{width:100%;max-width:440px;background:#fff;border-radius:14px;padding:28px;border-top:4px solid #3858e9;box-shadow:0 10px 35px rgba(20,30,50,.10)}'
			. '.eyebrow{margin:0 0 4px;font-size:13px;text-transform:uppercase;letter-spacing:.04em;color:#6b7380}'
			. 'h1{margin:0 0 12px;font-size:22px;line-height:1.3;font-weight:600}h1 strong{font-weight:700}'
			. 'dl{display:grid;grid-template-columns:auto 1fr;gap:6px 14px;margin:18px 0;padding:14px;background:#f6f7f9;border-radius:10px;font-size:14px}'
			. 'dt{color:#6b7380}dd{margin:0;word-break:break-word}'
			. '.warn{padding:10px 12px;background:#fff6e5;border-radius:8px;font-size:14px}'
			. '.actions{display:flex;justify-content:flex-end;gap:10px;margin-top:18px}'
			. 'button{font:inherit;font-weight:600;padding:9px 20px;border-radius:8px;cursor:pointer;border:1px solid #c4c9d1;background:#fff;color:#1e2530}'
			. 'button.primary{background:#3858e9;border-color:#3858e9;color:#fff}button.primary:hover{background:#2145e6}'
			. '.small{margin:16px 0 0;font-size:13px}.small a{color:#3858e9}';
		wp_register_style( 'twdb-consent', false, array(), TWDB_VERSION );
		wp_add_inline_style( 'twdb-consent', $css );
		ob_start();
		wp_print_styles( 'twdb-consent' );
		$styles = (string) ob_get_clean();

		$page = '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">'
			. '<title>' . esc_html( $title . ' - Tech Webers MCP Builder for Divi 5' ) . '</title>'
			. $styles . '</head><body>' . $html . '</body></html>';
		echo $page; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from esc_html / esc_attr / esc_url parts, wp_nonce_field() and wp_print_styles().

		exit;
	}
}
