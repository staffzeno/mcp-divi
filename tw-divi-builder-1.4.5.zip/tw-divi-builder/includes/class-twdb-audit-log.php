<?php
/**
 * Activity log of the last 300 changes and connection events: who (key, OAuth app, user), which tool, which page.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Activity log.
 */
class TWDB_Audit_Log {

	const OPTION = 'twdb_audit_log';
	const MAX    = 300;

	/**
	 * Current auth channel, set by the auth layer.
	 *
	 * @var string
	 */
	public static $via = 'admin';

	/**
	 * Human label of who is acting (key name, OAuth app and approver). Set by the auth layer; empty means "the user".
	 *
	 * @var string
	 */
	public static $actor = '';

	/**
	 * Add an entry.
	 *
	 * @param string $tool    Tool name.
	 * @param array  $args    Arguments (summarised).
	 * @param bool   $ok      Success.
	 * @param string $summary Summary.
	 */
	public static function add( $tool, $args, $ok, $summary = '' ) {
		$log = get_option( self::OPTION, array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}
		$log[] = array(
			'time'    => time(),
			'user'    => get_current_user_id(),
			'via'     => self::$via,
			'actor'   => TWDB_Text::substr( sanitize_text_field( self::$actor ), 0, 120 ),
			'ip'      => self::ip(),
			'tool'    => sanitize_text_field( $tool ),
			'target'  => self::target( $args ),
			'ok'      => (bool) $ok,
			'summary' => TWDB_Text::substr( sanitize_text_field( (string) $summary ), 0, 300 ),
			'args'    => self::summarise_args( $args ),
		);
		if ( count( $log ) > self::MAX ) {
			$log = array_slice( $log, -self::MAX );
		}
		update_option( self::OPTION, $log, false );
	}

	/**
	 * All entries, oldest first.
	 *
	 * @return array
	 */
	public static function all() {
		$log = get_option( self::OPTION, array() );
		return is_array( $log ) ? $log : array();
	}

	/**
	 * Clear.
	 */
	public static function clear() {
		update_option( self::OPTION, array(), false );
	}

	/**
	 * What the call was about, in a few words: a title, slug, name or id found in the arguments.
	 *
	 * @param mixed $args Args.
	 * @return string
	 */
	private static function target( $args ) {
		if ( ! is_array( $args ) ) {
			return '';
		}
		foreach ( array( 'title', 'slug', 'name', 'id', 'page_id', 'post_id', 'template_id', 'menu_id' ) as $k ) {
			if ( isset( $args[ $k ] ) && is_scalar( $args[ $k ] ) && '' !== (string) $args[ $k ] ) {
				$v = (string) $args[ $k ];
				return TWDB_Text::substr( sanitize_text_field( is_numeric( $v ) ? '#' . $v : $v ), 0, 80 );
			}
		}
		return '';
	}

	/**
	 * Compact, redacted JSON of args. Long strings (markup, CSS) are shortened.
	 *
	 * @param mixed $args Args.
	 * @return string
	 */
	private static function summarise_args( $args ) {
		$walk = static function ( $v ) use ( &$walk ) {
			if ( is_array( $v ) ) {
				$out = array();
				$i   = 0;
				foreach ( $v as $k => $item ) {
					if ( ++$i > 20 ) {
						$out['...'] = ( count( $v ) - 20 ) . ' more';
						break;
					}
					$out[ $k ] = $walk( $item );
				}
				return $out;
			}
			if ( is_string( $v ) && strlen( $v ) > 80 ) {
				return TWDB_Text::substr( $v, 0, 60 ) . '... (' . strlen( $v ) . ' chars)';
			}
			return $v;
		};
		$json = wp_json_encode( $walk( $args ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		return TWDB_Text::substr( (string) $json, 0, 600 );
	}

	/**
	 * Client IP (best effort, for display only).
	 *
	 * @return string
	 */
	private static function ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
	}
}
