<?php
/**
 * Front-end output: plugin-stored custom CSS and signed draft previews.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Frontend.
 */
class TWDB_Frontend {

	const PREVIEW_TTL = 3600;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'print_css' ), 999 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_helpers' ), 20 );
		add_filter( 'posts_results', array( __CLASS__, 'preview_posts_results' ), 10, 2 );
		add_action( 'send_headers', array( __CLASS__, 'preview_headers' ) );
		add_filter( 'redirect_canonical', array( __CLASS__, 'preview_no_canonical' ), 1 );
	}

	/**
	 * Is this request carrying a valid (unexpired, correctly signed) preview link?
	 *
	 * @return bool
	 */
	public static function is_signed_request() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Signed HMAC link, not a form.
		return ! empty( $_GET['twdb_preview'] ) && self::is_valid_preview( absint( $_GET['twdb_preview'] ) );
	}

	/**
	 * Never canonical-redirect a signed preview. A draft flipped to "publish" in memory
	 * has no slug yet, so WordPress would otherwise redirect it to the homepage.
	 *
	 * @param string|false $redirect Redirect URL.
	 * @return string|false
	 */
	public static function preview_no_canonical( $redirect ) {
		return self::is_signed_request() ? false : $redirect;
	}

	/**
	 * Small helper CSS/JS used by the AI skill: button hover guard, equal-height cards, custom tabs.
	 * Switch off under Settings > Access settings.
	 */
	public static function enqueue_helpers() {
		$settings = TWDB_Settings::get();
		if ( isset( $settings['helpers'] ) && ! $settings['helpers'] ) {
			return;
		}
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return; // Not inside the Visual Builder.
		}
		wp_enqueue_style( 'twdb-helpers', TWDB_URL . 'assets/twdb-helpers.css', array(), TWDB_VERSION );
		wp_enqueue_script( 'twdb-tabs', TWDB_URL . 'assets/twdb-tabs.js', array(), TWDB_VERSION, true );
	}

	/**
	 * Print plugin CSS (site-wide) and, when Divi is not active, per-page CSS.
	 */
	public static function print_css() {
		$css = (string) get_option( 'twdb_custom_css', '' );
		if ( '' !== trim( $css ) ) {
			echo "<style id=\"twdb-custom-css\">\n" . self::safe_css( $css ) . "\n</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS sanitised by safe_css().
		}
		if ( is_singular() && ! TWDB_Divi::available() ) {
			$page_css = (string) get_post_meta( get_queried_object_id(), '_et_pb_custom_css', true );
			if ( '' !== trim( $page_css ) ) {
				echo "<style id=\"twdb-page-css\">\n" . self::safe_css( $page_css ) . "\n</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS sanitised by safe_css().
			}
		}
	}

	/**
	 * Make CSS safe to print inside a style element.
	 *
	 * @param string $css CSS.
	 * @return string
	 */
	public static function safe_css( $css ) {
		$css = wp_strip_all_tags( (string) $css );
		// Repeat until stable so that nested fragments cannot reassemble a closing tag.
		do {
			$before = $css;
			$css    = str_ireplace( array( '</style', '<style', '<script', '</script' ), '', $css );
		} while ( $before !== $css );
		return $css;
	}

	/* -------------------- Signed previews -------------------- */

	/**
	 * Signature for a preview link.
	 *
	 * @param int $post_id Post.
	 * @param int $expires Expiry timestamp.
	 * @return string
	 */
	private static function sign( $post_id, $expires ) {
		return hash_hmac( 'sha256', $post_id . '|' . $expires, wp_salt( 'nonce' ) . 'twdb_preview' );
	}

	/**
	 * Build a time-limited preview URL that works without logging in.
	 *
	 * @param int $post_id Post.
	 * @return string
	 */
	public static function preview_url( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return '';
		}
		$expires = time() + self::PREVIEW_TTL;
		if ( 'page' === $post->post_type ) {
			$base = add_query_arg( 'page_id', $post_id, home_url( '/' ) );
		} elseif ( 'post' === $post->post_type ) {
			$base = add_query_arg( 'p', $post_id, home_url( '/' ) );
		} else {
			$base = add_query_arg(
				array(
					'p'         => $post_id,
					'post_type' => $post->post_type,
				),
				home_url( '/' )
			);
		}
		return add_query_arg(
			array(
				'twdb_preview' => $post_id,
				'twdb_exp'     => $expires,
				'twdb_sig'     => self::sign( $post_id, $expires ),
			),
			$base
		);
	}

	/**
	 * Valid preview request for this post?
	 *
	 * @param int $post_id Post.
	 * @return bool
	 */
	private static function is_valid_preview( $post_id ) {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Signed HMAC link, not a form.
		if ( empty( $_GET['twdb_preview'] ) || empty( $_GET['twdb_exp'] ) || empty( $_GET['twdb_sig'] ) ) {
			return false;
		}
		$id  = absint( $_GET['twdb_preview'] );
		$exp = absint( $_GET['twdb_exp'] );
		$sig = sanitize_text_field( wp_unslash( $_GET['twdb_sig'] ) );
		// phpcs:enable
		if ( $id !== (int) $post_id || $exp < time() ) {
			return false;
		}
		return hash_equals( self::sign( $id, $exp ), $sig );
	}

	/**
	 * Expose a draft to a signed preview request (in memory only).
	 *
	 * @param WP_Post[] $posts Posts.
	 * @param WP_Query  $query Query.
	 * @return WP_Post[]
	 */
	public static function preview_posts_results( $posts, $query ) {
		if ( is_admin() || ! $query->is_main_query() || 1 !== count( $posts ) ) {
			return $posts;
		}
		$p = $posts[0];
		if ( in_array( $p->post_status, array( 'draft', 'pending', 'future', 'private' ), true ) && self::is_valid_preview( $p->ID ) ) {
			$p->post_status = 'publish';
			$posts[0]       = $p;
			add_filter( 'wp_robots', 'wp_robots_no_robots' );
		}
		return $posts;
	}

	/**
	 * No caching for preview requests.
	 */
	public static function preview_headers() {
		if ( empty( $_GET['twdb_preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- Shared constant read by WP Super Cache, W3TC, WP Rocket and others.
		}
		do_action( 'litespeed_control_set_nocache', 'twdb preview' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- LiteSpeed Cache API.
		nocache_headers();
		header( 'Cache-Control: no-cache, must-revalidate, max-age=0, no-store, private' );
		header( 'X-Robots-Tag: noindex, nofollow' );
	}
}
