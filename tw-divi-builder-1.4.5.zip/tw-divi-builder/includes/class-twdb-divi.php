<?php
/**
 * Divi detection and Divi 5 storage helpers.
 *
 * Storage locations follow the bundled reference docs (DIVI5-PRESETS, DIVI5-STYLING,
 * DIVI5-MODULES-DYNAMIC) and observed Divi 5 option layouts:
 *  - Global colors:    et_get_option( 'et_global_data' )['global_colors']
 *  - Global variables: option 'et_divi_global_variables' grouped by type
 *  - Presets:          option 'et_divi_builder_global_presets_d5'
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Divi helpers.
 */
class TWDB_Divi {

	/**
	 * Variable types Divi 5 keeps in the variables registry.
	 *
	 * @var string[]
	 */
	public static $variable_types = array( 'numbers', 'strings', 'images', 'links', 'fonts', 'gradients' );

	/**
	 * Detection result.
	 *
	 * @return array
	 */
	public static function status() {
		static $cached = null;
		if ( null !== $cached && did_action( 'after_setup_theme' ) ) {
			return $cached;
		}
		$theme    = wp_get_theme();
		$template = strtolower( (string) $theme->get_template() );
		$product  = '';
		$version  = '';

		if ( in_array( $template, array( 'divi', 'extra' ), true ) ) {
			$product = 'divi' === $template ? 'Divi theme' : 'Extra theme';
			$parent  = $theme->parent() ? $theme->parent() : $theme;
			$version = (string) $parent->get( 'Version' );
		} elseif ( defined( 'ET_BUILDER_PLUGIN_VERSION' ) ) {
			$product = 'Divi Builder plugin';
			$version = (string) ET_BUILDER_PLUGIN_VERSION;
		}
		if ( defined( 'ET_BUILDER_VERSION' ) && '' === $version ) {
			$version = (string) ET_BUILDER_VERSION;
		}

		$active   = '' !== $product && ( function_exists( 'et_get_option' ) || defined( 'ET_BUILDER_VERSION' ) || defined( 'ET_CORE_VERSION' ) );
		$is_divi5 = $active && ( defined( 'ET_BUILDER_5_DIR' ) || class_exists( '\ET\Builder\Packages\GlobalData\GlobalData' ) || ( '' !== $version && version_compare( $version, '5.0.0-alpha', '>=' ) ) );

		$result = array(
			'active'   => $active,
			'is_divi5' => $is_divi5,
			'product'  => $product,
			'version'  => $version,
			'theme'    => $theme->get( 'Name' ),
		);
		if ( did_action( 'after_setup_theme' ) ) {
			$cached = $result; // Divi's constants are only final once the theme has loaded.
		}
		return $result;
	}

	/**
	 * Is Divi 5 usable?
	 *
	 * @return bool
	 */
	public static function available() {
		$s = self::status();
		return $s['active'];
	}

	/**
	 * Throw a clean tool error if Divi is not active.
	 *
	 * @throws TWDB_Tool_Error When Divi is missing.
	 */
	public static function require_divi() {
		$s = self::status();
		if ( ! $s['active'] ) {
			throw new TWDB_Tool_Error( 'divi_not_active', 'Divi is not active on this site. Activate the Divi 5 theme (or the Divi Builder plugin) to use this tool.' );
		}
		if ( ! $s['is_divi5'] ) {
			throw new TWDB_Tool_Error( 'divi4_detected', sprintf( 'This site runs %s %s, not Divi 5. These tools write Divi 5 data structures; update to Divi 5 first.', $s['product'], $s['version'] ) );
		}
		if ( ! function_exists( 'et_get_option' ) || ! function_exists( 'et_update_option' ) ) {
			throw new TWDB_Tool_Error( 'divi_api_missing', 'Divi is active but its option API (et_get_option / et_update_option) is not loaded. This tool cannot run here.' );
		}
	}

	/**
	 * Builder version to stamp on generated markup.
	 *
	 * @return string
	 */
	public static function builder_version() {
		$s = self::status();
		if ( $s['is_divi5'] && $s['version'] ) {
			return $s['version'];
		}
		return '5.11.1';
	}

	/**
	 * Divi product "shortname" used to prefix product options (divi, extra, divi_builder_plugin).
	 *
	 * @return string
	 */
	public static function shortname() {
		global $shortname;
		if ( is_string( $shortname ) && '' !== $shortname ) {
			return $shortname;
		}
		return 'divi';
	}

	/* ---------------- Divi GlobalData bridge ----------------
	 * Divi 5 exposes GlobalData::get/set_global_colors() and get/set_global_variables().
	 * Verified on a live Divi 5.17 site: writing the raw option rows directly is NOT picked
	 * up by the builder, while GlobalData::set_global_* is. Divi may return stdClass trees,
	 * so everything read from it is normalised to plain arrays.
	 */

	const GLOBAL_DATA_CLASS = '\ET\Builder\Packages\GlobalData\GlobalData';

	/**
	 * Is a GlobalData static method available?
	 *
	 * @param string $method Method.
	 * @return bool
	 */
	private static function gd_has( $method ) {
		return class_exists( self::GLOBAL_DATA_CLASS ) && method_exists( self::GLOBAL_DATA_CLASS, $method );
	}

	/**
	 * Normalise a value (possibly nested stdClass) to arrays.
	 *
	 * @param mixed $v Value.
	 * @return array
	 */
	public static function to_array( $v ) {
		$j = json_decode( wp_json_encode( $v ), true );
		return is_array( $j ) ? $j : array();
	}

	/**
	 * Every global color Divi knows (customizer + user), id => data.
	 *
	 * @return array
	 */
	private static function all_global_colors() {
		if ( self::gd_has( 'get_global_colors' ) ) {
			return self::to_array( call_user_func( array( self::GLOBAL_DATA_CLASS, 'get_global_colors' ) ) );
		}
		$data = function_exists( 'et_get_option' ) ? et_get_option( 'et_global_data' ) : array();
		if ( is_string( $data ) ) {
			$decoded = json_decode( $data, true );
			// Never instantiate objects from stored data (PHP object injection).
			$data = is_array( $decoded ) ? $decoded : ( is_serialized( $data ) ? @unserialize( trim( $data ), array( 'allowed_classes' => false ) ) : $data ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize, WordPress.PHP.NoSilencedErrors.Discouraged -- allowed_classes=false; corrupt data falls through to the empty default.
		}
		return ( is_array( $data ) && isset( $data['global_colors'] ) && is_array( $data['global_colors'] ) ) ? $data['global_colors'] : array();
	}

	/**
	 * Read user global colors (id => data), excluding the built-in customizer colors.
	 *
	 * @return array
	 */
	public static function get_global_colors() {
		$out = array();
		foreach ( self::all_global_colors() as $id => $c ) {
			if ( is_array( $c ) && ( ! isset( $c['folder'] ) || 'customizer' !== $c['folder'] ) ) {
				$out[ $id ] = $c;
			}
		}
		return $out;
	}

	/**
	 * Save user global colors. Customizer colors are preserved untouched.
	 *
	 * @param array $colors id => data (user colors only).
	 * @throws TWDB_Tool_Error If Divi did not keep the data.
	 */
	public static function save_global_colors( $colors ) {
		if ( self::gd_has( 'set_global_colors' ) ) {
			$merged = array();
			foreach ( self::all_global_colors() as $id => $c ) {
				if ( is_array( $c ) && isset( $c['folder'] ) && 'customizer' === $c['folder'] ) {
					$merged[ $id ] = $c;
				}
			}
			foreach ( $colors as $id => $c ) {
				$merged[ $id ] = $c;
			}
			call_user_func( array( self::GLOBAL_DATA_CLASS, 'set_global_colors' ), $merged );
			$after = self::all_global_colors();
			foreach ( array_keys( $colors ) as $id ) {
				if ( ! isset( $after[ $id ] ) ) {
					throw new TWDB_Tool_Error( 'storage_failed', sprintf( 'Divi did not keep global color %s after saving. Check the result in the Visual Builder.', $id ) );
				}
			}
			return;
		}
		$data = et_get_option( 'et_global_data' );
		if ( ! is_array( $data ) ) {
			$data = array();
		}
		$data['global_colors'] = $colors;
		et_update_option( 'et_global_data', $data );
	}

	/**
	 * Customizer (built-in) colors exposed by Divi 5 as gcid-primary-color etc.
	 *
	 * @return array
	 */
	public static function get_customizer_colors() {
		$out = array();
		if ( self::gd_has( 'get_global_colors' ) ) {
			foreach ( self::all_global_colors() as $id => $c ) {
				if ( is_array( $c ) && isset( $c['folder'] ) && 'customizer' === $c['folder'] ) {
					$out[ $id ] = array(
						'color'  => isset( $c['color'] ) ? (string) $c['color'] : '',
						'label'  => isset( $c['label'] ) ? (string) $c['label'] : $id,
						'source' => 'customizer',
					);
				}
			}
		}
		$cls = self::GLOBAL_DATA_CLASS;
		if ( ! $out && class_exists( $cls ) && property_exists( $cls, 'customizer_colors' ) ) {
			$src = $cls::$customizer_colors;
			if ( is_array( $src ) ) {
				foreach ( $src as $id => $meta ) {
					if ( ! is_array( $meta ) ) {
						continue;
					}
					$opt        = isset( $meta['option_name'] ) ? (string) $meta['option_name'] : '';
					$default    = isset( $meta['default'] ) ? (string) $meta['default'] : '';
					$out[ $id ] = array(
						'color'  => '' !== $opt && function_exists( 'et_get_option' ) ? (string) et_get_option( $opt, $default ) : $default,
						'label'  => isset( $meta['label'] ) ? (string) $meta['label'] : $id,
						'source' => 'customizer',
					);
				}
			}
		}
		if ( ! $out ) {
			// Fallback when Divi's GlobalData class is unavailable: the four built-in IDs.
			$known = array(
				'gcid-primary-color'   => array( 'accent_color', '#2ea3f2', 'Primary Color' ),
				'gcid-secondary-color' => array( 'secondary_accent_color', '#2ea3f2', 'Secondary Color' ),
				'gcid-heading-color'   => array( 'header_color', '#666666', 'Heading Text Color' ),
				'gcid-body-color'      => array( 'font_color', '#666666', 'Body Text Color' ),
			);
			foreach ( $known as $id => $k ) {
				$out[ $id ] = array(
					'color'  => function_exists( 'et_get_option' ) ? (string) et_get_option( $k[0], $k[1] ) : $k[1],
					'label'  => $k[2],
					'source' => 'customizer',
				);
			}
		}
		return $out;
	}

	/* ---------------- Global variables ---------------- */

	/**
	 * Variables registry option name.
	 *
	 * @return string
	 */
	public static function variables_option() {
		return 'et_' . self::shortname() . '_global_variables';
	}

	/**
	 * Read variables registry (type => id => data).
	 *
	 * @return array
	 */
	public static function get_global_variables() {
		if ( self::gd_has( 'get_global_variables' ) ) {
			return self::to_array( call_user_func( array( self::GLOBAL_DATA_CLASS, 'get_global_variables' ) ) );
		}
		$vars = get_option( self::variables_option(), array() );
		return is_array( $vars ) ? $vars : array();
	}

	/**
	 * Save variables registry.
	 *
	 * @param array $vars Registry (type => id => data).
	 * @throws TWDB_Tool_Error If Divi did not keep the data.
	 */
	public static function save_global_variables( $vars ) {
		if ( self::gd_has( 'set_global_variables' ) ) {
			$cls = self::GLOBAL_DATA_CLASS;
			try {
				call_user_func( array( $cls, 'set_global_variables' ), $vars );
			} catch ( ArgumentCountError $e ) {
				// Some Divi builds require the second argument ($expected_variables).
				call_user_func( array( $cls, 'set_global_variables' ), $vars, $vars );
			}
			$after = self::get_global_variables();
			foreach ( $vars as $type => $items ) {
				foreach ( (array) $items as $id => $unused ) {
					if ( ! isset( $after[ $type ][ $id ] ) ) {
						throw new TWDB_Tool_Error( 'storage_failed', sprintf( 'Divi did not keep global variable %s after saving. Check the result in the Visual Builder.', $id ) );
					}
				}
			}
			return;
		}
		update_option( self::variables_option(), $vars );
	}

	/* ---------------- Presets ---------------- */

	/**
	 * Presets option name.
	 *
	 * @return string
	 */
	public static function presets_option() {
		return 'et_' . self::shortname() . '_builder_global_presets_d5';
	}

	/**
	 * Read presets.
	 *
	 * @return array
	 */
	public static function get_presets() {
		$p = get_option( self::presets_option(), array() );
		if ( is_string( $p ) ) {
			$d = json_decode( $p, true );
			$p = is_array( $d ) ? $d : array();
		}
		if ( ! is_array( $p ) ) {
			$p = array();
		}
		if ( ! isset( $p['module'] ) || ! is_array( $p['module'] ) ) {
			$p['module'] = array();
		}
		if ( ! isset( $p['group'] ) || ! is_array( $p['group'] ) ) {
			$p['group'] = array();
		}
		return $p;
	}

	/**
	 * Save presets.
	 *
	 * @param array $presets Presets.
	 */
	public static function save_presets( $presets ) {
		update_option( self::presets_option(), $presets, false );
	}

	/* ---------------- Cache ---------------- */

	/**
	 * Flush Divi static CSS + Theme Builder caches. Optionally one post.
	 *
	 * @param int $post_id Post ID or 0 for all.
	 * @return array What was cleared.
	 */
	public static function clear_cache( $post_id = 0 ) {
		$done = array();
		if ( $post_id ) {
			delete_post_meta( $post_id, '_divi_dynamic_assets_cached_modules' );
			delete_post_meta( $post_id, '_divi_dynamic_assets_cached_feature_used' );
			$done[] = 'post_dynamic_assets_meta';
		}
		if ( class_exists( 'ET_Core_PageResource' ) && method_exists( 'ET_Core_PageResource', 'remove_static_resources' ) ) {
			ET_Core_PageResource::remove_static_resources( $post_id ? $post_id : 'all', 'all' );
			$done[] = 'divi_static_css';
		}
		if ( function_exists( 'et_theme_builder_clear_wp_cache' ) ) {
			et_theme_builder_clear_wp_cache( 'all' );
			$done[] = 'divi_theme_builder_cache';
		}
		if ( function_exists( 'et_core_clear_wp_cache' ) ) {
			et_core_clear_wp_cache( $post_id ? $post_id : 'all' );
			$done[] = 'divi_wp_cache';
		}
		if ( $post_id ) {
			clean_post_cache( $post_id );
		}
		return $done;
	}

	/**
	 * Divi token string for a color id.
	 *
	 * @param string $id gcid.
	 * @return string
	 */
	public static function color_token( $id ) {
		return '$variable(' . wp_json_encode(
			array(
				'type'  => 'color',
				'value' => array(
					'name'     => $id,
					'settings' => new stdClass(),
				),
			)
		) . ')$';
	}

	/**
	 * Divi token string for a variable.
	 *
	 * @param string $id   gvid.
	 * @param string $type Registry type.
	 * @return string
	 */
	public static function variable_token( $id, $type ) {
		$t = 'gradients' === $type ? 'gradient' : 'content';
		return '$variable(' . wp_json_encode(
			array(
				'type'  => $t,
				'value' => array(
					'name'     => $id,
					'settings' => new stdClass(),
				),
			)
		) . ')$';
	}
}
