<?php
/**
 * Plugin Name:       Tech Webers MCP Builder for Divi 5
 * Plugin URI:        https://www.techwebers.com/
 * Description:       Lets AI clients build and edit Divi 5 websites through a secure MCP server: pages, design system, Theme Builder, menus and media.
 * Version:           1.4.5
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Deepak Juneja
 * Author URI:        https://www.techwebers.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tw-divi-builder
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TWDB_VERSION', '1.4.5' );
define( 'TWDB_FILE', __FILE__ );
define( 'TWDB_DIR', plugin_dir_path( __FILE__ ) );
define( 'TWDB_URL', plugin_dir_url( __FILE__ ) );
define( 'TWDB_REST_NS', 'tw-divi/v1' );

if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
	add_action(
		'admin_notices',
		static function () {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Tech Webers MCP Builder for Divi 5 requires PHP 7.4 or newer.', 'tw-divi-builder' ) . '</p></div>';
		}
	);
	return;
}

require_once TWDB_DIR . 'includes/class-twdb-plugin.php';

register_activation_hook( __FILE__, array( 'TWDB_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'TWDB_Plugin', 'deactivate' ) );

TWDB_Plugin::instance();
