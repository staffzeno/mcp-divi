/* Tech Webers MCP Builder for Divi 5 - settings screen: app / sign-in method pickers and copy buttons. */
(function () {
	'use strict';
	var root = document.getElementById( 'twdb-settings' );
	if ( ! root ) {
		return;
	}
	var ai = 'claude';
	var method = root.getAttribute( 'data-method' ) || 'oauth';
	try {
		if ( window.localStorage ) {
			ai = localStorage.getItem( 'twdb_ai' ) || ai;
			var m = localStorage.getItem( 'twdb_method' );
			if ( m ) {
				method = m;
			}
		}
	} catch ( e ) {}
	if ( '1' === root.getAttribute( 'data-force-key' ) ) {
		method = 'key';
	}
	function each( sel, fn ) {
		Array.prototype.forEach.call( document.querySelectorAll( sel ), fn );
	}
	function paint() {
		each( '#twdb-ai-picker .twdb-choice', function ( b ) { b.classList.toggle( 'is-on', b.getAttribute( 'data-ai' ) === ai ); } );
		each( '#twdb-method-picker .twdb-choice', function ( b ) { b.classList.toggle( 'is-on', b.getAttribute( 'data-method' ) === method ); } );
		each( '.twdb-guide', function ( g ) {
			g.style.display = g.getAttribute( 'data-ai' ) === ai ? '' : 'none';
			Array.prototype.forEach.call( g.querySelectorAll( '.twdb-steps' ), function ( o ) {
				o.style.display = o.getAttribute( 'data-method' ) === method ? '' : 'none';
			} );
		} );
		each( '[data-addr]', function ( a ) { a.style.display = a.getAttribute( 'data-addr' ) === method ? '' : 'none'; } );
	}
	each( '#twdb-ai-picker .twdb-choice', function ( b ) {
		b.addEventListener( 'click', function () {
			ai = b.getAttribute( 'data-ai' );
			try { localStorage.setItem( 'twdb_ai', ai ); } catch ( e ) {}
			paint();
		} );
	} );
	each( '#twdb-method-picker .twdb-choice', function ( b ) {
		b.addEventListener( 'click', function () {
			method = b.getAttribute( 'data-method' );
			try { localStorage.setItem( 'twdb_method', method ); } catch ( e ) {}
			paint();
		} );
	} );
	if ( document.getElementById( 'twdb-ai-picker' ) ) {
		paint();
	}
	var copied = root.getAttribute( 'data-copied' ) || 'Copied';
	each( '.twdb-copy', function ( btn ) {
		btn.addEventListener( 'click', function () {
			var el = document.getElementById( btn.getAttribute( 'data-target' ) );
			if ( ! el ) {
				return;
			}
			var text = el.textContent;
			var done = function () {
				var original = btn.textContent;
				btn.textContent = copied;
				setTimeout( function () { btn.textContent = original; }, 1500 );
			};
			if ( navigator.clipboard ) {
				navigator.clipboard.writeText( text ).then( done );
			} else {
				var ta = document.createElement( 'textarea' );
				ta.value = text;
				document.body.appendChild( ta );
				ta.select();
				document.execCommand( 'copy' );
				document.body.removeChild( ta );
				done();
			}
		} );
	} );
}() );
