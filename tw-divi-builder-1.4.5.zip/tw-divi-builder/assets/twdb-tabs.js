/*
 * Tech Webers MCP Builder for Divi 5 - custom tabs (buttons + rows).
 * Markup contract (classes only, set through each module's CSS class field):
 *   wrapper  : .twdb-tabs                      (a section or group that holds the buttons and the panels)
 *   buttons  : .twdb-tab-btn .twdb-tab-KEY     (e.g. a divi/button with link "#")
 *   panels   : .twdb-tab-panel .twdb-tab-KEY   (e.g. a divi/row)
 *   optional : .twdb-tab-default on the button that starts active (otherwise the first)
 * The script adds .twdb-js to the wrapper, .is-active to the active button and panel, and ARIA roles.
 * Deep link: #twdb-tab-KEY opens that tab. Without JS every panel is visible.
 */
(function () {
	'use strict';

	function keyOf(el) {
		var cl = el.classList;
		for (var i = 0; i < cl.length; i++) {
			var m = /^twdb-tab-(?!btn$|panel$|default$)(.+)$/.exec(cl[i]);
			if (m) { return m[1]; }
		}
		return null;
	}

	function init(root, n) {
		var btns = Array.prototype.slice.call(root.querySelectorAll('.twdb-tab-btn'));
		var panels = Array.prototype.slice.call(root.querySelectorAll('.twdb-tab-panel'));
		if (!btns.length || !panels.length) { return; }

		var byKey = {};
		panels.forEach(function (p, i) {
			var k = keyOf(p);
			if (k) {
				byKey[k] = p;
				if (!p.id) { p.id = 'twdb-panel-' + n + '-' + i; }
				p.setAttribute('role', 'tabpanel');
			}
		});
		btns = btns.filter(function (b) { return keyOf(b) && byKey[keyOf(b)]; });
		if (!btns.length) { return; }

		var list = btns[0].parentNode;
		if (list) { list.setAttribute('role', 'tablist'); }

		btns.forEach(function (b, i) {
			var k = keyOf(b);
			if (!b.id) { b.id = 'twdb-btn-' + n + '-' + i; }
			b.setAttribute('role', 'tab');
			b.setAttribute('aria-controls', byKey[k].id);
			byKey[k].setAttribute('aria-labelledby', b.id);
		});

		function activate(key, focus) {
			btns.forEach(function (b) {
				var on = keyOf(b) === key;
				b.classList.toggle('is-active', on);
				b.setAttribute('aria-selected', on ? 'true' : 'false');
				b.setAttribute('tabindex', on ? '0' : '-1');
				if (on && focus) { b.focus(); }
			});
			Object.keys(byKey).forEach(function (k) {
				byKey[k].classList.toggle('is-active', k === key);
				byKey[k].setAttribute('aria-hidden', k === key ? 'false' : 'true');
			});
		}

		var start = null;
		var hash = (window.location.hash || '').replace(/^#twdb-tab-/, '');
		if (hash && byKey[hash] && window.location.hash.indexOf('#twdb-tab-') === 0) { start = hash; }
		if (!start) {
			var def = root.querySelector('.twdb-tab-btn.twdb-tab-default');
			start = def && keyOf(def) && byKey[keyOf(def)] ? keyOf(def) : keyOf(btns[0]);
		}

		root.addEventListener('click', function (e) {
			var b = e.target.closest ? e.target.closest('.twdb-tab-btn') : null;
			if (!b || btns.indexOf(b) === -1) { return; }
			e.preventDefault();
			activate(keyOf(b), false);
		});

		root.addEventListener('keydown', function (e) {
			var b = e.target.closest ? e.target.closest('.twdb-tab-btn') : null;
			if (!b || btns.indexOf(b) === -1) { return; }
			var i = btns.indexOf(b), t = null;
			if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { t = btns[(i + 1) % btns.length]; }
			else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { t = btns[(i - 1 + btns.length) % btns.length]; }
			else if (e.key === 'Home') { t = btns[0]; }
			else if (e.key === 'End') { t = btns[btns.length - 1]; }
			else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); activate(keyOf(b), false); return; }
			if (t) { e.preventDefault(); activate(keyOf(t), true); }
		});

		root.classList.add('twdb-js');
		activate(start, false);
	}

	function boot() {
		Array.prototype.slice.call(document.querySelectorAll('.twdb-tabs')).forEach(init);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
