# Tech Webers MCP Builder for Divi 5

A WordPress plugin that turns a Divi 5 site into an **MCP server**. AI clients such as Claude, ChatGPT, Codex, Gemini CLI, Cursor and Grok Bot can then build and edit the site: pages, global colors and variables, presets, Theme Builder templates, library Components, CSS, menus, media and SEO.

- **Endpoint:** `POST /wp-json/tw-divi/v1/mcp` (MCP Streamable HTTP, JSON-RPC 2.0, plain JSON responses with no SSE)
- **Requirements:** WordPress 6.0+, PHP 7.4+. Divi 5 is needed for the Divi-specific tools; the plugin is safe to activate without it.
- **Author:** Deepak Juneja - [www.techwebers.com](https://www.techwebers.com/)
- **License:** GPL-2.0-or-later

## Install

1. Plugins > Add New > Upload Plugin > `tw-divi-builder.zip` > Activate.
2. Settings > TW Divi Builder > **Access settings**: pick the acting user, then optionally turn on read-only mode or turn tool groups off.
3. **Connection** tab: pick your AI and how it signs in, then follow the steps shown.
   - *Sign in with WordPress*: paste the address, press Connect, sign in as an administrator, press Allow.
   - *Connector key*: create a key and send it in the `Authorization: Bearer` header. A key inside the address is accepted only after you turn on "Keys inside the connector address" (off on new installations: such addresses can end up in server and proxy logs).

### Cursor / remote-HTTP clients

```json
{
  "mcpServers": {
    "tw-divi-builder": {
      "url": "https://your-site.com/wp-json/tw-divi/v1/mcp",
      "headers": { "Authorization": "Bearer YOUR_API_KEY" }
    }
  }
}
```

### Claude Desktop (stdio, via mcp-remote)

```json
{
  "mcpServers": {
    "tw-divi-builder": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "https://your-site.com/wp-json/tw-divi/v1/mcp",
               "--header", "Authorization:${TWDB_AUTH}"],
      "env": { "TWDB_AUTH": "Bearer YOUR_API_KEY" }
    }
  }
}
```

### Quick curl check

```bash
curl -s https://your-site.com/wp-json/tw-divi/v1/mcp \
  -H "Authorization: Bearer YOUR_API_KEY" -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

## Authentication

| Method | Header |
|---|---|
| Sign in with WordPress (OAuth 2.1 + PKCE) | The app does it: `Authorization: Bearer twoa_...` (1 hour, refreshed automatically) |
| Connector key in the address | `POST /wp-json/tw-divi/v1/mcp/twk_...` (opt-in, off on new installations; only for apps that support neither OAuth nor headers) |
| Connector key in a header | `Authorization: Bearer twk_...` or `X-TW-Divi-Key: twk_...` (keys from before 1.1.0 start with `twdb_` and still work) |
| WordPress Application Password | `Authorization: Basic base64(user:app-password)` (HTTPS; can be turned off) |

With a key or a sign-in, requests run as the **acting user** chosen in the settings. With an Application Password, they run as that user, who must be able to edit pages. Each tool also checks its own capability: `edit_theme_options` for design, Theme Builder and CSS, `manage_options` for reading settings, `upload_files` for media, and so on.

## Tools (34)

| Group | Tool | Writes | Notes |
|---|---|---|---|
| site | `site_info` | | Call first: versions, Divi status, builderVersion, acting-user caps |
| site | `get_divi_reference` | | Bundled Divi 5 docs: topics, search, paging |
| settings | `set_front_page`, `set_posts_page` | yes | |
| pages | `list_pages`, `list_posts`, `get_page`, `validate_markup` | | |
| pages | `create_page` | yes | Draft by default; markup validated; Divi meta set |
| pages | `update_page` | yes | replace / append / prepend / find-replace; restore point |
| pages | `trash_page` | yes | Restore point; refuses front/posts page unless `force` |
| pages | `list_backups`, `restore_backup` | yes | Restores are themselves undoable |
| pages | `render_page` | | **beta**: `content` or `full` (loopback) HTML |
| design | `get_design_system`, `list_presets` | | Divi |
| design | `set_global_colors`, `delete_global_color` | yes | **beta**, Divi |
| design | `set_global_variables` | yes | **beta**, Divi |
| design | `upsert_preset`, `delete_preset` | yes | **beta**, Divi |
| theme_builder | `list_templates` | | Divi |
| theme_builder | `create_or_update_template` | yes | **beta**, Divi |
| library | `list_library_layouts` | | Divi |
| library | `save_library_layout` | yes | **beta**, Divi; returns a `divi/global-layout` snippet |
| css | `get_custom_css`, `set_custom_css`, `set_page_custom_css` | yes | Plugin CSS, Customizer CSS or per-page |
| menus | `list_menus`, `create_or_update_menu` | yes | Nested items, locations |
| media | `upload_media_from_url` | yes | Public URLs only; de-duplicated |
| seo | `get_seo`, `set_seo` | yes | **beta**: Yoast SEO / Rank Math |
| cache | `clear_divi_cache` | yes | Divi + common page-cache plugins |

Tools that error return MCP results with `isError: true` and a JSON body `{"error":{"code","message","details"}}`. Codes include `invalid_arguments`, `invalid_markup`, `not_found`, `forbidden`, `tool_disabled`, `divi_not_active`, `divi4_detected` and `no_seo_plugin`.

**Plain REST mirror:** `GET /wp-json/tw-divi/v1/tools` and `POST /wp-json/tw-divi/v1/tools/{name}`. Both use the same auth and rules.

## Safety

- Keys are stored as HMAC-SHA256 hashes keyed with the site salts, and only the last four characters are kept for display. If the salts in wp-config.php change, create new keys. OAuth tokens are stored as SHA-256 hashes; access tokens last 1 hour, refresh tokens 30 days and rotate on use. A key inside the address can end up in logs, so that option is off on new installations; prefer OAuth or the Authorization header.
- A restore point (a private `twdb_backup` post) is saved before every overwrite of a page, library or Theme Builder layout, global colors, variables, presets or CSS. The last 25 are kept per item.
- History keeps the last 300 write calls and connection events, plus failed write attempts, with who acted (key name, or app and approving administrator) and which item was touched.
- Read-only mode hides and blocks every write tool. Whole tool groups can also be turned off.
- Markup is validated (placeholder wrapper, balanced blocks, JSON attributes, no `attrs` wrapper) before anything is saved.
- Media downloads and client-metadata fetches block private, loopback, link-local (cloud metadata), CGNAT and reserved addresses on every redirect hop, pin the connection to the checked address on both HTTP transports (refusing HTTPS without cURL and proxied fetches), cap the size, and accept only media and document file types.
- AI clients cannot add executable code: scripts, iframes, embeds, event handlers, javascript:/data: URLs and script-like CSS are removed on the server before saving; unchanged existing content is kept.
- Draft previews use signed links that expire after 1 hour and are sent with `noindex`.

## Credits

Developed by **Deepak Juneja**, Tech Webers - [www.techwebers.com](https://www.techwebers.com/).

Bundled third-party code and documents, and their licences, are listed in `THIRD-PARTY-NOTICES.txt`. Divi is a trademark of Elegant Themes; this plugin is not affiliated with Elegant Themes.
