<?php
/**
 * Uninstall: remove plugin options, transients, audit log, connections and backups (on every site of a network).
 *
 * Media imported through the plugin is kept (it may be used on pages); only the plugin's bookkeeping meta on it
 * is removed.
 *
 * @package TW_Divi_Builder
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Remove everything this plugin stored on the current site.
 */
function twdb_uninstall_site() {
	global $wpdb;

	$twdb_options = array( 'twdb_settings', 'twdb_version', 'twdb_api_key_hash', 'twdb_api_key_hint', 'twdb_audit_log', 'twdb_custom_css', 'twdb_keys', 'twdb_keys_used', 'twdb_oauth', 'twdb_oauth_clients', 'twdb_oauth_codes', 'twdb_oauth_grants' );
	foreach ( $twdb_options as $twdb_option ) {
		delete_option( $twdb_option );
	}

	// Transients (rate limits, failed-login counters, cached client metadata, one-time key display) and lock rows.
	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time cleanup of the plugin's own rows.
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( '_transient_twdb_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_twdb_' ) . '%',
			$wpdb->esc_like( 'twdb_lock_' ) . '%'
		)
	);
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s", '_twdb_source_url' ) );
	// phpcs:enable

	$twdb_backups = get_posts(
		array(
			'post_type'      => 'twdb_backup',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		)
	);
	foreach ( $twdb_backups as $twdb_backup_id ) {
		wp_delete_post( $twdb_backup_id, true );
	}
}

if ( is_multisite() ) {
	$twdb_sites = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);
	foreach ( $twdb_sites as $twdb_site_id ) {
		switch_to_blog( $twdb_site_id );
		twdb_uninstall_site();
		restore_current_blog();
	}
} else {
	twdb_uninstall_site();
}
