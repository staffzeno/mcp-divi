# Security

Tech Webers MCP Builder for Divi 5 lets AI clients change a WordPress site, so it is built to give them no
more power than the WordPress user they act as, and no ability to add executable code.

## Reporting a vulnerability

Please report security issues privately to Tech Webers through https://www.techwebers.com/ (contact form),
not in public forums. Include the plugin version, steps to reproduce and the impact. We aim to reply within
7 days.

## Security model (version 1.4.5)

- **Authentication:** Sign in with WordPress (OAuth 2.1, PKCE S256 only, administrator approval, rotating
  refresh tokens with reuse detection), connector keys (shown once, stored as HMAC-SHA256, revocable one by
  one), or WordPress Application Passwords. Keys inside the URL are off by default on new installations.
- **Authorization:** every tool checks the acting user's capabilities and object permissions (read, edit,
  delete, publish; `edit_theme_options` for site-wide design; `manage_options` for Reading settings). On
  multisite nobody can delegate a Super Admin they are not.
- **No executable code from AI clients:** scripts, iframes, objects/embeds, event handlers,
  `javascript:`/`vbscript:`/non-image `data:` URLs and script-like CSS are removed on the server before
  anything is saved. Content that already exists and is sent back unchanged is kept. The plugin never
  executes code sent by a client.
- **Outbound requests:** only on request (media import, OAuth client metadata). Private, loopback,
  link-local, cloud-metadata and reserved addresses are refused on every redirect; connections are pinned to
  the checked address on both HTTP transports, and fetches that cannot be pinned are refused.
- **Safety nets:** restore points before every overwrite, read-only mode, tool-group switches, an activity
  history, request size and batch limits, rate limits on authentication, registration and imports.
- **Data:** secrets are stored only as hashes; nothing is logged that could authenticate; uninstall removes
  all plugin data on every site of a network.

No software can be guaranteed free of vulnerabilities. Keep WordPress, Divi and this plugin up to date,
and give the AI the least-privileged acting user that does the job.
