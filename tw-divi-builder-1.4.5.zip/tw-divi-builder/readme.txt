=== Tech Webers MCP Builder for Divi 5 ===
Contributors: deepak-juneja
Tags: divi, divi 5, mcp, ai, page builder
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.4.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect AI clients to WordPress and build, edit, and manage Divi 5 websites through a secure MCP server.

== Description ==

Tech Webers MCP Builder for Divi 5 adds a secure MCP (Model Context Protocol) server to WordPress at `https://your-site.com/wp-json/tw-divi/v1/mcp`.

AI clients (Claude, ChatGPT, Codex, Gemini CLI, Cursor and other MCP clients) sign in with WordPress (OAuth) or a connector key and get 36 tools:

* **Site:** site_info, get_divi_reference, set_front_page, set_posts_page
* **Pages:** list_pages, list_posts, get_page, validate_markup, create_page, update_page, trash_page, render_page
* **Modules:** get_page_tree, edit_page_modules (edit, add, move, replace or delete one module)
* **Safety:** list_backups, restore_backup
* **Design system:** get_design_system, set_global_colors, delete_global_color, set_global_variables, list_presets, upsert_preset, delete_preset
* **Theme Builder:** list_templates, create_or_update_template
* **Library:** list_library_layouts, save_library_layout
* **CSS:** get_custom_css, set_custom_css, set_page_custom_css
* **Menus, media, SEO, cache:** list_menus, create_or_update_menu, upload_media_from_url, get_seo, set_seo (Yoast or Rank Math), clear_divi_cache

Safety:

* Sign in with WordPress (OAuth 2.1 with PKCE): an administrator approves each app; every connection can be ended on its own.
* Connector keys are shown once, stored only as a hash and can be revoked one by one.
* You choose the WordPress user the AI acts as; every tool checks that user's permissions.
* No executable code from AI clients: scripts, iframes, embeds, event handlers, javascript: URLs and script-like CSS are removed before saving (see FAQ).
* Read-only mode and switches for whole tool groups.
* A restore point before every overwrite; new pages are drafts.
* A History tab of changes and connections.
* Divi markup is validated before saving.
* Media imports only from public addresses and only media and document files.

Tools marked BETA write Divi data not yet checked on every Divi 5 release; check the result in the Visual Builder.

== Installation ==

1. Upload and activate the plugin (Plugins > Add New > Upload Plugin).
2. Go to Settings > TW Divi Builder > Access settings and choose the acting user: an administrator for full access, or an editor for content only.
3. On the Connection tab, pick your AI app and follow the steps shown.
   * **Sign in with WordPress (recommended):** paste the address into the app, press Connect, sign in as an administrator and press Allow.
   * **Connector key:** create a key and send it in the `Authorization: Bearer` header. Example for apps that read a config file:

    {
      "mcpServers": {
        "tw-divi-builder": {
          "url": "https://your-site.com/wp-json/tw-divi/v1/mcp",
          "headers": { "Authorization": "Bearer YOUR_KEY" }
        }
      }
    }

A key inside the address (`.../mcp/YOUR_KEY`) is only accepted if you turn on "Keys inside the connector address" under Access settings. It is off on new installations because such addresses can end up in server, CDN and proxy logs. WordPress Application Passwords (Basic auth over HTTPS) also work and can be turned off.

== Frequently Asked Questions ==

= Does it work without Divi? =
Yes. Page, CSS, menu, media, SEO, settings and cache tools work. Design system, preset, Theme Builder and library tools return "divi_not_active" until Divi 5 is active ("divi4_detected" on Divi 4).

= Can the AI add JavaScript, iframes or Code module scripts? =
No. On every save, the plugin removes scripts, iframes, objects and embeds, inline event handlers (onclick and similar, including Divi custom attributes), javascript:/vbscript: and non-image data: URLs, and script-like CSS such as expression(). The AI is told what was removed. It can still build layouts, write text, add images, use design settings, presets, variables, static SVG graphics and CSS. Content you made yourself, such as a Code module with a script, is kept as long as the AI sends it back unchanged, so the AI can still edit other parts of that page. The plugin never runs PHP sent by a client. For videos and maps the AI uses Divi's own Video and Map modules.

= Why are keys inside the address off by default? =
A key that is part of a URL can be written to web-server, CDN and proxy logs, browser history and config files. Use Sign in with WordPress or the Authorization header. Turn the option on only for an app that supports neither, and give that app its own key.

= The Authorization header is not reaching WordPress =
Some Apache/CGI hosts strip it. Use the `X-TW-Divi-Key: YOUR_KEY` header, or add `SetEnvIf Authorization "(.*)" HTTP_AUTHORIZATION=$1` to .htaccess.

= claude.ai cannot register with the sign-in service =
Open the addresses under "Sign-in not connecting?" on the Connection tab; each must show JSON. Some hosts answer every /.well-known/ address themselves, and a site in a subfolder needs those addresses served from that folder.

= Is there a plain REST API? =
Yes: `GET /wp-json/tw-divi/v1/tools` lists tools and `POST /wp-json/tw-divi/v1/tools/{tool_name}` runs one, with the same authentication and rules.

= Does the plugin contact external services? =
No telemetry and no requests on its own. Outbound requests happen only when an authenticated AI client or administrator asks:

* **Media import** (upload_media_from_url): downloads the file at the URL the AI supplies. Only public http(s) addresses; private, loopback, link-local and reserved networks are refused on every redirect, and the connection is pinned to the checked address.
* **Client ID metadata documents** (OAuth): while an administrator is on the approval screen, the plugin fetches the app's JSON description from its https URL (for example on claude.ai), with no redirects and at most 16 KB.
* **Render check** (render_page, mode "full"): a request to your own site.

Nothing from your site is sent beyond what an HTTP request carries (your server address and a user agent naming this plugin).

= What happens on uninstall? =
Settings, key hashes, connections, history, restore points and the plugin's own CSS are removed, on every site of a network. Pages, menus, media and Divi data stay.

== Credits ==

Developed by Deepak Juneja, Tech Webers - https://www.techwebers.com/

Third-party material and licences: THIRD-PARTY-NOTICES.txt. Divi is a trademark of Elegant Themes. This plugin is not affiliated with Elegant Themes.

== Changelog ==

= 1.4.5 =
* Fix: the plugin no longer calls mbstring functions. Names, labels and log entries are shortened by characters with a built-in UTF-8 helper, so multibyte text is never split, with or without mbstring.
* Fix: reference paging always finishes, even with very small page sizes.

= 1.4.4 =
* Fix: long reference documents and pages are cut on whole UTF-8 characters; paging never skips or repeats text, and an offset inside a character starts at the next one. No mbstring needed.
* Security: existing code is kept only where it already was; the AI cannot copy or duplicate it, and a final check refuses any save that would add executable code. Titles and excerpts are cleaned too.
* Fix: sites upgrading from 1.4.2 or earlier without saved settings (for example network sub-sites) keep keys inside the connector address working.

= 1.4.3 =
* Security / WordPress.org: AI clients can no longer add executable code. Scripts, iframes, embeds, event handlers, executable URLs and script-like CSS are removed on the server in every tool that saves content or design data; unchanged existing content is kept. The 1.4.2 "Allow the AI to add scripts and embeds" setting is removed.
* Security: keys inside the connector address are off by default on new installations (existing sites keep their setting), with a log-exposure warning.
* Security: downloads are pinned to the checked address on both HTTP transports; HTTPS without cURL, proxied downloads and unpinned responses are refused.
* WordPress.org: shorter description and readme; history moved to CHANGELOG.md.

Earlier versions: CHANGELOG.md.

== Upgrade Notice ==

= 1.4.5 =
Works the same with or without the PHP mbstring extension. No settings change.

= 1.4.4 =
UTF-8 safe paging, stricter protection against copied or duplicated code, and an upgrade fix for network sub-sites. Settings and keys are kept.

= 1.4.3 =
AI clients can no longer add scripts, iframes or other executable code; existing content is kept. New installations do not accept keys inside the connector address.
