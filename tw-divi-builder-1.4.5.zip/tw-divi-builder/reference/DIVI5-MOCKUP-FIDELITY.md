# Mockup Fidelity — build EXACTLY what the user supplied (Divi 5 native modules)

> **Read this INSTEAD of the discovery / plan / "design it as HTML first" route whenever the user
> supplies a design:** an **uploaded or pasted mockup image, HTML file or HTML/CSS**, a Figma link or export, or a PDF. Their design IS
> the specification. You are a translator, not a designer.
>
> Target: **99% visual match at every supplied breakpoint, built from Divi's native modules.**
> "99%" is something you MEASURE (≤ 1% pixel difference, §7), never something you claim.

This file is written by the plugin author, not part of the general reference docs. Where it disagrees with another
topic (DESIGN-PROCESS discovery / approval gate, PAGE-FROM-HTML "design it yourself", CONNECT
"match a reference… rebuild in the user's own tokens"), **this file wins while a design is supplied.**

---

## 1. The contract (what "strictly follow" means)

**Copy the design exactly and add NOTHING from your side.** No extra section, heading, line of copy, tagline,
badge, icon, image, divider, shadow, gradient, animation or hover effect. Nothing removed, reordered or
"improved". If something looks wrong, build it as shown and mention it in the report.

DO:
- Keep **every** section, in the same order, with the same copy (words, case, punctuation, line breaks).
- Keep **exact** values: font family, size, weight, line-height, letter-spacing, colour, spacing, radii,
  borders, shadows, widths, aspect ratios, image crops, alignment, z-order.
- Use **native Divi modules** for everything Divi can express (§4). Style each module itself.
- Measure, compare, fix, repeat (§7) before you say "done".

DO NOT:
- Redesign, "improve", re-balance, add sections, add or rewrite copy, swap fonts, change the palette,
  add cards/shadows/dividers/animations the design does not have, or remove ones it has.
- Snap a colour or size to the nearest global token. **An exact match may use the token; a near miss
  stays a literal value** (list near misses in the report and offer to add them as global colours).
- Dump the whole design into one `divi/code` module, or replace layout with CSS you wrote. `divi/code`
  is allowed only for what no native module can do (§4 last rows) and must be reported.
- Invent images. No stock photos. If an asset was not supplied, say so and use a neutral placeholder
  of the exact dimensions.
- Ask discovery questions about brand, audience, goals. The design already answers them.
- Wait for plan approval. Post the **Design Inventory** (§2) and carry on, **unless** a blocking gap
  needs the user (see §2 "Blockers").

**House rules in this mode** (`DIVI5-HOUSE-RULES.md`): the design's own values always win. The layout defaults
(section side padding 50/30/20px, rows 100% wide, 16px gaps) only fill what the design does not state — typically
tablet/phone padding, row width when no container is shown, and gaps when none are drawn. The "no look-alike
sections" rule and the equal-cards / mobile-menu recipes are for pages YOU design; they never change what a supplied
design shows (if the design has equal cards or a mobile menu, use the recipes to BUILD them).

House rules that still apply on top of the design (they are bugs, not style):
- Buttons never change letter-spacing on hover — write the same `letterSpacing` in resting and hover
  (BASE "Letter Spacing Must Not Change On Button Hover"). If the supplied HTML does otherwise, keep the
  house rule and list it under Deviations.
- Markup rules in BASE (no `attrs` wrapper, `builderVersion`, raw HTML, `phone` not `phoneWide`).

---

## 2. Step 1 — Extract a Design Inventory BEFORE any markup

Write it down (briefly) from the supplied design. This is the checklist you verify against at the end.

1. **Canvas:** supplied widths (e.g. 1440 / 768 / 390). Which breakpoints are actually designed?
2. **Tokens as measured:** every colour (hex), every font family + weights, the type scale
   (size / line-height / letter-spacing per role), spacing rhythm, radii, shadows, border styles.
3. **Sections in order:** for each — background (colour / gradient / image + overlay), padding top/bottom,
   container max-width, columns + ratios + gaps + vertical alignment, and the elements inside.
4. **Components:** buttons (padding, radius, border, fill, text style, hover), cards, badges, icons,
   forms, tabs, accordions, sliders, tables, counters, sticky/fixed bits, overlaps.
5. **Assets:** every image / icon / logo / video — file or URL supplied? dimensions? crop (`object-fit`)?
6. **States:** hover / active / focus described in the design; anything animated.

**How to read each kind of input**
- **HTML + CSS (best):** read the CSS literally. Resolve shorthands, `rem`/`em`/`%` to px at the design
  width, `clamp()`/`vw` at each target width, inherited values, `gap`, `max-width`, pseudo-elements
  (`::before/::after` are real design elements), media queries (they ARE the tablet/phone design).
  If a browser is available in your client, render the HTML and read **computed** styles
  (`getComputedStyle`, `getBoundingClientRect`) for every element — measure, do not guess.
- **Figma (link or Figma tools connected):** pull exact values from the design data (frame sizes, text
  styles, fills, auto-layout padding/gaps, corner radii, effects, variables). Prefer that to eyeballing.
- **Vector PDF / PNG at a stated canvas width:** exact type sizes are recoverable; state the canvas width
  you read it at. **Image with no known width:** ask the width once (blocker), otherwise measurements
  are approximate and you must say so.

**Blockers — the only reasons to stop and ask (batch them in ONE message):**
canvas width unknown for an image mockup · an asset you cannot get (images, logo, icon set, custom font
file) · two parts of the design contradict each other · the design shows only desktop and the user has
not said how it should collapse (offer: stack columns at tablet and phone, scale type ~0.8× / 0.65×).
Everything else: decide, state the assumption in the report, continue.

---

## 3. Step 2 — Read the site, then bind values

1. `site_info`, then `get_design_system` (colours, fonts, size variables, presets).
2. **Colours:** exact hex match → use the global colour token; otherwise the literal hex.
3. **Fonts:** state `family` on EVERY text-bearing module (PAGE-FROM-HTML: unstated = site/preset font).
   If the design's font is not available on the site (not in Divi's Google list, no uploaded file), say so
   and ask for the font file, or use the named family anyway and flag it as unverified.
4. **Presets are the enemy of fidelity.** A module with no explicit value inherits the site's global
   preset / Customizer. **State every value the design shows** — family, size, weight, line-height,
   letter-spacing, colour, margin, padding, radius, border, shadow — on every module, even when it
   "matches the default". Check `list_presets`; where a preset would leak in a value the design does not
   have, override it explicitly.
5. **Divi supplies its own default spacing** (section and row padding, row width, gutters, module bottom
   margins, paragraph margins, line-height). A design that looks tight or loose "by itself" is almost
   always one of these defaults. State section padding, row width / max-width, column gap, and each
   module's margin explicitly (use `0` where the design has none), then confirm in §7.

---

## 4. Step 3 — Pick the native module for each design element

| Design element | Native build |
|---|---|
| Full-width band, background colour / gradient / image + overlay | `divi/section` background (image + gradient overlay layers), explicit padding |
| Container with max-width | `divi/row` width / max-width stated explicitly |
| 2–6 column layout | `divi/row` + `divi/column` in 24ths (CSS gap is subtracted by Divi — state `gap`, and check widths in §7) |
| CSS grid / many equal cards | rows of columns, or `divi/group` / Grid layout (LAYOUT topic); one row per visual row |
| Card (bg, border, radius, shadow, padding) | **one column or group styled as the card**, not a module inside a module |
| Heading / paragraph / eyebrow / list / quote | `divi/heading`, `divi/text` (HTML in `content`), styled per element |
| Button (filled / ghost / icon) | `divi/button` — padding, radius, border, font, hover state (+ the letter-spacing rule) |
| Image with crop / radius / aspect ratio | `divi/image` with explicit width, height / aspect-ratio and object-fit |
| Icon + title + text | `divi/blurb` (or icon + heading + text in a group when the layout differs) |
| Feature list with icons | `divi/icon-list` |
| Stats / numbers | `divi/number-counter` (note: JS-driven) or heading modules if static |
| Testimonial / team / pricing / tabs / accordion / toggle / slider | their native modules (MODULES-* topics) restyled to the design |
| Form | `divi/contact-form` + fields (INTERACTIVE) |
| Divider line / spacer | `divi/divider` (set its colour explicitly) / section or module spacing |
| Pill / badge / tag | `divi/text` or `divi/heading` with background, padding, radius |
| Overlap / offset / negative margin / z-index | module `position` / `transform` / margin settings (STYLING §7d); keep the layer order |
| Sticky header, global footer | Theme Builder (`create_or_update_template`), not the page body |
| Menu / search / login | `divi/menu`, `divi/search`, `divi/login` |
| Background video, map, embed | `divi/video` / `divi/map` / `divi/code` only for the embed itself |
| Decorative SVG / shapes | `divi/svg` or `divi/image` (uploaded SVG); CSS-drawn shapes → section / column background or border |
| **Not expressible natively** (custom canvas, scripted animation, unusual blend) | `divi/code` for that ONE piece only, and list it under Deviations |

Typography detail: line-height unitless or in `em` exactly as designed; `letterSpacing` in the unit given;
`text-transform` only via `capitalization` (BASE/STYLING).

---

## 5. Step 4 — Assets

- `upload_media_from_url` for every image/logo the user supplied as a URL. Use the returned media in
  `divi/image` / backgrounds. Keep intrinsic aspect ratio and the designed crop.
- Local files or relative paths in supplied HTML cannot be fetched by the server: ask for URLs (blocker),
  or use a clearly labelled placeholder of the exact size and list it as outstanding.
- Icons: if the design uses a specific icon set, match it (Divi icon picker, `divi/svg`, or uploaded SVG).
  Never substitute a "similar" icon silently.

---

## 6. Step 5 — Build as a DRAFT, in sections

`create_page` with `status: "draft"` (unless told otherwise) — all sections, every value stated. Read
`warnings` in the response and fix every one (including the letter-spacing hover warning).
For very long pages, build the first third, run the §7 check on it, then continue.

---

## 7. Step 6 — Verify, measure, fix, repeat (this is what makes it 99%)

"Built" means **rendered and compared**, never "create_page returned OK".

1. `render_page` `{id, mode: "full"}` returns the real front end and a signed `preview_url` (valid ~1 hour).
2. **If your client has a browser** (Playwright / Chromium / built-in browser): open the design reference
   and the Divi preview at the SAME widths as the design (e.g. 1440, 768, 390), full page, then:
   - **Pixel diff** per breakpoint (e.g. Pillow `ImageChops.difference`, or `pixelmatch`). Target ≤ 1%
     different pixels. Note the worst regions (rows of the page where the diff concentrates).
   - **Element measurement:** for each design element and its Divi counterpart compare
     `getBoundingClientRect()` (x, y, width, height) and `getComputedStyle()` (font-family, size, weight,
     line-height, letter-spacing, colour, margin, padding, border, radius, box-shadow, background).
     Tolerance: **≤ 2px** on positions and sizes, **exact** on fonts, colours, weights.
   - **Fix** each mismatch with `get_page_tree` + `edit_page_modules` (small, targeted ops; a restore point
     is saved before every change). Re-render and re-measure. Repeat up to ~5 rounds or until the target.
3. **No browser available:** say so. Compare what you can from the returned HTML/CSS (explicit values on
   every module, computed from the rendered stylesheet) and tell the user the match is **unmeasured**.
   Never claim "99%" without a measurement.
4. Typical causes of drift — check these first: unstated margins (Divi's defaults), row width / max-width,
   column gap, line-height, a preset leaking a font or colour, image width unstated (renders narrower),
   `phoneWide` used instead of `phone`, text wrapping because the column is a few px narrower than the CSS
   column, fonts not loaded (fallback font metrics), anti-aliasing (ignore sub-pixel noise).

---

## 8. Step 7 — Report (short, honest)

Give the user: the draft URL and the signed preview link; **measured match** per breakpoint
(e.g. "1440: 0.6% px diff, 768: 0.9%, 390: assumed layout, 1.4%") or "not measured, no browser";
**Deviations** (anything not native, any house-rule override, any font/asset that was missing);
**Assumptions** (responsive behaviour you inferred, canvas width); and **near-miss colours/sizes**
you kept literal, with an offer to turn them into global colours/variables.
Do not narrate tools or the method; describe the result.

---

## 9. Follow-up edits

For "change X" requests, edit only X: `get_page_tree` → `edit_page_modules`, then re-run §7 on the
affected region. The design is still the spec — if the user's new request contradicts it, change
what they asked and nothing else.
