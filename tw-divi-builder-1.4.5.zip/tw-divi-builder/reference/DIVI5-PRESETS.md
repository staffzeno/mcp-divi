# DIVI5-PRESETS.md — Divi 5 Global Presets

> Checked against Divi **5.16.0** on 2026-10-22: rule 8 (§8), §6b and the Component-copy presets in
> LAYOUT §5c were render-confirmed there. The code examples still carry `"version": "5.8.1"` /
> `builderVersion` `5.8.1` — Divi reads older stamps; set your site's version when you write new presets.

Presets are saved style configurations for module types. Any module instance can reference a preset by ID; Divi merges the preset attrs with the instance's own attrs at render time.

---

## §1 Storage

WP option (logical name): **`builder_global_presets_d5`**

**IMPORTANT — actual DB key:** Divi reads/writes this option via `et_get_option()` / `et_update_option()` with `$is_product_setting=true`, which prefixes the key with `et_{shortname}_`. On a standard Divi install the actual WordPress option row is **`et_divi_builder_global_presets_d5`**. The mu-plugin endpoint uses the same Divi functions so both reads and writes hit the correct key.

> **Note — `_d5` is created lazily; don't be fooled by seeing only `_ng` (verified on 5.8.1):** the `et_divi_builder_global_presets_d5` row does not exist until the first successful Divi 5 preset save/import (`GlobalPreset::save_data()`). A sibling row, `et_divi_builder_global_presets_ng`, is the **Divi 4 legacy store**, read once for migration (`GlobalPreset::get_legacy_data()`, gated by `et_divi_builder_is_legacy_presets_imported_to_d5`) — it exists as `{}` by default on fresh installs. So if `wp option list --search='et_divi_builder_global_presets*'` shows only `_ng`, it means no D5 preset has ever landed on that site, not that `_ng` is the live store. Two related import-side traps for programmatic workflows: render lookup searches `presets.module` buckets by the **full `divi/<type>` block name** (a bare-tag bucket like `"button"` imports fine but never matches), and front-end CSS generation is gated on the item's **`attrs`** key (`GlobalPresetItem::has_data_attrs()`) holding a full `{"module":{"decoration":…}}` tree — a `styleAttrs`-only item emits no CSS. Verified with a 4-variant live experiment on Divi 5.8.1.

### Top-level structure

```json
{
  "module": {
    "<moduleName>": {
      "default": "<preset-id>",
      "items": {
        "<preset-id>": { /* preset item — see §2 */ }
      }
    }
  },
  "group": {}
}
```

- `moduleName` = Divi block slug e.g. `"divi/heading"`, `"divi/text"`, `"divi/button"`
- `default` = ID of the preset that is auto-applied to every new instance of that module
- `items` = object keyed by preset ID

---

## §1b Preset system model — design it in levels (role-based)

Divi 5 presets form a **four-level system**. Designing with the levels — not one-off per-module styles — is what makes output feel like a coherent design system and keeps it editable (a key AI-slop fix; DESIGN-PROCESS §8b/§8c).

1. **Design variables** (foundation) — colours, fonts, sizes, radii as global tokens (`gcid-*` / `gvid-*`). Role-based names beat raw values ("Primary Color", "Space M"). See STYLING §10.
2. **Option-Group presets** — reusable single-group styles (Border, Spacing, Text, Button, Background) that **stack and nest across module types**. Divi stores these in the top-level **`group`** bucket (alongside `module`). Define **8–12 foundational ones first** (e.g. `Text: Body`, `Text: Heading`, `Button: Primary Filled`, `Border: Card`, `Spacing: Section`) before styling whole components.
3. **Nested (composable) presets** — an Option-Group preset applied inside a module's sub-element (a card's inner button, a blurb's image) via Divi's Composable Settings, so sub-elements join the system instead of carrying hardcoded overrides.
4. **Element (module) presets** — a full module style that **bundles** the lower levels; stored in `module.<moduleName>.items` (§1). Assign a **`default`** per module type so new instances arrive pre-styled.

**Stacking order (page JSON):** apply the **base** preset first, then **variation** presets — later wins on overlapping keys (`modulePreset: ["btn-base","btn-dark"]`; §6). Prefer **base + variation** over a separate preset per context.

**Naming:** role-based and scope-prefixed, never page-specific — `Button: Primary Filled`, `Border: Card`, `Text: Body`; variations as `Base` vs `Base: Dark` (`Pill` → `Pill: Dark`). Reads cleanly in the Preset Manager and maps straight to descriptive layer names.

**Avoid:** inline overrides that silently break the preset link (audit them); a bloated library of near-duplicate Element presets where a base + one variation would do.

---

## §2 Preset Item Schema

```json
{
  "id":         "abc123",
  "name":       "My Heading Style",
  "moduleName": "divi/heading",
  "version": "5.8.1",
  "type":       "module",
  "created":    1749999999,
  "updated":    1749999999,
  "attrs":      { /* PRIMARY CSS bucket — drives PHP CSS generation — see §3 */ },
  "styleAttrs": { /* AUXILIARY — same structure as attrs; used by builder UI for deduplication */ },
  "renderAttrs": { /* HTML-structure attrs — see §4 */ }
}
```

**Required fields:** `id`, `name`, `moduleName`, `version`, `type`, `created`, `updated`

⚠️ **`renderAttrs` must be present, and when empty it must be an empty ARRAY `[]`, not an
empty object `{}`.** A preset missing it can validate, save, and be counted in the totals
while never appearing in the builder's preset list — there is no error anywhere; the only
symptom is a human looking at a dropdown. (Divi Connect ≥ 2.0.4 fills this in for you on
write, so this matters most when writing to the store by any other route.)

⛔ **`order` is NOT required.** It appears on presets the builder itself creates, so it shows
up when you diff against one — but all 490 presets Divi Connect ships omit it and list
correctly. Do not add it on the strength of a diff against a builder-made preset.

**Bucket priority (source-verified):**
- `attrs` is checked by `GlobalPresetItem::has_data_attrs()` → empty `attrs` means NO CSS is generated, even if `styleAttrs` has values
- `styleAttrs` is auxiliary — the builder UI reads it for deduplication; it does NOT drive PHP CSS generation
- Put all styling in **`attrs`**; mirror it in `styleAttrs` for builder-UI consistency

---

## §2b GROUP preset item schema — different from a module preset in three ways

A **group preset** (Divi calls these Option Group Presets) styles one *option group* —
Button, Border, Spacing, Text, Background — and **stacks across module types**. It is the
right home for a reusable button style, because **a group preset out-cascades a module
preset**: if both target the same property, the group wins.

🚨 **DO NOT MODEL A GROUP ITEM ON A MODULE ITEM.** It is the commonest way to produce a
preset that saves, validates, is counted, and never appears in the builder. Three
differences, all load-bearing:

| | module preset | group preset |
|---|---|---|
| `type` | `"module"` | `"group"` |
| identity | `moduleName` alone | **`groupName` + `groupId`**, *plus* `moduleName` |
| `attrs` root | the module's own root (`module`, `title`, …) | **the GROUP's key** (`button`, `image`, …) — **NOT `decoration`** |

```json
{
  "type":       "group",
  "id":         "dlp-btn-ghost",
  "name":       "DL Button: Ghost",
  "version":    "5.9.0",
  "created":    0,
  "updated":    0,
  "groupName":  "divi/button",      // MUST match Divi's presetGroup EXACTLY
  "groupId":    "button",
  "moduleName": "divi/signup",      // still required on a group preset
  "attrs": {
    "button": {                     // ← the GROUP key is the root, not `decoration`
      "decoration": {
        "background": { "desktop": { "value": { "color": "rgba(0,0,0,0)" } } },
        "font": { "font": { "desktop": { "value": { "color": "#1E4FD8" } } } }
      }
    }
  },
  "styleAttrs": { /* mirror of attrs */ },
  "renderAttrs": []
}
```

🪤 **A `groupName` that does not match Divi's own `presetGroup` string is SILENTLY IGNORED** —
no error, no warning, and the preset simply never applies. Read an existing group preset out
of the store and copy the string rather than guessing it.

**Group buckets Divi Connect ships presets into:** `divi/background`, `divi/border`,
`divi/box-shadow`, `divi/button`, `divi/filters`, `divi/font`, `divi/font-body`, `divi/image`,
`divi/layout`, `divi/sizing`, `divi/spacing`.

🔑 **The fastest way to get this right is to read one.** From Divi Connect 2.0.4 the preset
read can be filtered, so you can fetch a single real group preset and copy its shape instead
of inferring it:

```
divi_get_presets  type="group"  group="divi/button"
```

⚠️ **Validation is not a render check.** A preset can pass `divi_repair_presets` — which checks
*structure* — and still not appear in the builder, because the builder applies rules the store
does not. **"Valid" means "the store will hold it", not "the builder will show it."** After
writing a preset, confirm it appears in the builder's list before building on top of it.

---

## §3 attrs / styleAttrs — Format & Key Paths

Both `attrs` and `styleAttrs` use the **same nested D5 responsive format** as page JSON:

```json
{
  "attrPath": {
    "<breakpoint>": {
      "value": { /* value object or scalar */ }
    }
  }
}
```

Breakpoints: `desktop` | `tablet` | `phone`  
State: `value` is the normal state. Hover state would add a `hover` key inside the breakpoint.

### §3a Title font attrs — `divi/heading`

Attr path root: `title.decoration.font`

| attrs key path | What it controls |
|---|---|
| `title.decoration.font.font.{bp}.value.color` | Title text color |
| `title.decoration.font.font.{bp}.value.size` | Font size (e.g. `"48px"`, `"3em"`) |
| `title.decoration.font.font.{bp}.value.family` | Font family (e.g. `"Roboto"`) |
| `title.decoration.font.font.{bp}.value.weight` | Font weight (`"700"`, `"400"`) |
| `title.decoration.font.font.{bp}.value.style` | Italic etc (`"italic"`, `"normal"`) |
| `title.decoration.font.font.{bp}.value.textAlign` | `"left"` / `"center"` / `"right"` |
| `title.decoration.font.font.{bp}.value.lineHeight` | e.g. `"1.5em"` |
| `title.decoration.font.font.{bp}.value.letterSpacing` | e.g. `"2px"` |
| `title.decoration.font.font.{bp}.value.lineColor` | Text decoration color |
| `title.decoration.font.font.{bp}.value.lineStyle` | `"underline"` / `"overline"` / etc. |
| `title.decoration.font.textShadow.{bp}.value.style` | Shadow preset name |
| `title.decoration.font.textShadow.{bp}.value.horizontal` | e.g. `"2px"` |
| `title.decoration.font.textShadow.{bp}.value.vertical` | e.g. `"2px"` |
| `title.decoration.font.textShadow.{bp}.value.blur` | e.g. `"4px"` |
| `title.decoration.font.textShadow.{bp}.value.color` | Shadow color |
| `title.decoration.font.textEffects.{bp}.value.fillType` | `"none"` / `"gradient"` / `"image"` / `"transparent"` |
| `title.decoration.font.textEffects.{bp}.value.strokeColor` | Outline/stroke color |
| `title.decoration.font.textEffects.{bp}.value.strokeWidth` | Outline width (e.g. `"2px"`) |
| `title.decoration.font.textEffects.{bp}.value.gradient` | Full gradient object |
| `title.decoration.font.textEffects.{bp}.value.imageFill.url` | Image fill URL |

### §3b Module decoration attrs (apply to ALL modules)

| attrs key path | What it controls |
|---|---|
| `module.decoration.background.{bp}.value.color` | Background color |
| `module.decoration.background.{bp}.value.gradient` | Gradient object |
| `module.decoration.background.{bp}.value.image` | Background image object |
| `module.decoration.spacing.{bp}.value.margin` | Margin (object with top/right/bottom/left) |
| `module.decoration.spacing.{bp}.value.padding` | Padding |
| `module.decoration.sizing.{bp}.value.width` | Module width |
| `module.decoration.sizing.{bp}.value.maxWidth` | Max width |
| `module.decoration.sizing.{bp}.value.alignSelf` | Module box alignment on the column cross-axis (the native **Sizing → Alignment** VB control, `align-self`): `"flex-start"` / `"center"` / `"end"`. Use THIS to position a width-capped box (e.g. a `maxWidth` text block), **not** `margin:auto` — it stays VB-editable and round-trips. Left = flex default, so omit it. |
| `module.decoration.border.{bp}.value.radius` | Border radius |
| `module.decoration.border.{bp}.value.styles` | Border styles object |
| `module.decoration.boxShadow.{bp}.value.style` | Shadow style preset |
| `module.decoration.boxShadow.{bp}.value.color` | Shadow color |
| `module.decoration.filters.{bp}.value.opacity` | `"50%"` etc. |
| `module.decoration.filters.{bp}.value.blur` | `"4px"` etc. |
| `module.decoration.transform.{bp}.value.scale` | Scale object |
| `module.decoration.transform.{bp}.value.rotate` | Rotate object |
| `module.decoration.animation.{bp}.value.style` | `"fade"`, `"slide"`, etc. |
| `module.decoration.animation.{bp}.value.direction` | `"left"`, `"right"`, etc. |
| `css.{bp}.value.mainElement` | Custom CSS for main element |
| `css.{bp}.value.headingContainer` | Custom CSS for `.et_pb_heading_container` (heading only) |

### §3c Text module font attrs — `divi/text`

Attr path root: `content.decoration.bodyFont`

| attrs key path | What it controls |
|---|---|
| `content.decoration.bodyFont.body.font.{bp}.value.color` | Body text color |
| `content.decoration.bodyFont.body.font.{bp}.value.size` | Font size |
| `content.decoration.bodyFont.body.font.{bp}.value.family` | Font family |
| `content.decoration.bodyFont.body.font.{bp}.value.lineHeight` | Line height |
| `content.decoration.bodyFont.link.font.{bp}.value.color` | Link color |
| `content.decoration.bodyFont.h1.font.{bp}.value.size` | H1 size inside text module |

---

## §4 renderAttrs — HTML-Affecting Attrs

Same nested format as `attrs`. Controls HTML structure/attributes, not CSS styles.

⚠️ **When it carries nothing, ship it as `[]` — see the warning in §2.** An empty object is
not equivalent here, and the failure is silent.

| renderAttrs key path | What it controls |
|---|---|
| `title.decoration.font.font.{bp}.value.headingLevel` | HTML tag: `"h1"` / `"h2"` / `"h3"` etc. |
| `module.advanced.html.{bp}.value.elementType` | Heading's wrapping HTML element |
| `module.decoration.sizing.{bp}.value.flexType` | Flex type (layout) |

---

## §5 REST Endpoint (mu-plugin)

Endpoint: `POST /wp-json/skill-loop/v1/global-presets`  
Auth: Application Password (same as all other skill-loop endpoints)

### Create / merge presets

```python
import requests, time

PRESETS_URL = "https://your-site.example/wp-json/skill-loop/v1/global-presets"
AUTH = ("claude", "If1f Vre2 moxv iXmE NDxX riYP")

ts = int(time.time())
preset_id = "skill-heading-dark-01"

# attrs is the PRIMARY bucket — MUST be non-empty for CSS to be generated.
# styleAttrs mirrors attrs for builder UI consistency.
style = {
    "title": {
        "decoration": {
            "font": {
                "font": {
                    "desktop": {"value": {"color": "#ffffff", "size": "48px", "weight": "700"}},
                    "tablet":  {"value": {"size": "36px"}},
                    "phone":   {"value": {"size": "28px"}}
                }
            }
        }
    },
    "module": {
        "decoration": {
            "background": {
                "desktop": {"value": {"color": "#1a1a2e"}}
            },
            "spacing": {
                "desktop": {"value": {"padding": {"top": "40px", "bottom": "40px"}}}
            }
        }
    }
}

presets = {
    "module": {
        "divi/heading": {
            "default": preset_id,
            "items": {
                preset_id: {
                    "id": preset_id,
                    "name": "Dark Heading",
                    "moduleName": "divi/heading",
                    "version": "5.8.1",
                    "type": "module",
                    "created": ts,
                    "updated": ts,
                    "attrs": style,        # PRIMARY — drives CSS generation
                    "styleAttrs": style,   # AUXILIARY — mirrors attrs for builder UI
                    "renderAttrs": []      # empty = an ARRAY; {} saves but never lists (§2)
                }
            }
        }
    }
}

r = requests.post(PRESETS_URL, json={"presets": presets, "merge": True}, auth=AUTH)
print(r.json())
```

### Read current presets

```python
r = requests.get(PRESETS_URL, auth=AUTH)
print(r.json())
```

### Clear all presets

```python
r = requests.delete(PRESETS_URL, auth=AUTH)
print(r.json())
```

---

## §6 Applying a Preset to a Module in Page JSON

Add `modulePreset` at the top level of the module's attrs object (not nested under any decoration key):

```python
# Single preset
m('heading', {
    'modulePreset': 'skill-heading-dark-01',
    'title': {'innerContent': {'desktop': {'value': 'My Heading'}}},
    'builderVersion': '5.8.1'
})

# Stacked presets — last item wins on conflict
m('heading', {
    'modulePreset': ['base-preset-id', 'accent-preset-id'],
    'title': {'innerContent': {'desktop': {'value': 'My Heading'}}},
    'builderVersion': '5.8.1'
})

# Inline override beats preset — inline attr value wins over preset attr value
m('heading', {
    'modulePreset': 'skill-heading-dark-01',
    'title': {
        'innerContent': {'desktop': {'value': 'Red text despite preset'}},
        'decoration': {'font': {'font': {'desktop': {'value': {'color': '#ef4444'}}}}}
    },
    'builderVersion': '5.8.1'
})
```

### §6b CSS ID, CSS class and custom attributes from a preset (✓ render-confirmed on 5.16.0)

Since Divi 5.12 a preset can put attributes on the module wrapper, but **which preset type carries which
attribute matters**:

| set in | renders on the wrapper? |
|---|---|
| a **module** preset's custom attributes — `module.decoration.attributes` (`data-*`, and also `id` / `class` given as attribute names) | ✅ yes |
| a **module** preset's CSS ID & Classes — `module.advanced.htmlAttributes` `{id, class}` | ❌ **no — silently dropped** |
| a **group** preset of `groupName` **`divi/id-classes`** (`groupId` `module.advanced.htmlAttributes`) | ✅ yes — `id` and `class` |

- Divi reads the `divi/id-classes` group preset's id/class from its **`renderAttrs`** — put the same
  `{"module":{"advanced":{"htmlAttributes":{"desktop":{"value":{"id":"…","class":"…"}}}}}}` tree in
  `attrs` (non-empty, or the preset counts as empty) **and** `renderAttrs`. The page references it like
  any group preset:
  `"groupPreset":{"module.advanced.htmlAttributes":{"presetId":["<id>"],"groupName":"divi/id-classes"}}`.
- The module's **own** class is kept: a module with its own `htmlAttributes` class plus a preset class
  rendered both (fixed in 5.12.1; before, the preset class replaced the module's).
- A preset that sets an **id** gives that id to every module using the preset — keep such a preset to one
  module per page, or the page has duplicate ids. (Divi 5.12's notes say preset ids are dropped to prevent
  this; on 5.16.0 both a custom attribute named `id` and a `divi/id-classes` id rendered.)
- Not tested: preset-sourced interactions (5.12 says they reach the wrapper too).

---

## §7 Common Preset Patterns

### Typography preset (heading)
```python
def make_heading_typography_preset(id, name, color, size_desktop, size_tablet, size_phone,
                                    family=None, weight="700", align="left"):
    ts = int(time.time())
    font_val = {"color": color, "size": size_desktop, "weight": weight, "textAlign": align}
    if family:
        font_val["family"] = family
    style = {
        "title": {"decoration": {"font": {"font": {
            "desktop": {"value": font_val},
            "tablet":  {"value": {"size": size_tablet}},
            "phone":   {"value": {"size": size_phone}}
        }}}}
    }
    return {
        "id": id, "name": name, "moduleName": "divi/heading",
        "version": "5.8.1", "type": "module", "created": ts, "updated": ts,
        "attrs": style,       # PRIMARY
        "styleAttrs": style,  # AUXILIARY
        "renderAttrs": []     # empty = an ARRAY (§2)
    }
```

### Background + spacing preset (any module)
```python
def make_section_style_preset(id, name, module_name, bg_color, padding="60px"):
    ts = int(time.time())
    style = {
        "module": {"decoration": {
            "background": {"desktop": {"value": {"color": bg_color}}},
            "spacing":    {"desktop": {"value": {"padding": {
                "top": padding, "bottom": padding, "left": padding, "right": padding
            }}}}
        }}
    }
    return {
        "id": id, "name": name, "moduleName": module_name,
        "version": "5.8.1", "type": "module", "created": ts, "updated": ts,
        "attrs": style,       # PRIMARY
        "styleAttrs": style,  # AUXILIARY
        "renderAttrs": []     # empty = an ARRAY (§2)
    }
```

---

## §8 Critical Rules

1. **`attrs` is the PRIMARY CSS bucket** — `GlobalPresetItem::has_data_attrs()` checks `attrs`, not `styleAttrs`. If `attrs` is empty or missing, Divi skips CSS generation entirely for that preset, even if `styleAttrs` has values. Always put styling in `attrs`.

2. **`styleAttrs` is auxiliary** — mirrors `attrs` for builder UI deduplication. Has no effect on PHP CSS generation.

3. **Actual DB option key is `et_divi_builder_global_presets_d5`** — Divi reads/writes via `et_get_option()` / `et_update_option()` with `$is_product_setting=true`, which prepends `et_{shortname}_`. Saving with native `update_option('builder_global_presets_d5', ...)` writes to the wrong key and causes `get_selected_preset()` to return `is_exist:false`. The mu-plugin endpoint uses `et_update_option()` so this is handled correctly.

4. **Preset ID uniqueness is global** — IDs must be unique across ALL module types in the option, not just per-module.

5. **`modulePreset` is a top-level attr** — not nested under `decoration` or `advanced`. It sits at the same level as `title`, `module`, `builderVersion` etc.

6. **Stacked presets** — `modulePreset` accepts a string (single) or array (stacked). Last preset in the array wins on conflict.

7. **Inline attrs override preset attrs** — module-level inline styling always wins over preset styling.

8. **`default` preset applies to EVERY instance with no `modulePreset` — existing ones too.** Divi resolves a module with no `modulePreset` to its type's `default` at RENDER time (`GlobalPreset::get_selected_preset()`; the wrapper gets `preset--module--divi-<type>--default`). Measured on Divi 5.16.0: a text module with no preset rendered exactly like one naming the default. ⇒ Setting or changing a `default` restyles every page already using that module type without a preset. (Corrected 2026-10-22 — this rule used to say existing instances were not affected.)

9. **Cache flush** — The mu-plugin endpoint calls `ET_Core_PageResource::remove_static_resources()` to flush Divi's CSS cache after saving. Static CSS is regenerated on next page load.

---

*Real-render verified at Divi 5.7.0. Source-verified from: `GlobalPreset.php` (`get_data()`, `save_data()`, `get_selected_preset()`), `GlobalPresetItem.php` (`has_data_attrs()`, `get_data_attrs()`), `GlobalPresetItemUtils.php` (`generate_preset_class_name()`), `Module.php` (`render_styles_preset()`), `epanel/custom_functions.php` (`et_get_option()`, `et_update_option()`) — V0.5.1 / 2026-06-09*
*Re-checked on Divi 5.16.0 (2026-10-22): `default` reaches existing instances (rule 8), wrapper attributes from presets (§6b); source `Module.php`, `GlobalPreset.php`, `ComponentPresetUtils.php`.*

---

*DIVI5 Presets Skill — V0.7.3 | Builder Version 5.16.0 | Tech Webers MCP Builder for Divi 5*
