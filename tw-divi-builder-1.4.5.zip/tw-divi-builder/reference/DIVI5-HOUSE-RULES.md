# House Rules — the site owner's defaults (read before writing ANY page)

These are the owner's standing preferences. They apply to every page you build. Exact attribute
paths are given so you can copy them. Breakpoints are `desktop`, `tablet` (≤980px) and `phone`
(≤767px) only — never `phoneWide`.

**Precedence (highest first):**
1. **A design the user supplied** (mockup image, Figma, PDF, uploaded or pasted HTML): every value the
   design shows wins. Copy it exactly, add nothing (§8, and `DIVI5-MOCKUP-FIDELITY.md`).
2. **These house rules** — they fill in whatever the design does not state (e.g. tablet/phone padding)
   and apply in full when you design the page yourself.
3. Divi's own defaults — only where neither of the above says anything. State explicit values
   instead of relying on defaults.

---

## 1. Layout defaults

### 1a. Section: side padding 50px / 30px / 20px
Every `divi/section` gets left and right padding of **50px desktop, 30px tablet, 20px phone**.
Top/bottom padding is a design decision (keep it in the same `padding` object).

```json
"module": {"decoration": {"spacing": {
  "desktop": {"value": {"padding": {"top": "80px", "bottom": "80px", "left": "50px", "right": "50px"}}},
  "tablet":  {"value": {"padding": {"left": "30px", "right": "30px"}}},
  "phone":   {"value": {"padding": {"left": "20px", "right": "20px"}}}
}}}
```

### 1b. Row: 100% wide, no side padding of its own
Every `divi/row` is **100% of the section**; the section's side padding is the page margin. Do not
leave Divi's default row width (it narrows the row and doubles the margin). Rows carry no side padding.

```json
"module": {"decoration": {
  "sizing":  {"desktop": {"value": {"width": "100%", "maxWidth": "100%"}}},
  "spacing": {"desktop": {"value": {"padding": {"left": "0px", "right": "0px"}}}}
}}
```
Because rows are full width, **state `maxWidth` in `ch` on paragraphs** (e.g. `"65ch"`) so body text never
runs edge to edge, and use `maxWidth` on a row only when the design shows a narrower container.

### 1c. Gaps: 16px by default
- **Row (space between columns): `columnGap: "16px"`, and `rowGap: "16px"` for wrapped rows.**
- **Column and group (space between the modules stacked inside them): `rowGap: "16px"`** (a column is a
  vertical flex container; use `flexDirection: "column"` explicitly).
- A grid container: `columnGap` and `rowGap` both `"16px"`.
Divi's default column gutter is far too wide; never leave it unstated.

```json
// row
"module": {"decoration": {"layout": {"desktop": {"value": {"columnGap": "16px", "rowGap": "16px"}}}}}
// column / group
"module": {"decoration": {"layout": {"desktop": {"value": {"flexDirection": "column", "rowGap": "16px"}}}}}
```
Change a gap only when the design shows a different one, or for a deliberate tight/airy pairing
(e.g. an eyebrow glued to its heading → `rowGap` smaller on that column).

---

## 2. Cards in a row are EQUAL size (group and blurb cards)
Whenever 2+ cards sit side by side (feature cards, pricing, team, services, testimonials):
1. Equal columns: the same `flexType` on every column (`8_24` ×3, `12_24` ×2, `6_24` ×4…).
2. **Add the class `twdb-equal-cards` to the ROW** (`module.advanced.htmlAttributes.desktop.value.class`).
   The plugin's helper CSS then stretches every card to the height of the tallest one.
3. Also set the row's `alignItems: "stretch"` (native) — belt and braces.
4. **One card = one module per column**, a `divi/group` (preferred) or `divi/blurb`, with the SAME padding,
   border, radius, background and shadow on every card in the row. No `minHeight` hacks, no fixed heights.
5. To keep the buttons on one line at the bottom of each card, make the card a `divi/group` with
   `layout.flexDirection: "column"` and `justifyContent: "space-between"`.

```json
"module": {"advanced": {"htmlAttributes": {"desktop": {"value": {"class": "twdb-equal-cards"}}}},
           "decoration": {"layout": {"desktop": {"value": {"alignItems": "stretch", "columnGap": "16px"}}}}}
```
Check at 1440 that all cards in the row have the same height; on phone they stack, which is expected.
(If the owner turned the helper CSS off, give each card `sizing.height: "100%"` instead.)

---

## 3. Buttons never change letter-spacing on hover
Write the same `letterSpacing` in the resting and the hover state (default `"0px"`) — BASE "Letter Spacing
Must Not Change On Button Hover". The plugin's helper CSS also forces `letter-spacing: 0` on every
`.et_pb_button:hover`, so existing and future buttons stay still. If a design truly rests buttons at a
non-zero letter-spacing, add the class `twdb-keep-ls` to that button (CSS class field) and put the same value
in `value` and `hover`.

---

## 4. Tabs: native module first; buttons + rows + JS only for two-column panels

**Decision:**
- Tab panels contain only text/simple content → **`divi/tabs` + `divi/tab`** (MODULES-INTERACTIVE). Always the default.
- A tab panel needs a **multi-column layout** (e.g. image left + text right, or two columns of cards),
  or other modules/rows the native tab cannot hold → build **custom tabs from buttons + rows**, below.
  Never fake native tabs with `divi/code` HTML, and never use custom tabs where native tabs are enough.

**Custom tabs — markup contract** (the plugin loads the small script; you only set classes through each
module's CSS class field, `module.advanced.htmlAttributes.desktop.value.class`):

| Element | Divi build | CSS classes |
|---|---|---|
| Wrapper | the `divi/section` (or a `divi/group`) that holds the buttons AND the panels | `twdb-tabs` |
| Tab buttons | one `divi/button` per tab, link `#`, inside one row/column | `twdb-tab-btn twdb-tab-KEY` |
| Panels | one `divi/row` per tab (each with its own columns) | `twdb-tab-panel twdb-tab-KEY` |
| Start tab (optional) | add to ONE button | `twdb-tab-default` |

`KEY` is a short word per tab (`one`, `pricing`, `faq`…), the same on a button and its panel, unique
within the wrapper. Several tab sets can live on one page (one `twdb-tabs` wrapper each).

```json
// button (self-closing)
{"button": {"innerContent": {"desktop": {"value": {"text": "Design", "linkUrl": "#", "linkTarget": "off"}}},
            "decoration": {"font": {"font": {"desktop": {"value": {"letterSpacing": "0px"}, "hover": {"letterSpacing": "0px"}}}}}},
 "module": {"advanced": {"htmlAttributes": {"desktop": {"value": {"class": "twdb-tab-btn twdb-tab-design twdb-tab-default"}}}}},
 "builderVersion": "5.11.1"}
// panel row (contains its two columns)
{"module": {"advanced": {"htmlAttributes": {"desktop": {"value": {"class": "twdb-tab-panel twdb-tab-design"}}}}},
 "builderVersion": "5.11.1"}
```
What the script does: adds `twdb-js` to the wrapper, shows only the active panel, sets `.is-active` on the
active button and panel, ARIA roles, arrow / Home / End keys, and `#twdb-tab-KEY` deep links. Without JS
every panel stays visible, so nothing is lost if scripting fails.

**Style the buttons natively** (all buttons in one inactive/ghost look, the hover as designed) and give the
ACTIVE button its look with page CSS (`set_page_custom_css`), using the design's colours:
```css
.twdb-tabs .twdb-tab-btn.is-active .et_pb_button,
.twdb-tabs .twdb-tab-btn.is-active.et_pb_button { background:#111; color:#fff; border-color:#111; }
```
Verify with `render_page` (mode full) that wrapper, buttons and panels carry the classes, then in a browser
that clicking each button swaps panels. If the helper JS is switched off under Access settings, custom
tabs will not switch — say so instead of shipping them.

---

## 5. Never build look-alike sections
A page must not contain **two sections with the same structure and styling**, and above all not two card
grids in a row (symmetric "3 cards, then 3 more cards"). Each section gets its own shape:
- Alternate **layout**: asymmetric split (7/5, 5/7) → full-bleed band → grid → centred statement → list → big
  quote → image-led. At most ONE equal card grid per page.
- Alternate **surface**: flat white → tinted → dark → image/gradient → accent.
- Alternate **density and alignment**: airy centred, dense left-aligned, offset, overlapping.
- Cards are opt-in: use a card only where a section has distinct items; a second set of items becomes a list,
  a timeline, a split with an image, or a table.
The plugin's validator warns when two adjacent sections have an identical column/module structure.
**This rule applies to pages you design. A supplied design is copied as it is, repeated layouts included.**

---

## 6. Mobile menu: a real, responsive menu
The navigation is **always `divi/menu`** (or `divi/fullwidth-menu` in a fullwidth section) — never a row of
`divi/link` / text links as the only navigation. Below the tablet breakpoint (≤980px) it must collapse to a
hamburger and open a full-width panel:
1. Header layout: section (house side padding) → row (100%, `alignItems: center`, `justifyContent:
   space-between`) → logo column + menu column. Rows keep the 16px gap.
2. `menuMobile.advanced.collapsible: "on"` (submenus start closed with their own toggle buttons) and
   `parentLinksActive: "on"` (MODULES-DYNAMIC "Collapsible mobile menu").
3. Hamburger icon visible, ≥ 44×44px tap area, colour that contrasts with the header background.
4. The open panel is full width, has its own background (not transparent over the page), and menu items are
   ≥ 16px with ≥ 44px tap height and visible separation.
5. Logo scales down (set a phone `width`/`maxWidth`), header padding follows the 30px/20px side rule.
6. A sticky/fixed header must not cover anchors: add top scroll offset equal to its height when the page uses
   in-page links.
7. **Verify at 390px and 768px** (not just desktop): no horizontal scroll (`document.documentElement.
   scrollWidth <= innerWidth`), hamburger present, panel opens and closes, items tappable. If Divi's mobile
   panel needs a CSS fix, read its real class names from the rendered HTML (`render_page` full) before writing
   any selector, and put the CSS in the Theme Builder template or `set_custom_css`.

---

## 7. Always (in addition)
- Explicit `family`, `size`, `weight`, `lineHeight`, `letterSpacing`, `color` on every text module.
- Phone: `phone` breakpoint values for anything that must change (type scale, padding, columns stack, button
  full width if designed). Stack columns at tablet where there are 3+ columns.
- Draft status for new pages; fix every validator warning (or consciously ignore it and say why).

---

## 8. A design the user supplied (uploaded image / HTML file / Figma / PDF): copy it, add NOTHING
When the user uploads or pastes an image or an HTML file as the design:
- Reproduce **only** what is in it: same sections, order, copy, fonts, colours, sizes, spacing, radii,
  images, icons, alignment. Their design is the specification (`DIVI5-MOCKUP-FIDELITY.md`).
- **Do not add** sections, headings, paragraphs, taglines, badges, icons, images, dividers, shadows,
  gradients, animations, hover effects, counters, forms, CTAs or "improvements". **Do not remove or reorder**
  anything. **Do not rewrite copy**, fix typos silently, or substitute fonts/colours.
- If something seems wrong or missing in the design, build it as shown and mention it in the report
  afterwards. Never "fix" it yourself.
- House rules in this mode: the design's own values win (§1 only fills what the design is silent about, e.g.
  tablet/phone padding, row width when no container is shown, gaps when none are shown). Rules 2, 5 and 6 are for
  pages you design; they never override what the supplied design shows. Rule 3 (hover letter-spacing) and the
  `twdb-tabs` / native-tabs choice in rule 4 still apply, because they are about how it is built, not what it
  looks like.
