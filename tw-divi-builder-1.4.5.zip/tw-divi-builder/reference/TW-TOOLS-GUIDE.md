# Tech Webers MCP Builder for Divi 5 - tools guide for AI clients

This plugin exposes MCP tools that write Divi 5 content directly into WordPress.
The other reference topics teach the markup; this page maps their
workflow onto this plugin's tools.

## Build workflow

1. `site_info` - versions, theme, Divi status, the `builder_version_to_use`, the acting user's capabilities.
2. `get_divi_reference` topic `rules` (DIVI5-BASE) before writing markup; then `layout`, `styling`, module topics as needed.
3. `get_design_system` - copy the exact `$variable(...)$` tokens for colors and variables. Never invent ids.
   Missing tokens? Create them with `set_global_colors` / `set_global_variables` first (ask the user).
4. Write the page as Divi 5 block markup wrapped in ONE `<!-- wp:divi/placeholder -->` ... `<!-- /wp:divi/placeholder -->`.
   Optional: `validate_markup` first.
5. `create_page` (draft by default) or `update_page` (restore point saved automatically).
6. `render_page` (mode `full` for the real page) and share the `preview_url` with the user. Preview links are signed and expire after about an hour, but some hosts and CDNs (for example Cloudflare "cache everything" rules) ignore the plugin's no-cache headers and may keep a copy of the preview at that exact URL. Treat preview links as private.
7. Publish with `update_page` status `publish` only when the user asks.

## Divi Connect endpoint -> this plugin's tool

| Divi Connect (docs)                      | This plugin                                 |
|------------------------------------------|---------------------------------------------|
| GET /site, /status                       | `site_info`                                 |
| GET /design-system, /global-colors       | `get_design_system`                         |
| POST /global-colors                      | `set_global_colors`, `delete_global_color`  |
| POST /global-variables                   | `set_global_variables`                      |
| GET/POST /presets                        | `list_presets`, `upsert_preset`, `delete_preset` |
| GET /pages, /pages/{id}                  | `list_pages`, `list_posts`, `get_page`      |
| POST /pages (create / update)            | `create_page`, `update_page`                |
| DELETE /pages/{id}                       | `trash_page`                                |
| backups / restore                        | `list_backups`, `restore_backup`            |
| render / preview                         | `render_page`                               |
| /theme-builder                           | `list_templates`, `create_or_update_template` |
| /library                                 | `list_library_layouts`, `save_library_layout` |
| custom CSS                               | `get_custom_css`, `set_custom_css`, `set_page_custom_css` |
| menus                                    | `list_menus`, `create_or_update_menu`       |
| media                                    | `upload_media_from_url`                     |
| reading settings                         | `set_front_page`, `set_posts_page`          |
| SEO                                      | `get_seo`, `set_seo`                        |
| cache                                    | `clear_divi_cache`                          |

## Markup essentials (summary - see `rules` for detail)

- **Always read topic `house-rules` before writing markup** (section padding 50/30/20px, rows 100%, 16px gaps, equal-size cards via `twdb-equal-cards`, tabs, no look-alike sections, responsive mobile menu).
- **User supplied a mockup / HTML / Figma?** Read topic `mockup` first: copy the design exactly with native modules, build as a draft, compare to the design with `render_page` + a browser, and fix with `get_page_tree` / `edit_page_modules` until it matches.
- Buttons: write `letterSpacing` in BOTH the resting `value` and the `hover` state (same value, default `"0px"`) so the text never changes spacing on hover.
- Whole page inside one `divi/placeholder`. Top level: `divi/section` (or a section Component).
- Nesting: section > row > column > modules. Leaf modules self-close: `<!-- wp:divi/text {...} /-->`.
- Every block carries `"builderVersion"` (use `site_info.divi.builder_version_to_use`).
- Attributes sit at the top level of the JSON - never inside an `"attrs"` wrapper.
- `divi/text` stores its body under `"content"`; HTML inside values is raw (`<p>`), not escaped.
- Templates: `default` keeps the Theme Builder header/footer; `blank` hides them.
- Components: `<!-- wp:divi/global-layout {"globalModule":"<library id>","blockName":"divi/section"} /-->`.

## Safety

- Every overwrite of a page, layout, global colors/variables/presets or CSS stores a restore point
  (`list_backups` / `restore_backup`, 25 kept per object).
- Ask the user before trashing pages, deleting colors/presets, changing the homepage or publishing.
- If the site owner enabled read-only mode, write tools are hidden.

## No executable code

This plugin removes executable code written by an AI client before anything is saved: `<script>`,
`<iframe>`, `<object>`/`<embed>`, inline event handlers (`onclick` ...), `javascript:`/`vbscript:` and
non-image `data:` URLs, Divi custom attributes named `on*`, and script-like CSS (`expression()`,
`behavior:`, `-moz-binding`). The tool result lists what was removed in `warnings`.

- Build with native modules: `divi/video` (YouTube/Vimeo URL), `divi/map`, `divi/svg`, `divi/image`,
  `divi/contact-form`, `divi/social-media-follow` and so on.
- `divi/code` may still hold static HTML, inline SVG and `<style>` blocks; scripts and embeds are removed.
- Existing content that you send back unchanged (for example a Code module a person added) is kept exactly
  as it is, so you can edit other parts of such pages safely.
- Custom CSS tools refuse CSS with script-like constructs.

