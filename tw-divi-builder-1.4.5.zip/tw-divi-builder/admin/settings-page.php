<?php
/**
 * Settings page template. Variables come from TWDB_Settings::render_page().
 *
 * @package TW_Divi_Builder
 *
 * @var array        $tabs
 * @var string       $tab
 * @var string       $msg
 * @var array        $settings
 * @var array        $divi
 * @var string       $endpoint
 * @var array|false  $new
 * @var string       $raw_key
 * @var string       $key_url
 * @var array        $keys
 * @var array|false  $legacy_hint
 * @var bool         $legacy_on
 * @var array        $guides
 * @var bool         $oauth_on
 * @var array        $people
 * @var array        $log
 * @var array        $users
 * @var bool         $subfolder
 * @var array        $checks
 * @var array|false  $selftest
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$twdb_messages = array(
	'saved'         => __( 'Settings saved.', 'tw-divi-builder' ),
	'key'           => __( 'Connector key created. Copy the address below now: the key is shown only once.', 'tw-divi-builder' ),
	'key_revoked'   => __( 'Key revoked. Anything still using it stops working.', 'tw-divi-builder' ),
	'too_many_keys' => __( 'This site already has the maximum number of keys. Revoke one first.', 'tw-divi-builder' ),
	'log_cleared'   => __( 'History cleared.', 'tw-divi-builder' ),
	'selftest'      => __( 'Self-test finished. Results are below.', 'tw-divi-builder' ),
	'conn_revoked'  => __( 'Connection ended. The app has to sign in again to come back.', 'tw-divi-builder' ),
);
$twdb_fmt      = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
$twdb_post     = esc_url( admin_url( 'admin-post.php' ) );
?>
<div class="wrap twdb-wrap" id="twdb-settings" data-method="<?php echo esc_attr( ( $oauth_on && ! $new ) ? 'oauth' : 'key' ); ?>" data-force-key="<?php echo esc_attr( ( ! $oauth_on || $new ) ? '1' : '0' ); ?>" data-copied="<?php echo esc_attr__( 'Copied', 'tw-divi-builder' ); ?>">
	<h1><?php esc_html_e( 'Tech Webers MCP Builder for Divi 5', 'tw-divi-builder' ); ?></h1>
	<p><?php esc_html_e( 'Connect Claude, ChatGPT, Codex, Gemini, DeepSeek Harness or any MCP app so it can build and edit this Divi 5 site.', 'tw-divi-builder' ); ?></p>

	<?php if ( $msg && isset( $twdb_messages[ $msg ] ) ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $twdb_messages[ $msg ] ); ?></p></div>
	<?php endif; ?>

	<?php if ( ! $divi['active'] ) : ?>
		<div class="notice notice-warning"><p><?php esc_html_e( 'Divi (theme or Divi Builder plugin) is not active. Page tools still work, but Divi-only tools (design system, presets, Theme Builder, library, cache) will return an error until Divi 5 is active.', 'tw-divi-builder' ); ?></p></div>
	<?php elseif ( ! $divi['is_divi5'] ) : ?>
		<div class="notice notice-warning"><p><?php esc_html_e( 'Divi is active but does not look like Divi 5. This plugin writes Divi 5 block markup.', 'tw-divi-builder' ); ?></p></div>
	<?php endif; ?>

	<h2 class="nav-tab-wrapper">
		<?php foreach ( $tabs as $twdb_slug => $twdb_label ) : ?>
			<a href="<?php echo esc_url( TWDB_Settings::page_url( $twdb_slug ) ); ?>" class="nav-tab <?php echo $twdb_slug === $tab ? 'nav-tab-active' : ''; ?>"><?php echo esc_html( $twdb_label ); ?><?php echo ( 'people' === $twdb_slug && $people ) ? ' (' . esc_html( (string) count( $people ) ) . ')' : ''; ?></a>
		<?php endforeach; ?>
	</h2>

	<?php if ( 'connection' === $tab ) : ?>

		<h2><?php esc_html_e( 'Which AI are you connecting?', 'tw-divi-builder' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Pick one and the exact steps for it appear below. You can connect as many as you like.', 'tw-divi-builder' ); ?></p>
		<div class="twdb-picker" id="twdb-ai-picker">
			<?php foreach ( $guides as $twdb_ai => $twdb_g ) : ?>
				<button type="button" class="twdb-choice" data-ai="<?php echo esc_attr( $twdb_ai ); ?>"><b><?php echo esc_html( $twdb_g['label'] ); ?></b><span><?php echo esc_html( $twdb_g['sub'] ); ?></span></button>
			<?php endforeach; ?>
		</div>

		<h2><?php esc_html_e( 'How should it sign in?', 'tw-divi-builder' ); ?></h2>
		<p class="description"><?php echo wp_kses_post( __( 'Both work. <b>Sign in with WordPress</b> (OAuth): each person gets their own connection that you can end one at a time, and the History names them. <b>Connector key</b>: one shared secret carried in the address or a header; anyone who has it can act on the site until you revoke it. If an app asks, choose <i>OAuth</i> for the first, or <i>no authentication</i> for a key inside the address.', 'tw-divi-builder' ) ); ?></p>
		<div class="twdb-picker" id="twdb-method-picker">
			<?php if ( $oauth_on ) : ?>
				<button type="button" class="twdb-choice" data-method="oauth"><b><?php esc_html_e( 'Sign in with WordPress', 'tw-divi-builder' ); ?></b><span><?php esc_html_e( 'recommended · per person · revocable', 'tw-divi-builder' ); ?></span></button>
			<?php endif; ?>
			<button type="button" class="twdb-choice" data-method="key"><b><?php esc_html_e( 'Use a connector key', 'tw-divi-builder' ); ?></b><span><?php esc_html_e( 'one shared key', 'tw-divi-builder' ); ?></span></button>
		</div>
		<?php if ( ! $oauth_on ) : ?>
			<p class="description"><?php esc_html_e( 'Sign in with WordPress is switched off under Access settings.', 'tw-divi-builder' ); ?></p>
		<?php endif; ?>

		<div class="twdb-card">
			<div data-addr="oauth">
				<strong><?php esc_html_e( 'Connector address', 'tw-divi-builder' ); ?></strong>
				<p><code id="twdb-addr-oauth"><?php echo esc_html( $endpoint ); ?></code> <button type="button" class="button twdb-copy" data-target="twdb-addr-oauth"><?php esc_html_e( 'Copy', 'tw-divi-builder' ); ?></button></p>
				<p class="description"><?php esc_html_e( 'No secret in it: the app signs in through WordPress.', 'tw-divi-builder' ); ?></p>
			</div>
			<div data-addr="key">
				<strong><?php esc_html_e( 'Connector address with a key', 'tw-divi-builder' ); ?></strong>
				<?php if ( $new ) : ?>
					<p><code id="twdb-addr-key"><?php echo esc_html( $key_url ); ?></code> <button type="button" class="button twdb-copy" data-target="twdb-addr-key"><?php esc_html_e( 'Copy', 'tw-divi-builder' ); ?></button></p>
					<p class="description"><strong><?php esc_html_e( 'Shown once.', 'tw-divi-builder' ); ?></strong> <?php esc_html_e( 'Only a hash of the key is stored. If you lose it, create another key and revoke this one.', 'tw-divi-builder' ); ?></p>
				<?php else : ?>
					<p><code><?php echo esc_html( $endpoint . '/YOUR_KEY' ); ?></code></p>
					<p class="description"><?php esc_html_e( 'Create a key under "Connector keys" below and the full address appears here once.', 'tw-divi-builder' ); ?></p>
				<?php endif; ?>
				<?php if ( empty( $settings['allow_path_key'] ) ) : ?>
					<p class="description" style="color:#b32d2e;"><?php esc_html_e( 'Keys inside the address are switched off (Access settings), so an address like the one above is refused. Prefer "Sign in with WordPress", or send the key in the Authorization header. Turn the option on only for an app that can do neither.', 'tw-divi-builder' ); ?></p>
				<?php endif; ?>
			</div>
		</div>

		<?php foreach ( $guides as $twdb_ai => $twdb_g ) : ?>
			<div class="twdb-guide" data-ai="<?php echo esc_attr( $twdb_ai ); ?>">
				<h3><?php echo esc_html( $twdb_g['label'] ); ?> <small>(<?php echo esc_html( $twdb_g['sub'] ); ?>)</small></h3>
				<?php foreach ( array( 'oauth', 'key' ) as $twdb_m ) : ?>
					<ol class="twdb-steps" data-method="<?php echo esc_attr( $twdb_m ); ?>">
						<?php foreach ( $twdb_g[ $twdb_m ] as $twdb_step ) : ?>
							<li><?php echo wp_kses( $twdb_step, TWDB_Settings::allowed_html() ); ?></li>
						<?php endforeach; ?>
					</ol>
				<?php endforeach; ?>
			</div>
		<?php endforeach; ?>

		<h2><?php esc_html_e( 'Connector keys', 'tw-divi-builder' ); ?></h2>
		<form method="post" action="<?php echo $twdb_post; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above. ?>" class="twdb-inline">
			<input type="hidden" name="action" value="twdb_create_key" />
			<?php wp_nonce_field( 'twdb_create_key' ); ?>
			<label for="twdb-key-name" class="screen-reader-text"><?php esc_html_e( 'Key name', 'tw-divi-builder' ); ?></label>
			<input type="text" id="twdb-key-name" name="key_name" class="regular-text" placeholder="<?php esc_attr_e( 'Name, e.g. Claude on claude.ai', 'tw-divi-builder' ); ?>" maxlength="60" />
			<?php submit_button( __( 'Create key', 'tw-divi-builder' ), 'primary', 'submit', false ); ?>
		</form>
		<?php if ( $keys || $legacy_on ) : ?>
			<table class="widefat striped twdb-table" style="max-width:900px;margin-top:12px;">
				<thead><tr><th><?php esc_html_e( 'Name', 'tw-divi-builder' ); ?></th><th><?php esc_html_e( 'Ends in', 'tw-divi-builder' ); ?></th><th><?php esc_html_e( 'Created', 'tw-divi-builder' ); ?></th><th><?php esc_html_e( 'Last used', 'tw-divi-builder' ); ?></th><th></th></tr></thead>
				<tbody>
				<?php foreach ( $keys as $twdb_kid => $twdb_k ) : ?>
					<tr>
						<td><?php echo esc_html( $twdb_k['name'] ); ?></td>
						<td><code><?php echo esc_html( $twdb_k['last4'] ); ?></code></td>
						<td><?php echo esc_html( wp_date( $twdb_fmt, (int) $twdb_k['created'] ) ); ?></td>
						<td><?php echo $twdb_k['last_used'] ? esc_html( wp_date( $twdb_fmt, (int) $twdb_k['last_used'] ) ) : esc_html__( 'never', 'tw-divi-builder' ); ?></td>
						<td>
							<form method="post" action="<?php echo $twdb_post; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="margin:0">
								<input type="hidden" name="action" value="twdb_revoke_key_id" />
								<input type="hidden" name="key_id" value="<?php echo esc_attr( $twdb_kid ); ?>" />
								<?php wp_nonce_field( 'twdb_revoke_key_id' ); ?>
								<?php submit_button( __( 'Revoke', 'tw-divi-builder' ), 'secondary small', 'submit', false, array( 'onclick' => "return confirm('" . esc_js( __( 'Revoke this key? Anything using it stops working.', 'tw-divi-builder' ) ) . "');" ) ); ?>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				<?php if ( $legacy_on ) : ?>
					<tr>
						<td><?php esc_html_e( 'Original key (from before named keys)', 'tw-divi-builder' ); ?></td>
						<td><code><?php echo is_array( $legacy_hint ) ? esc_html( $legacy_hint['last4'] ) : ''; ?></code></td>
						<td><?php echo ( is_array( $legacy_hint ) && ! empty( $legacy_hint['created'] ) ) ? esc_html( wp_date( $twdb_fmt, (int) $legacy_hint['created'] ) ) : ''; ?></td>
						<td><?php esc_html_e( 'header use only', 'tw-divi-builder' ); ?></td>
						<td>
							<form method="post" action="<?php echo $twdb_post; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="margin:0">
								<input type="hidden" name="action" value="twdb_revoke_key" />
								<?php wp_nonce_field( 'twdb_revoke_key' ); ?>
								<?php submit_button( __( 'Revoke', 'tw-divi-builder' ), 'secondary small', 'submit', false, array( 'onclick' => "return confirm('" . esc_js( __( 'Revoke the original key?', 'tw-divi-builder' ) ) . "');" ) ); ?>
							</form>
						</td>
					</tr>
				<?php endif; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p class="description"><?php esc_html_e( 'No keys yet. You only need one for the connector-key route.', 'tw-divi-builder' ); ?></p>
		<?php endif; ?>

		<?php if ( $oauth_on ) : ?>
			<details class="twdb-card" style="margin-top:24px;">
				<summary><strong><?php esc_html_e( 'Sign-in not connecting? Check these addresses', 'tw-divi-builder' ); ?></strong></summary>
				<?php if ( $subfolder ) : ?>
					<p><?php esc_html_e( 'This site lives in a subfolder. Apps look for the sign-in documents under that folder, so the addresses below must open in your browser and show JSON, not a 404 page or a web page.', 'tw-divi-builder' ); ?></p>
				<?php else : ?>
					<p><?php esc_html_e( 'These addresses must open in your browser and show JSON, not a 404 page or a web page.', 'tw-divi-builder' ); ?></p>
				<?php endif; ?>
				<ul>
					<?php foreach ( $checks as $twdb_c ) : ?>
						<li><a href="<?php echo esc_url( $twdb_c ); ?>" target="_blank" rel="noopener"><code><?php echo esc_html( $twdb_c ); ?></code></a></li>
					<?php endforeach; ?>
					<li><a href="<?php echo esc_url( rest_url( TWDB_REST_NS . '/oauth/metadata' ) ); ?>" target="_blank" rel="noopener"><code><?php echo esc_html( rest_url( TWDB_REST_NS . '/oauth/metadata' ) ); ?></code></a></li>
				</ul>
				<p class="description"><?php esc_html_e( 'If your host blocks every /.well-known/ address and the app still cannot sign in, use the connector key route: it needs none of them.', 'tw-divi-builder' ); ?></p>
			</details>
		<?php endif; ?>

	<?php elseif ( 'people' === $tab ) : ?>

		<h2><?php esc_html_e( 'Connected people', 'tw-divi-builder' ); ?></h2>
		<p><?php esc_html_e( 'Each row is an app an administrator approved through "Sign in with WordPress". Revoke ends that one connection only; the app has to sign in again to come back. Connections made with a connector key are not listed here: revoke those on the Connection tab.', 'tw-divi-builder' ); ?></p>
		<?php if ( ! $people ) : ?>
			<p><em><?php esc_html_e( 'Nobody is connected through sign-in yet.', 'tw-divi-builder' ); ?></em></p>
		<?php else : ?>
			<table class="widefat striped twdb-table" style="max-width:900px;">
				<thead><tr><th><?php esc_html_e( 'Approved by', 'tw-divi-builder' ); ?></th><th><?php esc_html_e( 'App', 'tw-divi-builder' ); ?></th><th><?php esc_html_e( 'Connected', 'tw-divi-builder' ); ?></th><th><?php esc_html_e( 'Last used', 'tw-divi-builder' ); ?></th><th></th></tr></thead>
				<tbody>
				<?php foreach ( $people as $twdb_p ) : ?>
					<tr>
						<td><?php echo esc_html( $twdb_p['user'] ); ?></td>
						<td><?php echo esc_html( $twdb_p['client'] ); ?></td>
						<td><?php echo esc_html( wp_date( $twdb_fmt, $twdb_p['created'] ) ); ?></td>
						<td><?php echo $twdb_p['last_used'] ? esc_html( wp_date( $twdb_fmt, $twdb_p['last_used'] ) ) : esc_html__( 'not yet', 'tw-divi-builder' ); ?></td>
						<td>
							<form method="post" action="<?php echo $twdb_post; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="margin:0">
								<input type="hidden" name="action" value="<?php echo esc_attr( TWDB_OAuth::ACTION_REVOKE ); ?>" />
								<input type="hidden" name="grant" value="<?php echo esc_attr( $twdb_p['id'] ); ?>" />
								<?php wp_nonce_field( TWDB_OAuth::ACTION_REVOKE ); ?>
								<?php submit_button( __( 'Revoke', 'tw-divi-builder' ), 'secondary small', 'submit', false, array( 'onclick' => "return confirm('" . esc_js( __( 'End this connection? The app will have to sign in again.', 'tw-divi-builder' ) ) . "');" ) ); ?>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php $twdb_as = get_userdata( TWDB_Settings::acting_user_id() ); ?>
		<p class="description" style="margin-top:12px;"><?php echo $twdb_as ? esc_html( sprintf( /* translators: %s: user name */ __( 'Every connection acts on the site as %s (the "AI acts as user" setting), whatever the approving administrator could do.', 'tw-divi-builder' ), $twdb_as->display_name ) ) : esc_html__( 'No "AI acts as user" account is set. Choose one under Access settings.', 'tw-divi-builder' ); ?></p>

	<?php elseif ( 'access' === $tab ) : ?>

		<h2><?php esc_html_e( 'Access settings', 'tw-divi-builder' ); ?></h2>
		<form method="post" action="<?php echo $twdb_post; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
			<input type="hidden" name="action" value="twdb_save_settings" />
			<?php wp_nonce_field( 'twdb_save_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="twdb-acting-user"><?php esc_html_e( 'AI acts as user', 'tw-divi-builder' ); ?></label></th>
					<td>
						<select id="twdb-acting-user" name="acting_user">
							<?php foreach ( $users as $twdb_user ) : ?>
								<option value="<?php echo esc_attr( $twdb_user->ID ); ?>" <?php selected( TWDB_Settings::acting_user_id(), $twdb_user->ID ); ?>><?php echo esc_html( $twdb_user->display_name . ' (' . $twdb_user->user_login . ' - ' . implode( ', ', $twdb_user->roles ) . ')' ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Requests made with a connector key or through sign-in run with this user\'s capabilities. An Administrator is needed for design system, Theme Builder, CSS and menu tools; an Editor can only manage content. Users without "unfiltered_html" get their markup filtered by WordPress, which can break Code modules and embeds.', 'tw-divi-builder' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Sign in with WordPress', 'tw-divi-builder' ); ?></th>
					<td><label><input type="checkbox" name="allow_oauth" value="1" <?php checked( ! empty( $settings['allow_oauth'] ) ); ?> /> <?php esc_html_e( 'Let apps connect through a WordPress login (OAuth). An administrator approves each one; you can end any of them under Connected people.', 'tw-divi-builder' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Key inside the address', 'tw-divi-builder' ); ?></th>
					<td><label><input type="checkbox" name="allow_path_key" value="1" <?php checked( ! empty( $settings['allow_path_key'] ) ); ?> /> <?php esc_html_e( 'Accept a connector key as part of the address (.../mcp/<key>), only for apps that support neither "Sign in with WordPress" nor headers.', 'tw-divi-builder' ); ?></label>
					<p class="description" style="color:#b32d2e;"><?php esc_html_e( 'Warning: an address that contains a key can be written to web-server, CDN and proxy access logs, browser history and app configuration files, where anyone who reads them can use the key. Prefer "Sign in with WordPress" (OAuth) or the Authorization header. If you turn this on, use a separate key for that app and revoke it as soon as it is no longer needed. Off by default on new installations.', 'tw-divi-builder' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Read-only mode', 'tw-divi-builder' ); ?></th>
					<td><label><input type="checkbox" name="read_only" value="1" <?php checked( ! empty( $settings['read_only'] ) ); ?> /> <?php esc_html_e( 'Only allow read tools (no changes to the site).', 'tw-divi-builder' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Tool groups', 'tw-divi-builder' ); ?></th>
					<td>
						<?php foreach ( TWDB_Tools::groups() as $twdb_gkey => $twdb_glabel ) : ?>
							<label style="display:block;margin-bottom:4px;"><input type="checkbox" name="groups[]" value="<?php echo esc_attr( $twdb_gkey ); ?>" <?php checked( in_array( $twdb_gkey, (array) $settings['groups'], true ) ); ?> /> <?php echo esc_html( $twdb_glabel ); ?></label>
						<?php endforeach; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Helper CSS and JS', 'tw-divi-builder' ); ?></th>
					<td><label><input type="checkbox" name="helpers" value="1" <?php checked( ! isset( $settings['helpers'] ) || ! empty( $settings['helpers'] ) ); ?> /> <?php esc_html_e( 'Load a few KB of front-end helpers the AI skill relies on: buttons never change letter-spacing on hover, equal-height card rows (class twdb-equal-cards) and custom tabs made of buttons and rows (classes twdb-tabs / twdb-tab-btn / twdb-tab-panel). Leave on unless you use your own CSS for these.', 'tw-divi-builder' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Application Passwords', 'tw-divi-builder' ); ?></th>
					<td><label><input type="checkbox" name="allow_app_passwords" value="1" <?php checked( ! empty( $settings['allow_app_passwords'] ) ); ?> /> <?php esc_html_e( 'Also accept WordPress Application Passwords (Basic auth). Requests then run as that user.', 'tw-divi-builder' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Key in URL query (not recommended)', 'tw-divi-builder' ); ?></th>
					<td><label><input type="checkbox" name="allow_url_key" value="1" <?php checked( ! empty( $settings['allow_url_key'] ) ); ?> /> <?php esc_html_e( 'Accept a key as ?tw_key= in the address. Older option; the key inside the address above is neater.', 'tw-divi-builder' ); ?></label></td>
				</tr>
			</table>
			<?php submit_button( __( 'Save settings', 'tw-divi-builder' ) ); ?>
		</form>

		<h2><?php esc_html_e( 'Status', 'tw-divi-builder' ); ?></h2>
		<ul>
			<li><?php esc_html_e( 'Divi active:', 'tw-divi-builder' ); ?> <strong><?php echo $divi['active'] ? esc_html( $divi['product'] . ' ' . $divi['version'] ) : esc_html__( 'No', 'tw-divi-builder' ); ?></strong></li>
			<li><?php esc_html_e( 'Divi 5:', 'tw-divi-builder' ); ?> <strong><?php echo $divi['is_divi5'] ? esc_html__( 'Yes', 'tw-divi-builder' ) : esc_html__( 'No', 'tw-divi-builder' ); ?></strong></li>
			<li><?php esc_html_e( 'Plugin version:', 'tw-divi-builder' ); ?> <strong><?php echo esc_html( TWDB_VERSION ); ?></strong></li>
		</ul>

	<?php elseif ( 'selftest' === $tab ) : ?>

		<h2><?php esc_html_e( 'Self-test', 'tw-divi-builder' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Creates a throw-away draft page, reads and edits it, loads it on the front end, saves and removes a test global color and variable, then deletes everything it made. Run it after installing or after a Divi update. Send any failing row to whoever supports your site.', 'tw-divi-builder' ); ?></p>
		<form method="post" action="<?php echo $twdb_post; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above. ?>">
			<input type="hidden" name="action" value="twdb_selftest" />
			<?php wp_nonce_field( 'twdb_selftest' ); ?>
			<?php submit_button( __( 'Run self-test', 'tw-divi-builder' ), 'primary', 'submit', false ); ?>
		</form>
		<?php if ( is_array( $selftest ) ) : ?>
			<table class="widefat striped" style="max-width:1000px;margin-top:16px;">
				<tbody>
				<?php foreach ( $selftest as $twdb_row ) : ?>
					<tr>
						<td style="width:260px;"><strong><?php echo esc_html( $twdb_row['name'] ); ?></strong></td>
						<td style="width:40px;"><?php echo 'ok' === $twdb_row['status'] ? '&#9989;' : ( 'skip' === $twdb_row['status'] ? '&#9898;' : '&#10060;' ); ?></td>
						<td><code style="word-break:break-all;"><?php echo esc_html( $twdb_row['detail'] ); ?></code></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

	<?php else : ?>

		<h2><?php esc_html_e( 'History (last 300 changes and connection events)', 'tw-divi-builder' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Who changed what: the key or the app (and the administrator who approved it), the tool, and the page or item it touched. Read-only tool calls are not recorded.', 'tw-divi-builder' ); ?></p>
		<?php if ( empty( $log ) ) : ?>
			<p><?php esc_html_e( 'Nothing recorded yet.', 'tw-divi-builder' ); ?></p>
		<?php else : ?>
			<div style="max-height:560px;overflow:auto;">
			<table class="widefat striped twdb-table">
				<thead><tr><th><?php esc_html_e( 'Time', 'tw-divi-builder' ); ?></th><th><?php esc_html_e( 'Who', 'tw-divi-builder' ); ?></th><th><?php esc_html_e( 'Tool', 'tw-divi-builder' ); ?></th><th><?php esc_html_e( 'Item', 'tw-divi-builder' ); ?></th><th><?php esc_html_e( 'Result', 'tw-divi-builder' ); ?></th><th><?php esc_html_e( 'Details', 'tw-divi-builder' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( array_reverse( $log ) as $twdb_entry ) : ?>
					<?php
					$twdb_u   = get_userdata( (int) $twdb_entry['user'] );
					$twdb_who = ! empty( $twdb_entry['actor'] ) ? $twdb_entry['actor'] : ( $twdb_u ? $twdb_u->user_login : '#' . $twdb_entry['user'] ) . ' (' . $twdb_entry['via'] . ')';
					?>
					<tr>
						<td><?php echo esc_html( wp_date( 'Y-m-d H:i:s', (int) $twdb_entry['time'] ) ); ?></td>
						<td><?php echo esc_html( $twdb_who ); ?></td>
						<td><code><?php echo esc_html( $twdb_entry['tool'] ); ?></code></td>
						<td><?php echo esc_html( isset( $twdb_entry['target'] ) ? $twdb_entry['target'] : '' ); ?></td>
						<td><?php echo $twdb_entry['ok'] ? '<span style="color:#008a20;">OK</span>' : '<span style="color:#b32d2e;">' . esc_html__( 'Error', 'tw-divi-builder' ) . '</span>'; ?></td>
						<td><?php echo esc_html( $twdb_entry['summary'] ); ?><br /><code style="font-size:11px;word-break:break-all;"><?php echo esc_html( $twdb_entry['args'] ); ?></code></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
			<form method="post" action="<?php echo $twdb_post; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="margin-top:8px;">
				<input type="hidden" name="action" value="twdb_clear_log" />
				<?php wp_nonce_field( 'twdb_clear_log' ); ?>
				<?php submit_button( __( 'Clear history', 'tw-divi-builder' ), 'secondary small', 'submit', false ); ?>
			</form>
		<?php endif; ?>

	<?php endif; ?>

	<p class="description" style="margin-top:24px;">
		<?php
		printf(
			/* translators: %s: link to the developer's website */
			esc_html__( 'Developed by Deepak Juneja, %s. Third-party licences: see THIRD-PARTY-NOTICES.txt in the plugin folder.', 'tw-divi-builder' ),
			'<a href="' . esc_url( 'https://www.techwebers.com/' ) . '" target="_blank" rel="noopener">www.techwebers.com</a>'
		);
		?>
	</p>
</div>
