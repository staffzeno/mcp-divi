# Changelog

All notable changes to Tech Webers MCP Builder for Divi 5.

## 1.4.5

* Fix (mbstring): the 10 `mb_substr()` calls in connector keys, the activity log, restore points, OAuth client registration, the module tree and diagnostics now use `TWDB_Text::substr()`, a character-based UTF-8 helper that needs no PHP extension. Limits are unchanged (key names 60, activity actor 120, summary 300, target 80, argument preview 60 and arguments 600, restore point titles 180, client names 80, module labels 80, diagnostic details 500 characters). Results equal `mb_substr( ..., 'UTF-8' )` on valid UTF-8, including negative offsets and lengths; invalid bytes count as one character and are left out of the result. Before, these calls relied on WordPress's own `mb_substr()` fallback when mbstring was missing. New `TWDB_Text::length()`.
* Fix (paging): new `TWDB_Text::next_offset()` returns null instead of an offset that would not advance, and get_divi_reference uses it, so a client that pages on `next_offset` always finishes. `TWDB_Text::MIN_PAGE_BYTES` (4) documents the smallest byte budget that always makes progress without splitting or skipping a character; the reference tool's minimum page size stays at 1000.
* Developers: more standalone UTF-8 tests (character and byte truncation, small budgets, termination, mbstring comparison) and WordPress regression tests for every former `mb_substr()` call site, run with the mbstring extension unloaded.

## 1.4.4

* Fix (UTF-8): `TWDB_Text::cut()` never returns part of a character. A start offset inside a multibyte character now moves forward to the next character (it used to move back and repeat text from the previous page), the byte budget is never exceeded, invalid UTF-8 bytes are dropped from the output, and the result no longer depends on mbstring. The new `TWDB_Text::range()` gives the exact byte range, and get_divi_reference returns `next_offset` from it so consecutive pages tile the text exactly. `max_chars` and `offset` are clamped to their documented ranges.
* Security (code policy): existing values are preserved by block type, attribute path and number of occurrences, so code a person added stays where it is, but the AI can no longer copy it into another module or attribute or duplicate it. A final, independent check refuses any save whose result would contain more scripts, embeds or event handlers than the stored content. Page titles, excerpts and library item titles are cleaned by the same policy.
* Fix (upgrade): sites upgrading from 1.4.2 or earlier that never saved the plugin settings (for example network sub-sites) but have connector keys now keep keys inside the connector address working, as before; sites without keys and new installations keep the safer default (off).
* Developers: standalone `tests/unit/text-test.php` (no WordPress, no PHPUnit), new security tests for upgrades, key storage and rotation, malformed URLs, download clean-up and the code policy.

## 1.4.3

* Security / WordPress.org compliance: AI clients can no longer add executable code. Scripts, iframes, objects and embeds, inline event handlers, javascript:/vbscript: and non-image data: URLs, Divi custom attributes named on*, and script-like CSS are removed on the server in every tool that saves pages, modules, library items, Theme Builder layouts, presets, variables or CSS. Existing content that is sent back unchanged (for example a Code module added by a person) is kept exactly as it is. The 1.4.2 setting "Allow the AI to add scripts and embeds" is removed.
* Security: "Keys inside the connector address" is off by default on new installations (existing sites keep their current setting), with a warning that such addresses can appear in server and proxy logs. OAuth and the Authorization header are recommended.
* Security: client-chosen downloads are pinned to the checked address on both WordPress HTTP transports (cURL and streams). HTTPS downloads on servers without cURL, downloads through a configured HTTP proxy, and responses from transports that ignore the pin are refused instead of running unprotected. cURL no longer picks up proxies from the environment for these downloads.
* WordPress.org: shorter plugin description, readme under 10 KB, full history moved to CHANGELOG.md.
* Developers: development test suites under tests/ (security, DNS-rebinding on both transports, multisite, no-mbstring) with a runner script.

## 1.4.2

* New: setting "Allow the AI to add scripts and embeds". Off on new installations: WordPress filters scripts, iframes and event handlers out of what the AI writes. Sites upgrading from earlier versions keep their previous behaviour.
* New: a stored plugin version with one-time upgrade steps (replaces a check that ran on every page load).
* Fix: when the acting user lacks the unfiltered_html capability (for example an Editor, or any user on multisite), WordPress's HTML filter turned Divi modules that contain HTML into escaped text, destroying them. Divi markup is now stored in WordPress's canonical block form before filtering, so only unsafe code is removed and the layout survives.
* Security (multisite): a connector key created by a site administrator can no longer act as a network Super Admin, and the automatic "AI acts as user" fallback never picks a Super Admin.
* Fix: deleting or moving the last module out of a container with edit_page_modules raised PHP warnings while saving.
* Fix: truncating large pages and reference documents no longer needs the mbstring extension (UTF-8 safe fallback).
* Fix: cache clearing no longer calls a WordPress 6.1 function on WordPress 6.0.
* MCP: unsupported MCP-Protocol-Version headers are answered with 400; request ids must be strings or integers; tool arguments must be a JSON object.
* Performance: the settings option is autoloaded; Divi detection is computed once per request; admin CSS and JavaScript are separate files loaded only on the plugin's settings screen.
* i18n: the OAuth approval page is translatable.
* Long downloads and loopback renders ask for more PHP execution time where the host allows it.
* Readme: short description within 150 characters; tool list, external services and code policy documented.

## 1.4.1

* Change: new, original "Sign in with WordPress" (OAuth 2.1) server written from the published specifications, with a redesigned approval page. Endpoints and token formats are unchanged, and existing connections are converted automatically and stay signed in.
* Change: plugin renamed to "Tech Webers MCP Builder for Divi 5" (WordPress.org trademark rules). Settings and connections are unaffected.
* Security: media import and client-metadata fetches now refuse private, loopback, link-local (cloud metadata), CGNAT, reserved and IPv6-embedded addresses on every redirect hop (also on WordPress versions whose core check does not), check all A and AAAA records, pin the connection to the checked address (DNS rebinding) and cap the download while streaming.
* Security: media import accepts only image, audio, video and document types; active content (HTML, JavaScript, SVG, XML, PHP) is refused even when the acting user is an administrator.
* Security: OAuth refresh-token reuse detection; a replayed, already-rotated refresh token ends the connection. The token store is now updated under a lock, so authorization codes cannot be redeemed twice by concurrent requests and a revoked connection cannot be restored by a concurrent request.
* Security: the OAuth consent step checks the administrator role before fetching any client metadata; rate limits on client registration, failed token requests and media imports.
* Security: a deleted "AI acts as user" account is no longer silently replaced by the first administrator.
* Security: on multisite, a site administrator cannot let the AI act as a network Super Admin.
* Security: restore_backup can no longer publish content the acting user cannot publish; Theme Builder layouts need edit_theme_options when changed through page tools; parent pages are validated; list_backups only lists restore points of items the acting user can read.
* Security: connector-key "last used" times are stored separately, so using a key can never restore a key revoked a moment earlier.
* Security: MCP request bodies are capped (8 MB, filter twdb_max_request_bytes), batches are capped (25, filter twdb_max_batch), JSON nesting is limited, the REST mirror refuses malformed JSON instead of running a tool with defaults, and internal errors no longer reveal file paths or exception messages.
* Security: safer handling of stored Divi data (no object unserialization) and of CSS printed in <style>.
* Change: site_info lists active plugins only to users who can activate plugins, and the PHP version only to administrators.
* Change: uninstall also removes transients, lock rows and the plugin's media bookkeeping, on every site of a network.
* Change: author credit (Deepak Juneja, www.techwebers.com); third-party licences consolidated in THIRD-PARTY-NOTICES.txt.

## 1.4.0

* New: "house-rules" reference topic with the owner's defaults: section side padding 50px / 30px / 20px (desktop / tablet / phone), rows 100% wide, 16px gaps (row columnGap/rowGap, column and group rowGap), equal-size cards in a row, native tabs by default, no look-alike sections, a responsive mobile menu, and uploaded designs copied exactly with nothing added.
* New: front-end helpers (Access settings > "Helper CSS and JS", on by default): buttons never change letter-spacing on hover (opt out with class twdb-keep-ls), equal-height card rows (class twdb-equal-cards on the row), and custom tabs made of buttons and rows with a small script (classes twdb-tabs / twdb-tab-btn / twdb-tab-panel; keyboard and ARIA support, deep links, all panels visible without JS).
* New: the markup validator warns when two adjacent sections have the identical layout, or three or more share the same multi-column layout.
* Change: the header/footer navigation guidance now requires a real responsive divi/menu instead of a row of links.
* Change: SKILL.md lists the house rules at the top; the MCP instructions tell the AI to read them first.

## 1.3.0

* New: "mockup" reference topic (DIVI5-MOCKUP-FIDELITY.md). When you supply a mockup, Figma, PDF or HTML, the AI skips discovery/plan approval and reproduces your design exactly with native Divi modules: design inventory, exact values on every module (no preset/default leakage), native module mapping, assets, draft build, and a measure-and-fix loop targeting <= 1% pixel difference per breakpoint, with an honest report.
* Change: SKILL.md starts with a mode check; MCP instructions point to the new topic.

## 1.2.1

* Fix: buttons no longer change letter-spacing on hover. The skill/reference now tells the AI to write the same letterSpacing (default 0px) in the resting AND hover state of every button, the MCP instructions repeat it, and the markup validator warns when a button has no hover letterSpacing or a hover value that differs from the resting one.

## 1.2.0

* New: DeepSeek Harness guide on the Connection tab (cordis.patch.yml entry using Harness's built-in MCP client; the key is read from an environment variable).
* New: Self-test tab. Creates and removes a throw-away page and test color/variable, so you can see on the real site whether Divi 5 storage, editing and front-end rendering work.
* New tools: get_page_tree and edit_page_modules (change, replace, add, delete or move single modules by path without rewriting the page).
* Fix: global colors and variables are saved through Divi 5's own GlobalData API, so they appear in the Divi builder (Divi 5.17 tested against a stand-in; verify with the Self-test).
* Fix: render_page in full mode returns the page body instead of Divi's inline CSS, so truncation no longer hides the content (include_head returns everything).

## 1.1.0

* New: Sign in with WordPress (OAuth 2.1, PKCE, dynamic client registration and client ID metadata documents). Works with claude.ai, Claude Code, ChatGPT, Codex, Gemini CLI and other MCP apps. Includes the discovery forms a site in a subfolder needs.
* New: connector key inside the address (`/mcp/<key>`) for apps with no header field, such as claude.ai.
* New: named connector keys (up to 20), each with last-used time and its own Revoke. The original single key keeps working until you revoke it.
* New: Connection tab with an AI picker, per-app steps and copy buttons; Connected people tab with Revoke; Access settings tab; History tab.
* Change: the audit log is now History, keeps 300 entries, and records who acted (key name, or app and approving administrator) and which item was touched.

## 1.0.1

* Fix: signed draft previews no longer redirect to the homepage when the draft has no slug (canonical redirect disabled for valid signed preview requests).
* Fix: render_page full mode warns when the fetched HTML is not the requested page instead of silently returning another page.
* Fix: preview no-cache headers are sent earlier (send_headers) and tell page-cache plugins (DONOTCACHEPAGE, LiteSpeed) not to cache previews.
* Fix: titles in tool output are decoded (e.g. "Press & Media" instead of "Press &#038; Media").
* Docs: note that some hosts/CDNs override Cache-Control on previews.

## 1.0.0

* First release.
